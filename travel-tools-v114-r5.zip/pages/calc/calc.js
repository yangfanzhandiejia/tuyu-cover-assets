// 通用估算档位：各航司规则不同，仅供参考
// pct[cabinIdx][tierIdx] = 手续费占票面价百分比（%），0 表示可能不退
const PCTS = [
  [5, 5, 10, 10, 20],   // 经济舱（全价）
  [10, 15, 20, 30, 40], // 经济舱（折扣）
  [30, 40, 50, 50, 0],  // 特价票
];

function round2(n) {
  return Math.round(n * 100) / 100;
}

const { SECTIONS } = require('../../data/guides');
const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');

// 国内出发最常去的 15 个热门目的地（固定 UTC 偏移，不处理夏令时）
const TIMEZONES = [
  // ---------- 亚洲 ----------
  { city: '东京', utc: 9, climate: '年均约16℃；6月梅雨、7-8月湿热、12-2月干冷' },
  { city: '大阪', utc: 9, climate: '年均约16℃；四季分明，夏季湿热' },
  { city: '札幌', utc: 9, climate: '年均约9℃；冬季多雪严寒，夏季凉爽宜人' },
  { city: '福冈', utc: 9, climate: '年均约17℃；气候温和，四季舒适' },
  { city: '首尔', utc: 9, climate: '年均约13℃；冬冷夏热，7-8月多雨' },
  { city: '新加坡', utc: 8, climate: '常年26-31℃；高温多雨，随身备伞' },
  { city: '吉隆坡', utc: 8, climate: '常年26-32℃；午后多雷阵雨' },
  { city: '曼谷', utc: 7, climate: '常年28-34℃；3-5月最热，11-2月较舒适' },
  { city: '清迈', utc: 7, climate: '年均约25℃；11-2月凉爽，3-5月炎热' },
  { city: '普吉岛', utc: 7, climate: '常年27-33℃；11-4月旱季最宜出行' },
  { city: '河内', utc: 7, climate: '年均约24℃；夏湿热，冬微凉' },
  { city: '胡志明市', utc: 7, climate: '常年26-35℃；分旱雨两季' },
  { city: '金边', utc: 7, climate: '常年26-35℃；11-4月旱季舒适' },
  { city: '仰光', utc: 6.5, climate: '常年25-35℃；5-10月雨季' },
  { city: '马尼拉', utc: 8, climate: '常年25-33℃；6-11月为台风季' },
  { city: '雅加达', utc: 7, climate: '常年25-33℃；湿热多雨' },
  { city: '巴厘岛', utc: 8, climate: '常年26-32℃；4-10月旱季最宜' },
  { city: '香港', utc: 8, climate: '年均约23℃；夏湿热多雨，冬温和' },
  { city: '澳门', utc: 8, climate: '年均约23℃；与香港相近' },
  { city: '台北', utc: 8, climate: '年均约23℃；夏热多雨，冬湿冷' },
  { city: '德里', utc: 5.5, climate: '年均约25℃；4-6月酷热，7-9月季风' },
  { city: '孟买', utc: 5.5, climate: '常年20-33℃；6-9月暴雨季' },
  { city: '班加罗尔', utc: 5.5, climate: '常年16-32℃；高原气候较舒适' },
  { city: '科伦坡', utc: 5.5, climate: '常年26-31℃；湿热，沿海多雨' },
  { city: '加德满都', utc: 5.75, climate: '年均约18℃；昼夜温差大，10-11月最佳' },
  { city: '阿拉木图', utc: 6, climate: '年均约10℃；冬严寒夏温暖' },
  { city: '乌兰巴托', utc: 8, climate: '年均约0℃；冬季极寒，昼夜温差大' },
  // ---------- 中东 ----------
  { city: '迪拜', utc: 4, climate: '11-3月舒适20-28℃；5-9月酷热可达40℃+' },
  { city: '阿布扎比', utc: 4, climate: '同迪拜；夏季极热，冬季宜人' },
  { city: '多哈', utc: 3, climate: '冬季18-25℃舒适；夏季45℃极热' },
  { city: '利雅得', utc: 3, climate: '沙漠气候；夏极热，冬温和' },
  { city: '伊斯坦布尔', utc: 3, climate: '年均约15℃；四季分明，春秋最佳' },
  { city: '特拉维夫', utc: 2, climate: '年均约20℃；地中海气候，夏干冬雨' },
  // ---------- 欧洲 ----------
  { city: '伦敦', utc: 0, climate: '全年5-23℃；多雨，冬温夏凉，务必带伞' },
  { city: '巴黎', utc: 1, climate: '全年6-25℃；四季分明，春秋宜人' },
  { city: '罗马', utc: 1, climate: '全年8-28℃；夏干热，7-8月较晒' },
  { city: '米兰', utc: 1, climate: '全年3-29℃；夏热冬凉，冬季多雾' },
  { city: '柏林', utc: 1, climate: '全年1-25℃；冬冷夏凉' },
  { city: '慕尼黑', utc: 1, climate: '全年-1~24℃；冬季寒冷多雪' },
  { city: '法兰克福', utc: 1, climate: '全年2-26℃；四季分明' },
  { city: '阿姆斯特丹', utc: 1, climate: '全年3-22℃；多雨多风，随身外套' },
  { city: '苏黎世', utc: 1, climate: '全年1-26℃；冬季可作滑雪季' },
  { city: '维也纳', utc: 1, climate: '全年1-27℃；四季分明' },
  { city: '布拉格', utc: 1, climate: '全年1-25℃；冬冷夏凉' },
  { city: '布达佩斯', utc: 1, climate: '全年0-27℃；大陆性气候' },
  { city: '雅典', utc: 2, climate: '全年9-32℃；夏热干燥，日照强' },
  { city: '里斯本', utc: 0, climate: '全年10-28℃；温和宜人' },
  { city: '马德里', utc: 1, climate: '全年6-31℃；夏热冬凉' },
  { city: '巴塞罗那', utc: 1, climate: '全年10-29℃；地中海气候' },
  { city: '斯德哥尔摩', utc: 1, climate: '全年-3~23℃；冬季寒冷多雪' },
  { city: '赫尔辛基', utc: 2, climate: '全年-6~22℃；冬季严寒' },
  { city: '莫斯科', utc: 3, climate: '全年-8~24℃；冬季严寒多雪' },
  { city: '圣彼得堡', utc: 3, climate: '全年-8~23℃；冬季漫长寒冷' },
  // ---------- 非洲 ----------
  { city: '开罗', utc: 2, climate: '全年14-35℃；沙漠气候，夏季极热' },
  { city: '内罗毕', utc: 3, climate: '全年13-25℃；高原温和如春' },
  { city: '开普敦', utc: 2, climate: '全年11-26℃；地中海气候' },
  { city: '约翰内斯堡', utc: 2, climate: '全年8-26℃；高原温和，昼夜温差大' },
  { city: '卡萨布兰卡', utc: 1, climate: '全年10-26℃；温和少雨' },
  // ---------- 美洲 ----------
  { city: '纽约', utc: -5, climate: '全年-1~29℃；四季分明，冬冷夏热' },
  { city: '华盛顿', utc: -5, climate: '全年0-30℃；四季分明' },
  { city: '芝加哥', utc: -6, climate: '全年-5~29℃；冬季严寒多雪' },
  { city: '洛杉矶', utc: -8, climate: '全年14-29℃；温和少雨' },
  { city: '旧金山', utc: -8, climate: '全年10-22℃；夏凉多雾，需备外套' },
  { city: '西雅图', utc: -8, climate: '全年6-25℃；多雨，冬季阴湿' },
  { city: '温哥华', utc: -8, climate: '全年4-22℃；冬雨夏凉' },
  { city: '多伦多', utc: -5, climate: '全年-5~27℃；冬季寒冷' },
  { city: '蒙特利尔', utc: -5, climate: '全年-9~26℃；冬季严寒多雪' },
  { city: '墨西哥城', utc: -6, climate: '全年12-27℃；高原四季如春' },
  { city: '圣保罗', utc: -3, climate: '全年12-28℃；温和，12-3月多雨' },
  { city: '里约热内卢', utc: -3, climate: '全年19-30℃；湿热，12-3月最热' },
  { city: '布宜诺斯艾利斯', utc: -3, climate: '全年11-29℃；温和宜人' },
  { city: '利马', utc: -5, climate: '全年15-26℃；少雨，冬季多雾' },
  // ---------- 大洋洲 ----------
  { city: '悉尼', utc: 10, climate: '全年13-26℃；温和宜人' },
  { city: '墨尔本', utc: 10, climate: '全年8-26℃；一日多变，随身外套' },
  { city: '布里斯班', utc: 10, climate: '全年11-29℃；温暖舒适' },
  { city: '珀斯', utc: 8, climate: '全年11-30℃；夏季干热' },
  { city: '奥克兰', utc: 12, climate: '全年11-24℃；温和多雨' },
  { city: '惠灵顿', utc: 12, climate: '全年9-21℃；多风，注意防风' },
];

// 实行夏令时（DST）的常用目的地：每年 3-11 月当地时间比上表标准时区快 1 小时。
// 俄罗斯（莫斯科等，2014 年起）、墨西哥（2022 年起）已废止夏令时，不在此列。
const DST_CITIES = new Set([
  '伦敦', '巴黎', '罗马', '米兰', '柏林', '慕尼黑', '法兰克福', '阿姆斯特丹',
  '苏黎世', '维也纳', '布拉格', '布达佩斯', '雅典', '里斯本', '马德里', '巴塞罗那',
  '斯德哥尔摩', '赫尔辛基', '纽约', '华盛顿', '芝加哥', '洛杉矶', '旧金山', '西雅图',
  '温哥华', '多伦多', '蒙特利尔',
]);

const share = require('../../utils/share');
Page({
  data: {
    tab: 'refund',
    cabins: ['经济舱（全价）', '经济舱（折扣）', '特价票'],
    tiers: ['起飞前7天以上', '起飞前2~7天', '起飞前24~48小时', '起飞前24小时内', '起飞后'],
    cabinIdx: 1,
    tierIdx: 2,
    price: '',
    refundResult: null,

    freeKg: '20',
    actualKg: '',
    fullPrice: '',
    bagResult: null,

    // 免费托运额度速查（通用参考，以航司公示为准）
    baggageTable: [
      { name: '国航 / 东航 / 南航', eco: '20kg', biz: '30kg', note: '部分国际航线为 23kg' },
      { name: '海航 / 厦航 / 深航 / 川航', eco: '20kg', biz: '30kg', note: '与三大航基本一致' },
      { name: '吉祥 / 山航 / 长龙', eco: '20kg', biz: '30kg', note: '多数国内航线 20kg' },
      { name: '春秋航空', eco: '需另行购买', biz: '按所购产品', note: '手提约 7kg，托运要单买' },
      { name: '中国联合航空', eco: '需另行购买', biz: '按所购产品', note: '低成本航司，额度偏紧' },
      { name: '婴儿票（<2 岁）', eco: '约 10kg', biz: '同经济舱', note: '多数航司可免费托运婴儿车' },
    ],

    // 手提行李通用规则
    handRule: [
      '国内航班手提行李一般限 5kg，件数 1 件',
      '常见尺寸上限 20×40×55cm，各航司略有差异',
      '廉价航空更严：件数、重量、尺寸都会卡',
      '充电宝只能手提，不能托运，且有限额',
      '液体单瓶一般不超过 100ml（国际线更严格）',
    ],

    paxList: [
      { key: 'adult', label: '🧑 成人' },
      { key: 'child', label: '🧒 儿童 2-12 岁' },
      { key: 'infant', label: '👶 婴儿（<2 岁）' },
    ],
    pax: { adult: 1, child: 0, infant: 0 },
    segMode: 'oneway',
    fuelFee: '20',
    fuelResult: null,

    tzCities: TIMEZONES,
    tzCityIdx: 0,
    tzDate: '',
    tzTime: '',
    tzResult: null,

    faqArticle: null,
    memberDayOpen: false,
    memberDays: [
      { name: '中国国航', day: '每月「同月同日」(1/1、2/2…12/12)' },
      { name: '南方航空', day: '每月 28 日' },
      { name: '海南航空', day: '每月 8 日' },
      { name: '厦门航空', day: '每月 9 日' },
      { name: '深圳航空', day: '每月 12 日' },
      { name: '四川航空', day: '每月 19 日' },
      { name: '吉祥航空', day: '每月 25 日' },
      { name: '春秋航空', day: '每月 27 日' },
      { name: '东方航空', day: '每月 9 日（另有资料称 18 日，以官方为准）' },
      { name: '长龙航空', day: '每月 6 日（以官方公告为准）' },
      { name: '华夏航空', day: '每月 25 日（以官方公告为准）' },
      { name: '西藏航空', day: '每月「同月同日」（以官方公告为准）' },
      { name: '中国联合航空', day: '每周五 12:00 秒杀（周常活动）' },
      { name: '山东航空', day: '暂无公开固定会员日，关注官方渠道' },
      { name: '成都航空', day: '暂无公开固定会员日，关注官方渠道' },
      { name: '首都航空', day: '暂无公开固定会员日（海航系，可关注 8 日）' },
    ],
  },

  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    const tab = ['refund', 'baggage', 'fuel', 'time'].indexOf(options.tab) > -1 ? options.tab : 'refund';
    this.setData({ tab });
  },

  switchTab(e) {
    tap('calc_tab', { tab: e.currentTarget.dataset.tab });
    haptic.light();
    this.setData({ tab: e.currentTarget.dataset.tab });
  },

  /* ---------- 退改签 ---------- */
  onCabin(e) {
    tap('calc_input', { field: 'cabin' });
    this.setData({ cabinIdx: Number(e.detail.value) }, () => this.computeRefund());
  },

  onTier(e) {
    tap('calc_input', { field: 'tier' });
    this.setData({ tierIdx: Number(e.detail.value) }, () => this.computeRefund());
  },

  onPrice(e) {
    tap('calc_input', { field: 'price' });
    this.setData({ price: e.detail.value }, () => this.computeRefund());
  },

  computeRefund() {
    const p = parseFloat(this.data.price);
    if (!(p > 0)) {
      this.setData({ refundResult: null });
      return;
    }
    const pct = PCTS[this.data.cabinIdx][this.data.tierIdx];
    this.setData({
      refundResult: {
        pct,
        fee: pct > 0 ? round2((p * pct) / 100).toFixed(2) : '0.00',
        maybeZero: pct === 0,
      },
    });
  },

  /* ---------- 行李超重 ---------- */
  onFreeKg(e) {
    tap('calc_input', { field: 'freeKg' });
    this.setData({ freeKg: e.detail.value }, () => this.computeBag());
  },

  onActualKg(e) {
    tap('calc_input', { field: 'actualKg' });
    this.setData({ actualKg: e.detail.value }, () => this.computeBag());
  },

  onFullPrice(e) {
    tap('calc_input', { field: 'fullPrice' });
    this.setData({ fullPrice: e.detail.value }, () => this.computeBag());
  },

  /** 不知道全价时：按航线距离一键填入常见参考价 */
  setPricePreset(e) {
    const price = e.currentTarget.dataset.price;
    tap('calc_preset_fullprice', { price });
    this.setData({ fullPrice: String(price) }, () => this.computeBag());
    wx.showToast({
      title: '已按参考价估算，可在上方改成实际全价',
      icon: 'none',
      duration: 2000,
    });
  },

  computeBag() {
    const free = parseFloat(this.data.freeKg);
    const actual = parseFloat(this.data.actualKg);
    const price = parseFloat(this.data.fullPrice);
    if (!(actual > 0) || !(price > 0)) {
      this.setData({ bagResult: null });
      return;
    }
    const over = round2(actual - (free > 0 ? free : 0));
    if (over <= 0) {
      this.setData({ bagResult: { over: 0, fee: '0' } });
      return;
    }
    // 0.015 = 1.5%：行李超重费按票面价 1.5%/公斤为常见估算费率，各航司规则不同（UI 已标注仅供参考）
    const feeNum = round2(over * price * 0.015);

    // 按全价档位给出常见的每公斤费率区间（短/中/长航线），便于对照
    let range = '';
    const rates = price <= 1300 ? [12, 22] : price <= 1900 ? [18, 30] : [27, 45];
    const low = Math.round(over * rates[0]);
    const high = Math.round(over * rates[1]);
    range = low + '～' + high;

    // 提前在线加购 vs 机场柜台：柜台通常贵得多，提前买普遍能省三四成
    const online = round2(feeNum * 0.6);
    const save = round2(feeNum - online);

    this.setData({
      bagResult: {
        over,
        fee: feeNum.toFixed(2),
        range,
        online: online.toFixed(2),
        save: save.toFixed(2),
      },
    });
  },

  /* ---------- 税费速查（机建 + 燃油） ---------- */
  /** 乘客组合增减：adult / child / infant */
  changePax(e) {
    const type = e.currentTarget.dataset.type;
    const delta = Number(e.currentTarget.dataset.delta);
    const cur = Number(this.data.pax[type]) || 0;
    const next = Math.max(0, Math.min(20, cur + delta));
    tap('calc_pax', { type, delta, next });
    this.setData({ ['pax.' + type]: next }, () => this.computeFuel());
  },

  setSegMode(e) {
    const mode = e.currentTarget.dataset.mode || 'oneway';
    tap('calc_input', { field: 'segMode' });
    this.setData({ segMode: mode }, () => this.computeFuel());
  },

  onFuelFee(e) {
    tap('calc_input', { field: 'fuelFee' });
    this.setData({ fuelFee: e.detail.value }, () => this.computeFuel());
  },

  computeFuel() {
    const fuel = parseFloat(this.data.fuelFee);
    if (!(fuel >= 0)) {
      this.setData({ fuelResult: null });
      return;
    }
    const SEG = { oneway: 1, transfer: 2, roundtrip: 2 };
    const SEG_LABEL = { oneway: '单程', transfer: '中转', roundtrip: '往返' };
    const seg = SEG[this.data.segMode] || 1;
    const segLabel = SEG_LABEL[this.data.segMode] || '单程';
    const pax = this.data.pax || {};

    const a = Math.max(0, parseInt(pax.adult, 10) || 0);
    const c = Math.max(0, parseInt(pax.child, 10) || 0);
    const i = Math.max(0, parseInt(pax.infant, 10) || 0);

    // 单人单段：成人 燃油+机建；儿童 燃油半价、机建免；婴儿 全免
    // 注意：婴儿真实规则多为「免机建但仍收 10% 燃油」，此处按全免属保守近似，避免高估被坑金额；UI 已标注仅供参考
    const adultFee = round2(fuel + 50);
    const childFee = round2(fuel / 2);
    const infantFee = 0;

    const perSeg = a * adultFee + c * childFee + i * infantFee;
    const total = round2(perSeg * seg).toFixed(2);
    const heads = a + c + i;
    const perHead = heads ? round2((perSeg * seg) / heads).toFixed(2) : '0';

    const parts = [];
    if (a) parts.push('成人 ' + a + ' × ¥' + adultFee);
    if (c) parts.push('儿童 ' + c + ' × ¥' + childFee);
    if (i) parts.push('婴儿 ' + i + ' × ¥0');
    const detail = parts.length
      ? parts.join('  +  ') + '　× ' + seg + ' 航段（' + segLabel + '）'
      : '请添加乘客（点右侧 ＋）';

    this.setData({
      fuelResult: {
        total,
        detail,
        perHead,
        infantFree: i > 0,
        segText: seg > 1 ? '（含 ' + seg + ' 航段）' : '',
      },
    });
  },

  /* ---------- 常见问题：复用避坑指南文章 ID 弹层 ---------- */
  openFaq(e) {
    const id = e.currentTarget.dataset.id;
    tap('faq_open', { id });
    haptic.light();
    let article = null;
    for (const sec of SECTIONS) {
      const found = sec.items.find((it) => it.id === id);
      if (found) {
        article = found;
        break;
      }
    }
    if (!article) {
      wx.showToast({ title: '内容不存在', icon: 'none' });
      return;
    }
    this.setData({ faqArticle: article });
  },

  closeFaq() {
    tap('faq_close');
    this.setData({ faqArticle: null });
  },

  /* ---------- 航司会员日速查 ---------- */
  openMemberDay() {
    tap('member_day_open');
    haptic.light();
    this.setData({ memberDayOpen: true });
  },

  closeMemberDay() {
    this.setData({ memberDayOpen: false });
  },

  noop() {},

  /* ---------- 时差计算器 ---------- */
  onTzCity(e) {
    const idx = Number(e.detail.value);
    this.setData({ tzCityIdx: idx }, () => this.computeTz());
  },
  onTzDate(e) {
    this.setData({ tzDate: e.detail.value }, () => this.computeTz());
  },
  onTzTime(e) {
    this.setData({ tzTime: e.detail.value }, () => this.computeTz());
  },
  computeTz() {
    const city = TIMEZONES[this.data.tzCityIdx];
    const offset = city.utc - 8;
    const date = this.data.tzDate;
    const time = this.data.tzTime;
    if (!date || !time) {
      this.setData({ tzResult: null });
      return;
    }
    // 锚定北京时间（+08:00）：不写时区时按设备本地时区解析，用户手机非东八区会算错基准
    const base = new Date(date + 'T' + time + ':00+08:00');
    if (isNaN(base.getTime())) {
      this.setData({ tzResult: null });
      return;
    }
    const local = new Date(base.getTime() + offset * 3600 * 1000);
    const pad = (n) => (n < 10 ? '0' : '') + n;
    const wd = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][local.getDay()];
    const localStr = local.getFullYear() + '-' + pad(local.getMonth() + 1) + '-' + pad(local.getDate()) + ' ' + wd + ' ' + pad(local.getHours()) + ':' + pad(local.getMinutes());

    // 半时区友好显示（如印度 -2.5 → 慢 2 小时 30 分钟）；同一时区显示"无时差"
    const abs = Math.abs(offset);
    const hh = Math.floor(abs);
    const mm = Math.round((abs - hh) * 60);
    let diffText = '与北京无时差';
    if (offset !== 0) {
      let t = '';
      if (hh) t += hh + ' 小时';
      if (mm) t += (hh ? ' ' : '') + mm + ' 分钟';
      diffText = (offset > 0 ? '快' : '慢') + t;
    }

    this.setData({
      tzResult: {
        city: city.city,
        localStr,
        diff: diffText,
        climate: city.climate || '',
        dst: DST_CITIES.has(city.city),
        crossDay: local.getDate() !== base.getDate() || local.getMonth() !== base.getMonth() || local.getFullYear() !== base.getFullYear(),
      },
    });
  },

  onTabItemTap(e) {
    track('tab_switch', { page: e.pagePath });
  },
  onShareAppMessage() {
    return share.appMessage({ title: '机票退改、行李超重、税费一键算，出行前先避坑', path: '/pages/calc/calc?tab=' + this.data.tab });
  },
  onShareTimeline() {
    return share.timeline({ title: '机票退改、行李超重一键算，出行前先避坑' });
  },
});
