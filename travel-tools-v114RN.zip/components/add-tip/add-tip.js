// 添加到「我的小程序」引导条（全局常驻，可关闭）
// 逻辑：已添加则自动隐藏；未添加则显示；点 × 关闭后本地记住不再提示。
// 低版本不支持 checkIsAddedToMyMiniProgram 时降级为始终显示（可关闭）。
Component({
  data: { show: false },

  lifetimes: {
    attached() { this.check(); },
  },

  pageLifetimes: {
    show() { this.check(); },
  },

  methods: {
    check() {
      if (wx.getStorageSync('addTipDismissed')) {
        this.setData({ show: false });
        return;
      }
      if (!wx.canIUse('checkIsAddedToMyMiniProgram')) {
        this.setData({ show: true });
        return;
      }
      wx.checkIsAddedToMyMiniProgram({
        success: (res) => { this.setData({ show: !res.added }); },
        fail: () => { this.setData({ show: true }); },
      });
    },

    close() {
      wx.setStorageSync('addTipDismissed', true);
      this.setData({ show: false });
    },
  },
});
