/**
 * 用户隐私保护授权弹窗
 * ------------------------------------------------------------
 * 覆盖两条触发路径：
 *   1) 页面加载时：wx.getPrivacySetting 检测到还未授权 → 主动弹出
 *   2) 调用隐私接口（剪贴板）时被拦截 → App.onNeedPrivacyAuthorization 回调 → 由本组件 show(resolve) 弹出
 * 注意：需在 mp 后台「设置 → 服务内容声明 → 用户隐私保护指引」提交并审核通过后才会真正生效。
 */
Component({
  data: {
    show: false,
    privacyName: '用户隐私保护指引',
  },
  lifetimes: {
    attached() {
      this.checkPrivacy();
    },
  },
  methods: {
    checkPrivacy() {
      if (typeof wx.getPrivacySetting !== 'function') return;
      wx.getPrivacySetting({
        success: (res) => {
          if (res.needAuthorization) {
            this.setData({
              show: true,
              // 接口返回空字符串时也要回退默认名，否则页面渲染出《》空名称
              privacyName: res.privacyContractName || '用户隐私保护指引',
            });
          }
        },
        fail: () => {},
      });
    },

    /** 由 App.onNeedPrivacyAuthorization 调用 */
    show(resolve) {
      this.resolve = resolve || null;
      this.setData({ show: true });
    },

    noop() {},

    openContract() {
      if (typeof wx.openPrivacyContract === 'function') {
        wx.openPrivacyContract({
          fail: () => {},
        });
      }
    },

    onAgree() {
      this.setData({ show: false });
      if (typeof this.resolve === 'function') {
        this.resolve({ buttonId: 'agree-btn', event: 'agree' });
        this.resolve = null;
      }
    },

    onDisagree() {
      this.setData({ show: false });
      if (typeof this.resolve === 'function') {
        this.resolve({ event: 'disagree' });
        this.resolve = null;
      }
    },
  },
});
