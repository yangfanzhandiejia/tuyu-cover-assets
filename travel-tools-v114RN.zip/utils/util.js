/** 日期格式化工具 */

function pad(n) {
  return n < 10 ? '0' + n : '' + n;
}

/** 今天，YYYY-MM-DD */
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** '2026-10-09' -> '2026年10月9日' */
function cnDate(s) {
  if (!s) return '';
  const parts = s.split('-');
  if (parts.length < 3) return s;
  return `${parts[0]}年${parseInt(parts[1], 10)}月${parseInt(parts[2], 10)}日`;
}

/** Date -> 'YYYY-MM-DD' */
function fmt(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** 与今天相差的天数（target - today），传入 'YYYY-MM-DD' */
function diffDays(target) {
  const t = new Date(today() + 'T00:00:00');
  const g = new Date(target + 'T00:00:00');
  return Math.round((g - t) / 86400000);
}

module.exports = { today, cnDate, fmt, diffDays };
