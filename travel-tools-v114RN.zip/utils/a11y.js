// 无障碍字号放大（Behavior 方案）
// 档位存 storage key 'a11y_font_scale'：'normal' | 'large' | 'xlarge'（默认 normal）。
// 每个页面 Page({ behaviors: [a11y.a11yBehavior] }) + wxml 根 view class 挂 {{fontScaleClass}}，
// app.wxss 里 .font-large / .font-xlarge 覆盖正文字号（由 gen_font_scale.py 生成维护）。
// 用户在 about 页切换档位后，各页 pageLifetimes.show 自动刷新，无需手动同步。
const KEY = 'a11y_font_scale';

function readScale() {
  let v = '';
  try { v = wx.getStorageSync(KEY) || ''; } catch (e) { v = ''; }
  return (v === 'large' || v === 'xlarge') ? 'font-' + v : '';
}

const a11yBehavior = Behavior({
  data: {
    fontScaleClass: '',
  },
  pageLifetimes: {
    show() {
      const c = readScale();
      if (this.data.fontScaleClass !== c) this.setData({ fontScaleClass: c });
    },
  },
});

module.exports = { KEY, readScale, a11yBehavior };
