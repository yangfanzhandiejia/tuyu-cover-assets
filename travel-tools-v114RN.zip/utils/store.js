/**
 * 本地存储工具：行程 & 渠道收藏 & 攻略收藏 & 出行档案
 * ------------------------------------------------------------
 * 所有读写都走 safeGet / safeSet：
 *   - safeSet 写入后会【回读校验】，写失败会 console.error 出真实原因
 *     （之前失败被静默吞掉，用户看不到任何提示，问题极难排查）
 *   - safeGet 读失败打印一次错误后返回兜底值，不刷屏
 * 第二步接云开发时，可扩展为「云数据库 + 本地缓存」双写。
 */
const TRIPS_KEY = 'tt_trips';
const FAV_KEY = 'tt_fav_channels';
const CK_KEY = 'tt_checklist';
const CK_CUSTOM_KEY = 'tt_checklist_custom';
const CK_LAST_KEY = 'tt_checklist_last';
const CURRENT_KEY = 'tt_current'; // 最近一次选择的路线（首页 ⇄ / 购票渠道页共用）
const FAV_GUIDE_KEY = 'tt_fav_guides';   // 攻略收藏（文章 id 列表）
const RECENT_GUIDE_KEY = 'tt_recent_guides'; // 最近阅读（文章 id 列表，新的在前）
const ARCHIVE_KEY = 'tt_archive';           // 出行档案（已完成的行程，用于年度报告）

const _warned = {};   // 同一 key 的错误只打印一次，避免刷屏

function safeGet(key, fallback) {
  try {
    const v = wx.getStorageSync(key);
    return v === '' || v === undefined || v === null ? fallback : v;
  } catch (e) {
    if (!_warned[key]) {
      _warned[key] = 1;
      console.error('[store] 读取失败', key, e);
    }
    return fallback;
  }
}

/** 写入并回读校验；返回是否真正写成功 */
function safeSet(key, value) {
  try {
    wx.setStorageSync(key, value);
    const back = wx.getStorageSync(key);
    // 回读为空视为失败（某些环境写入静默丢失）
    if (back === '' || back === undefined || back === null) {
      console.error('[store] 写入回读为空', key, JSON.stringify(value));
      return false;
    }
    return true;
  } catch (e) {
    console.error('[store] 写入失败', key, e && e.message ? e.message : e);
    return false;
  }
}

function getTrips() {
  const v = safeGet(TRIPS_KEY, []);
  return Array.isArray(v) ? v : [];
}

function saveTrip(trip) {
  const list = getTrips();
  list.unshift({
    id: 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    createdAt: Date.now(),
    ...trip,
  });
  if (!safeSet(TRIPS_KEY, list)) {
    wx.showToast({ title: '保存失败：本地存储异常，请重启小程序重试', icon: 'none', duration: 3000 });
  }
  return list;
}

function removeTrip(id) {
  const list = getTrips().filter((t) => t.id !== id);
  safeSet(TRIPS_KEY, list);
  return list;
}

function getFavs() {
  const v = safeGet(FAV_KEY, []);
  return Array.isArray(v) ? v : [];
}

function toggleFav(id) {
  let favs = getFavs();
  if (favs.indexOf(id) > -1) {
    favs = favs.filter((f) => f !== id);
  } else {
    favs.push(id);
  }
  safeSet(FAV_KEY, favs);
  return favs;
}

function getCurrent() {
  return safeGet(CURRENT_KEY, null);
}

function saveCurrent(trip) {
  safeSet(CURRENT_KEY, trip);
  return trip;
}

/** 常用路线：从历史行程里按「出发地-目的地」去重，取最近 N 条 */
function getRecentRoutes(limit) {
  const n = limit || 3;
  const trips = getTrips();
  const seen = {};
  const routes = [];
  trips.forEach((t) => {
    if (!t.from || !t.to) return;
    const key = t.from + '-' + t.to;
    if (seen[key]) return;
    seen[key] = 1;
    routes.push({ key, from: t.from, to: t.to, type: t.type || 'flight', typeLabel: t.typeLabel || '' });
    if (routes.length >= n) return;
  });
  return routes;
}

/** ---------- 出行档案（已完成的行程） ---------- */
function getArchive() {
  const v = safeGet(ARCHIVE_KEY, []);
  return Array.isArray(v) ? v : [];
}

/** 把一条行程标记为已完成并归档；返回 { trips, archive } */
function archiveTrip(id) {
  const trips = getTrips();
  const hit = trips.find((t) => t.id === id);
  if (!hit) return { trips, archive: getArchive() };
  const rest = trips.filter((t) => t.id !== id);
  safeSet(TRIPS_KEY, rest);
  const archive = getArchive();
  archive.unshift(Object.assign({}, hit, { doneAt: Date.now() }));
  safeSet(ARCHIVE_KEY, archive);
  return { trips: rest, archive };
}

function removeArchive(id) {
  const list = getArchive().filter((t) => t.id !== id);
  safeSet(ARCHIVE_KEY, list);
  return list;
}

function clearArchive() {
  safeSet(ARCHIVE_KEY, []);
  return [];
}

/** ---------- 攻略收藏 ---------- */
function getGuideFavs() {
  const v = safeGet(FAV_GUIDE_KEY, []);
  return Array.isArray(v) ? v : [];
}

function isGuideFav(id) {
  return getGuideFavs().indexOf(id) > -1;
}

function toggleGuideFav(id) {
  let list = getGuideFavs();
  if (list.indexOf(id) > -1) {
    list = list.filter((x) => x !== id);
  } else {
    list.push(id);
  }
  if (!safeSet(FAV_GUIDE_KEY, list)) {
    wx.showToast({ title: '收藏失败：本地存储异常，请重启小程序重试', icon: 'none', duration: 3000 });
  }
  return list;
}

/** ---------- 最近阅读 ---------- */
function getRecentGuides() {
  const v = safeGet(RECENT_GUIDE_KEY, []);
  return Array.isArray(v) ? v : [];
}

function pushRecentGuide(id) {
  if (!id) return getRecentGuides();
  let list = getRecentGuides().filter((x) => x !== id);
  list.unshift(id);
  list = list.slice(0, 10);
  safeSet(RECENT_GUIDE_KEY, list);
  return list;
}

/* ---------- 清单（打包/自定义物品/上次场景） ---------- */
function getChecklist() {
  const v = safeGet(CK_KEY, {});
  return v && typeof v === 'object' ? v : {};
}

function saveChecklist(obj) {
  safeSet(CK_KEY, obj || {});
}

/** 自定义物品：{ 场景key: [{ name }] } */
function getCustomItems() {
  const v = safeGet(CK_CUSTOM_KEY, {});
  return v && typeof v === 'object' ? v : {};
}

function saveCustomItems(obj) {
  safeSet(CK_CUSTOM_KEY, obj || {});
}

/** 上次使用的清单场景 */
function getLastTpl() {
  return safeGet(CK_LAST_KEY, '') || '';
}

function saveLastTpl(key) {
  safeSet(CK_LAST_KEY, key || '');
}

module.exports = { getChecklist, saveChecklist, getCustomItems, saveCustomItems, getLastTpl, saveLastTpl,
  getTrips, saveTrip, removeTrip,
  getFavs, toggleFav,
  getCurrent, saveCurrent,
  getRecentRoutes,
  getGuideFavs, isGuideFav, toggleGuideFav,
  getRecentGuides, pushRecentGuide,
  getArchive, archiveTrip, removeArchive, clearArchive,
};
