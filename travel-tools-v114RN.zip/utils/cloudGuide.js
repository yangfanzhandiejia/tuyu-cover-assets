// utils/cloudGuide.js
// 统一的避坑指南内容加载：优先云端（微信云开发数据库），失败回退本地打包数据。
// 这样你后续在云数据库里改文章，无需重新发版即可生效；没开通云开发时也能正常显示。
const { SECTIONS } = require('../data/guides');

// 是否具备调用云端的条件（开关打开 + 已填环境 ID + 基础库支持）
function cloudReady() {
  const app = getApp();
  return !!(
    app &&
    app.globalData &&
    app.globalData.useCloud &&
    app.globalData.cloudEnv &&
    wx.cloud &&
    wx.cloud.callFunction
  );
}

// 返回文章板块数组（Promise）
function loadSections() {
  return new Promise((resolve) => {
    if (!cloudReady()) {
      return resolve(SECTIONS);
    }
    wx.cloud
      .callFunction({ name: 'getGuides' })
      .then((res) => {
        const r = (res && res.result) || {};
        if (r.ok && Array.isArray(r.sections) && r.sections.length) {
          resolve(r.sections);
        } else {
          resolve(SECTIONS);
        }
      })
      .catch(() => resolve(SECTIONS));
  });
}

// 在板块数组里按文章 id 查找
// 防御：若第一个参数传成了字符串（说明调用方少传了 sections），自动纠正为 (id) 单参调用
function findArticle(sections, id) {
  if (typeof sections === 'string') {
    id = sections;
    sections = null;
  }
  const list = sections && sections.length ? sections : SECTIONS;
  for (const sec of list) {
    const found = sec.items.find((it) => it.id === id);
    if (found) return found;
  }
  return null;
}

/** 按 id 列表批量查找文章（保持传入顺序，供收藏 / 最近阅读使用） */
function findArticles(sections, ids) {
  if (typeof sections === 'string') {
    ids = sections;
    sections = null;
  }
  const list = sections && sections.length ? sections : SECTIONS;
  const wanted = Array.isArray(ids) ? ids : [];
  const out = [];
  wanted.forEach((id) => {
    for (const sec of list) {
      const found = sec.items.find((it) => it.id === id);
      if (found) {
        out.push(found);
        return;
      }
    }
  });
  return out;
}

module.exports = { loadSections, findArticle, findArticles, SECTIONS };
