// 横向滚动栏「右侧还有内容」提示的公共逻辑（r11 → r12 修正测量方式）
//
// 背景：场景/地区等多 tab 横滑栏右侧原本齐切，用户不知道右边还能滑
// （实测反馈"好多人以为右边就没有了"）。样式见 app.wxss 的 .xscroll-* 系列。
//
// r12 修正：原实现用 fields({ scrollWidth: true, width: true }) 查 scroll-view——
// 这两个不是 SelectorQuery fields 的合法字段（合法的是 size/rect/scrollOffset/properties 等），
// 回调里取不到值直接 return，导致三页提示全部不渲染（真机实测复现）。
// 现改为查「内层轨道 view 的 size」：轨道是不换行的 inline-flex，其渲染宽度就是内容总宽，
// 与 scroll-view 自身可见宽相减即得最大滚动距离——size 是标准字段，稳定可靠。
//
// 页面接入三步：
//   1. wxml：<view class="xscroll-wrap"> 包住 <scroll-view class="原类名 xscroll" scroll-x bindscroll="onXscroll">，
//      并在 scroll-view 之后加提示层：
//      <view class="xscroll-more {{xscrollEnd ? 'xscroll-more-off' : ''}}" wx:if="{{xscrollMore}}">
//        <view class="xscroll-more-tag"><text class="xscroll-more-ico">›</text><text class="xscroll-more-txt">左滑看更多</text></view>
//      </view>
//   2. js data：xscrollMore: false, xscrollEnd: false
//   3. js：onReady() { xscroll.measure(this, '.tpl-inner'); }、onXscroll(e) { xscroll.handleScroll(this, e); }
//      measure 第二参数传内层轨道元素的选择器（各页不同：.tpl-inner / .rg-inner / .scene-track）。
//
// 说明：onReady 时测量一次；内容不超宽则 xscrollMore 保持 false，提示层不渲染。
// 滑到最右（scrollLeft 达到最大值）时 xscrollEnd 置 true，提示淡出。
// 若页面元素是 wx:if 动态创建/销毁的（如 rights 页按模式切换），切换后需再调一次 measure。

const SEL = '.xscroll';

// 测量横滑栏是否超宽（决定要不要显示提示）。innerSel 为内层轨道元素选择器。
// 任一节点查不到（元素不存在/选择器写错）时静默跳过，提示保持不渲染。
function measure(page, innerSel) {
  if (!innerSel) return;
  wx.createSelectorQuery()
    .select(SEL).fields({ size: true })
    .select(innerSel).fields({ size: true })
    .exec((res) => {
      const sv = res && res[0];
      const inner = res && res[1];
      if (!sv || !sv.width || !inner || !inner.width) return;
      page._xscrollMax = inner.width - sv.width;
      const more = page._xscrollMax > 8;
      if (more !== page.data.xscrollMore) page.setData({ xscrollMore: more });
    });
}

// bindscroll 处理器：滑到最右时置 xscrollEnd，提示淡出
function handleScroll(page, e) {
  if (page._xscrollMax == null) return;
  const end = e.detail.scrollLeft >= page._xscrollMax - 6;
  if (end !== page.data.xscrollEnd) page.setData({ xscrollEnd: end });
}

module.exports = { measure, handleScroll };
