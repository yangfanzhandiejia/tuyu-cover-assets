// 横向滚动栏「右侧还有内容」提示的公共逻辑（r11）
//
// 背景：场景/地区等多 tab 横滑栏右侧原本齐切，用户不知道右边还能滑
// （实测反馈"好多人以为右边就没有了"）。样式见 app.wxss 的 .xscroll-* 系列。
//
// 页面接入三步：
//   1. wxml：<view class="xscroll-wrap"> 包住 <scroll-view class="原类名 xscroll" scroll-x bindscroll="onXscroll">，
//      并在 scroll-view 之后加提示层：
//      <view class="xscroll-more {{xscrollEnd ? 'xscroll-more-off' : ''}}" wx:if="{{xscrollMore}}">
//        <view class="xscroll-more-tag"><text class="xscroll-more-ico">›</text><text class="xscroll-more-txt">左滑看更多</text></view>
//      </view>
//   2. js data：xscrollMore: false, xscrollEnd: false
//   3. js：onReady() { xscroll.measure(this); }、onXscroll(e) { xscroll.handleScroll(this, e); }
//
// 说明：onReady 时测量一次 scrollWidth 与可见宽度；内容不超宽则 xscrollMore 保持 false，
// 提示层不渲染。滑到最右（scrollLeft 达到最大值）时 xscrollEnd 置 true，提示淡出。
// 若页面元素是 wx:if 动态创建/销毁的（如 rights 页按模式切换），切换后需再调一次 measure。

const SEL = '.xscroll';

// 测量横滑栏是否超宽（决定要不要显示提示）。r 为 null（元素不存在）时静默跳过。
function measure(page) {
  wx.createSelectorQuery().select(SEL).fields({ scrollWidth: true, width: true }, (r) => {
    if (!r || !r.width) return;
    page._xscrollMax = r.scrollWidth - r.width;
    const more = page._xscrollMax > 8;
    if (more !== page.data.xscrollMore) page.setData({ xscrollMore: more });
  }).exec();
}

// bindscroll 处理器：滑到最右时置 xscrollEnd，提示淡出
function handleScroll(page, e) {
  if (page._xscrollMax == null) return;
  const end = e.detail.scrollLeft >= page._xscrollMax - 6;
  if (end !== page.data.xscrollEnd) page.setData({ xscrollEnd: end });
}

module.exports = { measure, handleScroll };
