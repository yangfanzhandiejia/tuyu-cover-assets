// utils/ask.js
// 本地「智能问答」：把用户的问题与我们已有的文章内容做关键词匹配，返回最相关的几篇。
// 说明：这是「信息检索」而非「AI 生成内容」，不调用任何大模型、不需要后端，
//      因此不触发微信「深度合成」类目要求，也无需算法备案。
//      优点：答案永远准确（就是我们的文章），不会编造。

const { loadSections } = require('./cloudGuide');

// 疑问词 / 语气词：匹配时剔除，避免"怎么""多少"这类词干扰
const STOP = [
  '请问', '问一下', '我想', '我要', '能不能', '可不可以', '是不是', '有没有',
  '怎么', '怎样', '如何', '什么', '多少', '可以', '需要', '应该', '吗', '呢', '啊',
  '的', '了', '是', '我', '想', '要', '有', '会', '不', '在', '和', '与', '或',
];

// 建成一份扁平的文章索引（含所属板块）
function buildIndex(sections) {
  const docs = [];
  (sections || []).forEach((sec) => {
    (sec.items || []).forEach((it) => {
      const tags = it.tags || [];
      const hay = [
        it.title || '',
        tags.join(' '),
        it.summary || '',
        (it.content || []).join(' '),
      ].join(' ').toLowerCase();
      docs.push({
        id: it.id,
        title: it.title || '',
        summary: it.summary || '',
        tags,
        sectionId: sec.id || '',
        sectionTitle: sec.title || '',
        hay,
        titleL: (it.title || '').toLowerCase(),
      });
    });
  });
  return docs;
}

// 把一句话拆成可匹配的词：整句 + 2 字滑窗
function tokenize(input) {
  if (!input) return [];
  let s = String(input).replace(/[?？，。、！!,.；;\s]+/g, ' ').trim().toLowerCase();
  STOP.forEach((w) => {
    s = s.split(w).join(' ');
  });
  s = s.replace(/\s+/g, ' ').trim();
  if (!s) return [];
  const words = [];
  if (s.length >= 2) words.push(s);                 // 整句
  for (let i = 0; i + 2 <= s.length; i += 1) {      // 2 字滑窗
    const w = s.slice(i, i + 2);
    if (w.length === 2) words.push(w);
  }
  return Array.from(new Set(words));
}

// 检索：给每篇文章打分，返回最相关的若干篇
function search(query, docs, limit) {
  const words = tokenize(query);
  if (!words.length || !docs || !docs.length) return [];
  const scored = [];
  docs.forEach((d) => {
    let score = 0;
    words.forEach((w) => {
      if (d.titleL.indexOf(w) > -1) score += 14;                       // 标题命中，权重最高
      if ((d.tags || []).join(' ').toLowerCase().indexOf(w) > -1) score += 9;
      const n = d.hay.split(w).length - 1;                             // 正文出现次数
      if (n > 0) score += Math.min(n, 5) * 1.6;
    });
    if (score > 0) scored.push({ id: d.id, title: d.title, summary: d.summary, sectionTitle: d.sectionTitle, sectionId: d.sectionId, score });
  });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit || 6);
}

module.exports = { buildIndex, search, tokenize, loadSections };
