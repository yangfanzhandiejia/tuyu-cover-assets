// 攻略板块图统一解析：板块 id → 真实存在的 illust 图名
// 背景：guide.wxml / guide-detail.wxml 按 sec-{{sec.id}}.png 动态拼图，
//       但数据里 140+ 个板块 id 只有 14 张大类图，未命中即渲染层 404。
// 规则：精确白名单 → 前缀映射 → 兜底 general（杜绝 404）
const EXACT = {
  'airport': 1, 'baggage': 1,
  'city-east': 1, 'city-north': 1, 'city-south': 1, 'city-southwest': 1, 'city-traffic': 1,
  'dest': 1, 'elderly': 1, 'flight': 1, 'general': 1, 'highway': 1, 'intl': 1,
  'pet': 1, 'points': 1, 'timing': 1, 'train': 1, 'world': 1,
};
const PFX = {
  airport: 'airport', baggage: 'baggage', dest: 'dest', drive: 'drive',
  elder: 'elderly', elderly: 'elderly', flight: 'flight', general: 'general',
  highway: 'highway', intl: 'intl', pet: 'pet', points: 'points',
  timing: 'timing', train: 'train', world: 'world', chunyun: 'chunyun',
};
function secImgOf(id) {
  if (!id) return 'general';
  if (EXACT[id]) return id;
  const p = String(id).split('-')[0];
  return PFX[p] || 'general';
}
module.exports = { secImgOf };
