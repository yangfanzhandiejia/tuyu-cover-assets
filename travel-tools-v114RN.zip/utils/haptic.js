/**
 * 轻触觉反馈
 * 在关键操作（切换类型、保存、复制、拨打等）时触发一次轻微震动，
 * 让"按下去"有实处。
 * 注意：iOS 受系统限制 wx.vibrateShort 基本不震，主要覆盖安卓；
 * 视觉按压态（hover-class="hov"）已全局兜底，iPhone 上靠变色反馈。
 */
module.exports = {
  light() {
    try {
      if (wx.vibrateShort) wx.vibrateShort({ type: 'light' });
    } catch (e) {
      /* 忽略：设备不支持或用户关闭了系统触感 */
    }
  },
};
