/**
 * 长图文导出：把投诉信 / 攻略文章绘制成竖版长图存相册。
 * - canvas 2d，逻辑宽度固定 750rpx，dpr 适配
 * - 文本自动按宽度换行；单页超 MAX_H 自动分页，分别存入相册
 * - 相册授权被拒时引导 wx.openSetting
 *
 * 页面用法：wxml 放一个隐藏画布 <canvas type="2d" id="exportCanvas" class="export-canvas" />，
 * js 调 exportLongImage({ title, subtitle, ops: [{ type, text }], footer })
 * type: title=大标题 / sub=副标题 / h=小节标题 / p=正文 / meta=弱化小字 / blank=空行
 */

const W = 750;            // 逻辑宽度（rpx 坐标）
const PAD = 44;           // 左右边距
const TOP = 56;           // 顶部边距
const BOTTOM = 56;        // 底部边距
const MAX_H = 1300;       // 单页最大逻辑高度，超出分页（留足 iOS 单 canvas 上限余量）
const LINE_H = 46;        // 正文行高
const GAP_H = 26;         // 小节标题与正文间距
const FOOT_H = 60;        // 页脚高度

const STYLES = {
  title: { font: 'bold 38px sans-serif', lineH: 60, color: '#1f2937' },
  sub: { font: '26px sans-serif', lineH: 44, color: '#6e7889' },
  h: { font: 'bold 30px sans-serif', lineH: 56, color: '#2f8f9e' },
  p: { font: '28px sans-serif', lineH: LINE_H, color: '#333a45' },
  meta: { font: '24px sans-serif', lineH: 40, color: '#9aa4b5' },
};

function styleOf(type) { return STYLES[type] || STYLES.p; }

/** 按 maxWidth 换行（支持 \n 硬换行），返回绘制行数组 */
function wrap(ctx, text, maxWidth) {
  const out = [];
  String(text == null ? '' : text).split('\n').forEach((seg) => {
    if (seg === '') { out.push(''); return; }
    let cur = '';
    for (const ch of seg) {
      const test = cur + ch;
      if (ctx.measureText(test).width > maxWidth && cur) { out.push(cur); cur = ch; }
      else cur = test;
    }
    if (cur) out.push(cur);
  });
  return out;
}

/** 分页：把 ops 铺成页面，每页 { ops: [{type, drawLines}] , isFirst, isLast } */
function paginate(ctx, ops) {
  const maxWidth = W - PAD * 2;
  const pages = [];
  let cur = [];
  let used = TOP + 8;
  ops.forEach((op) => {
    if (op.type === 'blank') {
      if (used + 24 > MAX_H - BOTTOM) { pages.push(cur); cur = []; used = TOP + 8; }
      cur.push({ type: 'blank', drawLines: [''] });
      used += 24;
      return;
    }
    const st = styleOf(op.type);
    ctx.font = st.font;
    const drawLines = wrap(ctx, op.text, maxWidth);
    const h = drawLines.length * st.lineH + (op.type === 'h' ? GAP_H : 0);
    if (used + h > MAX_H - BOTTOM - FOOT_H && cur.length) {
      pages.push(cur);
      cur = [];
      used = TOP + 8;
    }
    cur.push({ type: op.type, drawLines, st });
    used += h;
  });
  if (cur.length) pages.push(cur);
  return pages;
}

/** 画一页；返回该页 tempFilePath */
function drawPage(canvas, ctx, dpr, pageOps, opts, pageIdx, pageCount) {
  const st = styleOf('p');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  // 先铺白底（分页复用同一 canvas，必须重绘背景）
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, MAX_H);
  let y = TOP;

  // 每页都带标题（分页后每张独立成图，缺标题会看不懂）
  if (opts.title) {
    ctx.font = STYLES.title.font;
    ctx.fillStyle = STYLES.title.color;
    ctx.textBaseline = 'top';
    const tLines = wrap(ctx, opts.title, W - PAD * 2);
    tLines.forEach((l) => { ctx.fillText(l, PAD, y); y += STYLES.title.lineH; });
    // 标题下分隔线
    ctx.strokeStyle = '#2f8f9e';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(PAD, y + 6);
    ctx.lineTo(W - PAD, y + 6);
    ctx.stroke();
    y += 30;
  }
  if (opts.subtitle) {
    ctx.font = STYLES.sub.font;
    ctx.fillStyle = STYLES.sub.color;
    ctx.fillText(opts.subtitle, PAD, y);
    y += STYLES.sub.lineH + 10;
  }

  pageOps.forEach((op) => {
    if (op.type === 'blank') { y += 24; return; }
    if (op.type === 'h') y += GAP_H;
    ctx.font = op.st.font;
    ctx.fillStyle = op.st.color;
    ctx.textBaseline = 'top';
    op.drawLines.forEach((l) => {
      if (l) ctx.fillText(l, PAD, y);
      y += op.st.lineH;
    });
  });

  // 页脚：品牌 + 分页标记
  ctx.font = STYLES.meta.font;
  ctx.fillStyle = STYLES.meta.color;
  const foot = opts.footer || '途悦出行防坑 · 内容仅供参考，以官方为准';
  const footText = pageCount > 1 ? foot + '（第 ' + (pageIdx + 1) + '/' + pageCount + ' 页）' : foot;
  ctx.fillText(footText, PAD, MAX_H - BOTTOM - 20);

  return new Promise((resolve, reject) => {
    wx.canvasToTempFilePath({
      canvas,
      fileType: 'png',
      success: (r) => resolve(r.tempFilePath),
      fail: reject,
    });
  });
}

/**
 * 导出长图并存相册。
 * @returns Promise<number> 实际保存的页数
 */
function exportLongImage(opts) {
  return new Promise((resolve, reject) => {
    const query = wx.createSelectorQuery();
    query.select('#exportCanvas').fields({ node: true }).exec(async (res) => {
      try {
        const canvas = res[0].node;
        const ctx = canvas.getContext('2d');
        const dpr = wx.getSystemInfoSync().pixelRatio || 2;
        canvas.width = W * dpr;
        canvas.height = MAX_H * dpr;

        // 第一遍：分页
        const pages = paginate(ctx, opts.ops || []);
        if (!pages.length) { resolve(0); return; }
        const total = pages.length;

        // 逐页渲染 + 存相册
        for (let i = 0; i < total; i++) {
          const filePath = await drawPage(canvas, ctx, dpr, pages[i], opts, i, total);
          // eslint-disable-next-line no-await-in-loop
          await saveToAlbum(filePath);
        }
        resolve(total);
      } catch (err) {
        reject(err);
      }
    });
  });
}

/** 存相册；授权被拒时引导去设置（最多引导一次，仍拒绝则抛错） */
function saveToAlbum(filePath) {
  return new Promise((resolve, reject) => {
    wx.saveImageToPhotosAlbum({
      filePath,
      success: () => resolve(),
      fail: (err) => {
        if (err && /auth|deny|authoriz/i.test(err.errMsg || '')) {
          wx.showModal({
            title: '需要相册权限',
            content: '保存长图需要你授权使用相册，去设置里打开「保存到相册」即可。',
            confirmText: '去设置',
            success: (m) => {
              if (!m.confirm) { reject(err); return; }
              wx.openSetting({
                success: (s) => {
                  if (s.authSetting['scope.writePhotosAlbum']) {
                    wx.saveImageToPhotosAlbum({ filePath, success: () => resolve(), fail: reject });
                  } else reject(err);
                },
                fail: reject,
              });
            },
          });
        } else reject(err);
      },
    });
  });
}

module.exports = { exportLongImage, W, MAX_H };
