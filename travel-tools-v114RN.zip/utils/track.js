/**
 * 数据埋点（Mock 接口 / 假后台）
 * ------------------------------------------------------------
 * 当前阶段：纯本地「假接口」。点击行为只记录到：
 *   1) 开发者工具 Console（便于开发期观察）
 *   2) 本地 Storage（key: tt_track_events，最近 200 条，便于调试）
 * 不发送任何真实网络请求。
 *
 * 后续接入微信官方数据分析，只需改 send() 一处：
 *   - 方案 A（推荐，免服务器）：微信「自定义分析」
 *       wx.reportAnalytics(event, data);
 *       并在 MP 后台「数据分析 → 自定义分析」中配置同名的事件与字段。
 *   - 方案 B（自建后台）：
 *       wx.request({ url: 'https://your.api/track', method: 'POST', data: { event, ...payload } });
 *
 * 用法：
 *   const { track, tap } = require('../../utils/track');
 *   track('save_trip', { type: 'flight' });   // 通用事件
 *   tap('btn_save_trip');                       // 按钮点击快捷写法 = track('tap_btn_save_trip')
 */

const STORE_KEY = 'tt_track_events';
const MAX_LOG = 200;          // 本地最多保留多少条
const ENABLED = true;         // 上线前若不想打点，改 false 即可整体关闭

function readLog() {
  try {
    return wx.getStorageSync(STORE_KEY) || [];
  } catch (e) {
    return [];
  }
}

function writeLog(list) {
  try {
    wx.setStorageSync(STORE_KEY, list.slice(-MAX_LOG));
  } catch (e) {
    /* ignore */
  }
}

/**
 * 上报白名单：只把关键事件发到微信「自定义分析」（免费、免服务器、免域名）。
 * 其余几十个事件仍只记本地，避免后台事件泛滥。
 *
 * 需要在 We分析 后台「数据管理 → 事件管理」里新建同名的 5 个事件：
 *   save_trip / tap_channel / open_checklist / open_ask / share
 * 未配置的事件调用会静默失败，不影响小程序正常运行。
 */
const REPORT_MAP = {
  tap_save_trip: 'save_trip',              // 保存行程（最关键：有人在用）
  tap_tap_channel_index: 'tap_channel',    // 首页渠道墙点击
  tap_tap_channel: 'tap_channel',          // 购票渠道页点击
  tap_go_checklist: 'open_checklist',      // 打开打包清单
  tap_go_ask: 'open_ask',                  // 打开智能问答
  share_index: 'share',                    // 首页分享
  share_trip_card: 'share',                // 行程卡片分享
  share_trips: 'share',                    // 我的行程分享
  share_guide: 'share',                    // 攻略分享
};

/**
 * 发送：白名单事件上报微信自定义分析 + 本地 console。
 */
function send(event, payload) {
  const name = REPORT_MAP[event];
  if (!name) {
    console.log('[track]', event, payload);
    return;
  }
  // We分析用 wx.reportEvent；老接口 reportAnalytics 作为兜底（基础库兼容）
  try {
    if (typeof wx.reportEvent === 'function') {
      wx.reportEvent(name, { ts: Date.now() });
    } else if (typeof wx.reportAnalytics === 'function') {
      wx.reportAnalytics(name, {});
    }
  } catch (e) {
    /* 后台未配置该事件时静默忽略，不影响使用 */
  }
  console.log('[track]', event, payload);
}

function track(event, data) {
  if (!ENABLED) return;
  const payload = Object.assign({ ts: Date.now() }, data || {});
  send(event, payload);
  const log = readLog();
  log.push({ event, data: payload });
  writeLog(log);
  return payload;
}

/** 按钮点击快捷写法：tap('save_trip') => track('tap_save_trip') */
function tap(name, extra) {
  return track('tap_' + name, extra || {});
}

/** 读取本地埋点记录（调试用） */
function getEvents() {
  return readLog();
}

/** 清空本地埋点记录（调试用） */
function clearEvents() {
  writeLog([]);
}

module.exports = { track, tap, getEvents, clearEvents, send };
