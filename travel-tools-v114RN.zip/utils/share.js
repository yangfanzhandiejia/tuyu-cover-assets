/**
 * 统一分享能力（好友卡片 + 朋友圈）
 * ------------------------------------------------------------
 * 背景：onShareAppMessage / onShareTimeline 曾在 16 个页面重复粘贴，
 * 分享封面一改就要动 16 处、还容易漏。现收敛到本文件，页面只传
 * { title, path / query }，重复代码归零、封面全站一致。
 *
 * 封面规则（已核实微信现行规则）：
 *   - 好友卡片（onShareAppMessage）imageUrl：支持本地路径 → 用本地品牌封面
 *     （零网络依赖，100% 稳定）
 *   - 朋友圈（onShareTimeline）imageUrl：只认 https 网络图，本地路径会被
 *     静默忽略 → 单独用 COVER_TIMELINE（GitHub 仓库 + jsDelivr CDN，
 *     600×480 正好 5:4 朋友圈最佳比例，CDN 缓存一周、微信拉一次即缓存）。
 *     图床若失效仅影响朋友圈单场景，回退默认图，不致命；升级云存储时
 *     只改 COVER_TIMELINE 一处。
 *
 * 用法：
 *   const share = require('../../utils/share');
 *   onShareAppMessage() { return share.appMessage({ title: '...', path: '/pages/x/x?a=1' }); }
 *   onShareTimeline()   { return share.timeline({ title: '...' }); }
 *   // index 页有自己的 canvas 行程图，可传 imageUrl 覆盖默认封面：
 *   onShareAppMessage() { return share.appMessage({ title, path, imageUrl: this.data.shareImg }); }
 */

/**
 * 好友卡片品牌封面（本地路径，微信允许，稳定优先）
 */
const COVER = '/images/share-cover.png';

/**
 * 朋友圈品牌封面（P0-1 修复：微信只认 https 网络图）
 * 托管：GitHub 公开仓库 yangfanzhandiejia/tuyu-cover-assets → jsDelivr CDN
 * 已实测可达（HTTP 200，cache-control 一周）。换图流程：替换仓库内
 * share-cover.png（保持 600×480 5:4）→ 链接不变，全站自动生效。
 */
const COVER_TIMELINE = 'https://cdn.jsdelivr.net/gh/yangfanzhandiejia/tuyu-cover-assets@main/share-cover.png';

/**
 * 好友卡片
 * @param {string} title 分享标题
 * @param {string} path  打开路径（可带 query）
 * @param {string} [imageUrl] 可选，覆盖默认封面（如 canvas 生成的行程图，本地临时路径）
 */
function appMessage({ title, path, imageUrl }) {
  return { title, path, imageUrl: imageUrl || COVER };
}

/**
 * 朋友圈
 * @param {string} title 分享标题
 * @param {string} [query] 页面参数（一般传空串）
 */
function timeline({ title, query }) {
  return { title, query: query || '', imageUrl: COVER_TIMELINE };
}

module.exports = { COVER, COVER_TIMELINE, appMessage, timeline };
