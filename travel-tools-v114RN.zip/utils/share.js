/**
 * 统一分享能力（好友卡片 + 朋友圈）
 * ------------------------------------------------------------
 * 背景：onShareAppMessage / onShareTimeline 曾在 16 个页面重复粘贴，
 * 分享封面一改就要动 16 处、还容易漏。现收敛到本文件，页面只传
 * { title, path / query }，重复代码归零、封面全站一致。
 *
 * 封面规则（全站统一）：好友卡片 + 朋友圈 **共用包内本地封面 COVER**，零网络依赖，100% 稳定。
 *   - 微信 onShareAppMessage / onShareTimeline 的 imageUrl 均支持代码包内本地路径
 *     （/images/share-cover.png，600×480 5:4，朋友圈卡片最佳比例）。
 *   - 早期版本朋友圈依赖 jsDelivr CDN，偶发拉图失败导致卡片无图；本地路径根除该问题。
 *   - 换图流程：替换 src/images/share-cover.png → 重新打包即全站生效，无需改代码。
 *
 * 用法：
 *   const share = require('../../utils/share');
 *   onShareAppMessage() { return share.appMessage({ title: '...', path: '/pages/x/x?a=1' }); }
 *   onShareTimeline()   { return share.timeline({ title: '...' }); }
 *   // index 页有自己的 canvas 行程图，可传 imageUrl 覆盖默认封面：
 *   onShareAppMessage() { return share.appMessage({ title, path, imageUrl: this.data.shareImg }); }
 */

/**
 * 全站统一品牌封面（好友卡片 + 朋友圈共用，包内本地路径，零网络依赖）
 * 600×480 = 5:4，朋友圈卡片最佳比例；好友卡片同样适用。
 */
const COVER = '/images/share-cover.png';

/**
 * 好友卡片
 * @param {string} title 分享标题
 * @param {string} path  打开路径（可带 query）
 * @param {string} [imageUrl] 可选，覆盖默认封面（如 canvas 生成的行程图，本地临时路径）
 */
function appMessage({ title, path, imageUrl }) {
  return { title, path, imageUrl: imageUrl || COVER };
}

/**
 * 朋友圈（与好友卡片共用包内本地封面，不再走 CDN，彻底避免拉图失败）
 * @param {string} title 分享标题
 * @param {string} [query] 页面参数（一般传空串）
 */
function timeline({ title, query }) {
  return { title, query: query || '', imageUrl: COVER };
}

module.exports = { COVER, appMessage, timeline };
