/**
 * 热门内容（从首页归位到「避坑指南」页顶部）
 * ------------------------------------------------------------
 * 首页做减法后，这两块内容统一放在避坑指南页顶部统一展示，
 * 避免首页既要「办事」又要「看内容」导致主流程被淹没。
 */
const { loadSections } = require('../utils/cloudGuide');

/** 热门问题：图标网格，按主题直达 */
const FAQS = [
  { id: 'world-family', name: '带娃', img: 'family' },
  { id: 'flight-baggage-checkin', name: '行李', img: 'baggage' },
  { id: 'world-delay-comp', name: '航班延误', img: 'delay' },
  { id: 'flight-refund-rule', name: '退改签', img: 'refund' },
  { id: 'points-where-to-check', name: '里程积分', img: 'points' },
  { id: 'timing-best-window', name: '省钱时机', img: 'timing' },
];

/** 出行前必看：从内容库中挑出最高价值的几篇 */
const MUST_IDS = [
  'general-refund-rights',   // 第三方退票只退税费
  'baggage-forbidden',       // 不能带上飞机的物品
  'airport-checkin-time',    // 值机/安检提前多久
  'flight-low-price-trap',   // 特价机票陷阱
  'general-refund-scam',     // 退改签诈骗
];

function loadMustRead(cb) {
  loadSections().then((sections) => {
    const all = [];
    (sections || []).forEach((sec) => {
      (sec.items || []).forEach((it) => {
        all.push({ id: it.id, title: it.title, sectionTitle: sec.title });
      });
    });
    const list = MUST_IDS.map((id) => all.find((a) => a.id === id)).filter(Boolean);
    if (typeof cb === 'function') cb(list);
  });
}

module.exports = { FAQS, loadMustRead };
