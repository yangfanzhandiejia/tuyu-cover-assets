/**
 * 出行工具清单（单一数据源）
 * ------------------------------------------------------------
 * 「出行工具」页按此渲染；首页只挑几个做快捷入口，底部「查看全部 N 个工具」
 * 的数量也取自这里，避免两处不一致。
 *
 * 排序与分组原则：应急（出事时找）→ 常用（每次出行用）→ 算一算（按需查）。
 * 注意：费用类（退改签 / 行李 / 税费 / 时差）都在同一个「费用计算」页里用 tab 切换，
 * 所以这里只保留一个入口，避免同一个页面占四行。
 */

const TOOLS = [
  {
    group: 'urgent',
    img: 'delay', title: '航班延误权益', desc: '按原因和时长，算你能要求什么、怎么开口',
    url: '/pages/delay/delay',
  },
  {
    group: 'urgent',
    img: 'rights', title: '维权工具箱', desc: '投诉电话一键拨打 + 现成话术，退票/延误/超售都能用',
    url: '/pages/rights/rights',
  },
  {
    group: 'daily',
    img: 'checklist', title: '出行打包清单', desc: '按场景生成行李清单，逐项勾选不遗漏',
    url: '/pages/checklist/checklist',
  },
  {
    group: 'daily',
    img: 'cityguide', title: '城市交通指南', desc: '24 座城市：机场进城与市内出行怎么走最省',
    url: '/pages/cityguide/cityguide',
  },
  {
    group: 'daily',
    img: 'overseas', title: '出境工具包', desc: '插座要不要转换头、签证免签/落地签、外币换算',
    url: '/pages/overseas/overseas',
  },
  {
    group: 'daily',
    img: 'ask', title: '智能问答', desc: '输入你的出行问题，直接找答案',
    url: '/pages/ask/ask',
  },
  {
    group: 'calc',
    img: 'calc', title: '费用与时差计算', desc: '退改签、行李超重、燃油机建、时差，一个页面里切换着算',
    url: '/pages/calc/calc',
  },
  {
    group: 'calc',
    img: 'transit', title: '中转时间够不够', desc: '按中转类型、是否联程，算出最少要留多久',
    url: '/pages/transit/transit',
  },
  {
    group: 'calc',
    img: 'date', title: '购票 / 值机时间点计算', desc: '火车票开售日、退改节点、值机截止提醒',
    url: '/pages/date/date',
  },
  {
    group: 'calc',
    img: 'drive', title: '自驾计算', desc: '油/电费+过路费、电车续航、限行、行程时长',
    url: '/pages/drive/drive',
  },
];

const GROUPS = [
  { key: 'urgent', title: '出问题了先用这些', sub: '延误、被坑，别自己扛' },
  { key: 'daily', title: '每次出行都用得上', sub: '打包、进城、查问题' },
  { key: 'calc', title: '算一算', sub: '费用、时间、中转够不够' },
];

module.exports = { TOOLS, TOOL_GROUPS: GROUPS };
