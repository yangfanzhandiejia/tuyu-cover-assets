/**
 * 城市交通指南的区域与城市（单一数据源）
 * 「城市交通」页与首页的「目的地交通」推荐卡共用这一份，
 * 保证两处城市一致、不会这边有那边没有。
 */

const REGIONS = [
  {
    key: 'north', name: '华北 · 东北 · 西北',
    cities: [['beijing', '北京'], ['tianjin', '天津'], ['shenyang', '沈阳'], ['harbin', '哈尔滨'],
             ['xian', '西安'], ['dunhuang', '敦煌'], ['lhasa', '拉萨']],
  },
  {
    key: 'east', name: '华东',
    cities: [['shanghai', '上海'], ['hangzhou', '杭州'], ['nanjing', '南京'], ['suzhou', '苏州'],
             ['xiamen', '厦门'], ['qingdao', '青岛']],
  },
  {
    key: 'south', name: '华南 · 华中',
    cities: [['guangzhou', '广州'], ['shenzhen', '深圳'], ['sanya', '三亚'], ['guilin', '桂林'],
             ['changsha', '长沙'], ['wuhan', '武汉']],
  },
  {
    key: 'southwest', name: '西南',
    cities: [['chengdu', '成都'], ['chongqing', '重庆'], ['kunming', '昆明'], ['lijiang', '丽江'],
             ['zhangjiajie', '张家界']],
  },
];

/** 中文城市名 → { key, regionKey }，找不到返回 null（用于首页判断要不要推荐） */
function findCity(name) {
  if (!name) return null;
  const cn = String(name).trim();
  for (let i = 0; i < REGIONS.length; i++) {
    const r = REGIONS[i];
    for (let j = 0; j < r.cities.length; j++) {
      if (r.cities[j][1] === cn) {
        return { key: r.cities[j][0], name: cn, regionKey: r.key };
      }
    }
  }
  return null;
}

module.exports = { REGIONS, findCity };
