/**
 * 渠道数据（第一版：本地数据）
 * ------------------------------------------------------------
 * 【第二步接云开发时】把本文件替换为从云数据库读取的 api.js。
 *
 * ⚠️ appid 字段说明（重要）：
 * 微信官方规则：自 2020-04-24 起，通过 wx.navigateToMiniProgram 跳转其他小程序
 * 已【取消白名单】要求——无需预先声明、跳转数量不限；目标小程序须已发布，
 * 跳转前微信会弹确认框（用户点「允许」才跳）。
 * 已知目标小程序的官方 AppID，填到 appid 字段即可一键直达；
 * appid 为空时，点击卡片会自动复制名称，引导用户到微信搜索官方小程序。
 * 请务必使用官方小程序的真实 AppID。
 *
 * 📌 如何获取官方小程序 AppID（自己补全其他渠道时用）：
 *   1. 在微信里搜索并打开该平台「官方小程序」（认准官方认证标识）
 *   2. 点右上角「···」→ 点小程序名称进入详情页 → 再点右上角「···」→「更多资料」
 *   3. 复制里面的 AppID（wx 开头的一串字符），粘贴到下面对应渠道的 appid 字段
 *
 * ✅ 已配通跳转的渠道（AppID 经核实）：
 *   - 携程旅行   wx0e6ed4f51db9d078   （来源：微信内「携程旅行」小程序「更多资料」页核对，主体「上海携程商务有限公司」企业认证，官方核实）
 *   - 铁路12306  wxa51f55ab3b2655b9   （来源：微信内「铁路12306」小程序「更多资料」页核对，主体「中铁程科技有限责任公司」企业认证，官方核实）
 *   - 飞猪旅行   wx6a96c49f29850eb5   （来源：微信内「飞猪旅行」小程序「更多资料」页核对，主体「杭州淘美航空服务有限公司」企业认证，官方核实）
 *   - 海南航空   wx56dbc76c7b340f86   （来源：微信内「海南航空」小程序「更多资料」页核对，主体「海南航空控股股份有限公司」企业认证+备案号琼ICP备05001792号-5X，官方核实）
 *   - 中国国航   wx366ae41607c228d1   （来源：微信内「中国国际航空」小程序「更多资料」页核对，主体「中国国际航空股份有限公司」企业认证，官方核实）
 *   - 东方航空   wxc1d4e8f52a93da7e   （来源：微信内「中国东方航空」小程序「更多资料」页核对，主体「中国东方航空股份有限公司」企业认证，官方核实）
 *   - 南方航空   wx729238547ac7a14c   （来源：微信内「中国南方航空」小程序「更多资料」页核对，主体「中国南方航空股份有限公司」企业认证，官方核实）
 *   - 深圳航空   wx0ff4e01294eca299   （来源：微信内「深圳航空」小程序「更多资料」页核对，主体「深圳航空有限责任公司」企业认证，官方核实）
 *   - 厦门航空   wxf1c98c0261d2bcf5   （来源：微信内「厦门航空」小程序「更多资料」页核对，主体「厦门航空有限公司」企业认证，官方核实）
 *   - 四川航空   wx96cbe8b2db62b578   （来源：微信内「四川航空」小程序「更多资料」页核对，主体「四川航空股份有限公司」企业认证，官方核实）
 *   - 春秋航空   wx3fc2bf1badc3a129   （来源：微信内「春秋航空」小程序「更多资料」页核对，主体「春秋航空股份有限公司」企业认证，官方核实）
 *   - 吉祥航空   wx534a6f359f266888   （来源：微信内「吉祥航空」小程序「更多资料」页核对，主体「上海吉祥航空股份有限公司」企业认证，官方核实）
 *   - 山东航空   wx5e0b801b20f31d7f   （来源：微信内「山东航空」小程序「更多资料」页核对，主体「山东航空股份有限公司」企业认证，官方核实）
 *   - 长龙航空   wx0a991d42d653886e   （来源：微信内「长龙航空」小程序「更多资料」页核对，主体「浙江长龙航空股份有限公司」企业认证，官方核实）
 *   - 去哪儿旅行 wx799d4d93a341b368   （来源：微信内「去哪儿旅行」小程序「更多资料」页核对，主体「北京嘉信浩远信息技术有限公司」为去哪儿网运营主体北京趣拿100%控股子公司，官方核实）
 *   - 同程旅行   wx336dcaf6a1ecf632   （来源：2026-10-14 真机实测发现旧值跳转失败，改按微信内「同程旅行」小程序「更多资料」页原始ID页核对；主体「同程网络科技股份有限公司」，苏ICP备09033604号-59X）
 *   - 华夏航空   wxf4fb2b1702e14b96   （来源：用户微信内「华夏航空」小程序「更多资料」页截图核对，主体「华夏航空股份有限公司」蓝V认证）
 *   - 成都航空   wx66b913b9a04ebbd0   （来源：用户微信内截图核对，主体「成都航空有限公司」蓝V认证）
 *   - 西藏航空   wx4e033a64f8735d07   （来源：用户微信内截图核对，主体「西藏航空有限公司」蓝V认证）
 *   - 首都航空   wxaf9e9b1ede9e7e0b   （来源：用户微信内截图核对，主体「北京首都航空有限公司」蓝V认证）
 *   - 中国联合航空 wxd8e34a77a8f86936 （来源：用户微信内截图核对，主体「中国联合航空有限公司」蓝V认证）
 * 以上 21 个渠道（5 平台 + 16 航司）的 AppID 均已核实，可直接跳转。
 *
 * 渠道按三组分类：综合平台 / 航空公司 / 火车票。
 */

const CONFIG = require('./config');

const GROUPS = [
  {
    key: 'ota',
    name: '综合平台',
    icon: '🧭',
    color: '#5b6cff',
    desc: '只用于比价参考，出票建议回到航司 / 12306 官方渠道，售后更稳妥',
    channels: [
      { id: 'ctrip', code: '携', deep: '#0a76d6', name: '携程旅行', icon: '🧳', bg: '#e6f3ff', tel: '400-830-6666', appid: 'wx0e6ed4f51db9d078', search: '携程旅行', desc: '机票、火车票预订平台，比价参考用' },
      { id: 'qunar', code: '去', deep: '#0f7f9c', name: '去哪儿旅行', icon: '🔍', bg: '#e3f6fb', tel: '95117', appid: 'wx799d4d93a341b368', search: '去哪儿旅行', desc: '机票、火车票比价查询平台' },
      { id: 'fliggy', code: '飞', deep: '#b8760a', name: '飞猪旅行', icon: '🧭', bg: '#fff3e0', tel: '9510208', appid: 'wx6a96c49f29850eb5', search: '飞猪旅行', desc: '阿里系出行预订平台，可作比价参考' },
      { id: 'tongcheng', code: '同', deep: '#3f4fd1', name: '同程旅行', icon: '📖', bg: '#ebedfd', tel: '95711', appid: 'wx336dcaf6a1ecf632', search: '同程旅行', desc: '机票、火车票预订平台，比价参考用' },
    ],
  },
  {
    key: 'airline',
    name: '航空公司',
    icon: '✈️',
    color: '#2f8f9e',
    desc: '各大航司官方直销渠道，价格透明、售后稳妥',
    channels: [
      { id: 'air-china', code: 'CA', deep: '#c62828', name: '中国国航', icon: '✈️', bg: '#fdeaea', tel: '95583', appid: 'wx366ae41607c228d1', search: '中国国航', desc: '载旗航司，国内国际航线齐全，官方直销有保障' },
      { id: 'china-eastern', code: 'MU', deep: '#d84a10', name: '东方航空', icon: '✈️', bg: '#fff0e8', tel: '95530', appid: 'wxc1d4e8f52a93da7e', search: '东方航空', desc: '上海主基地航司，航线覆盖广，官网/APP 直销' },
      { id: 'china-southern', code: 'CZ', deep: '#1a4fbf', name: '南方航空', icon: '✈️', bg: '#e6eefc', tel: '95539', appid: 'wx729238547ac7a14c', search: '南方航空', desc: '广州主基地航司，国内航线密集，机队规模大' },
      { id: 'hainan', code: 'HU', deep: '#b3183f', name: '海南航空', icon: '✈️', bg: '#fdecef', tel: '95339', appid: 'wx56dbc76c7b340f86', search: '海南航空', desc: '服务口碑较好，国内国际航线丰富' },
      { id: 'xiamen', code: 'MF', deep: '#1a72a8', name: '厦门航空', icon: '✈️', bg: '#e8f4fb', tel: '95557', appid: 'wxf1c98c0261d2bcf5', search: '厦门航空', desc: '华东华南航线丰富，官方渠道购票安心' },
      { id: 'shenzhen', code: 'ZH', deep: '#4b4bc9', name: '深圳航空', icon: '✈️', bg: '#ececfb', tel: '95361', appid: 'wx0ff4e01294eca299', search: '深圳航空', desc: '国航系航司，官方渠道直购更放心' },
      { id: 'sichuan', code: '3U', deep: '#bf3a1a', name: '四川航空', icon: '✈️', bg: '#fdeeea', tel: '95378', appid: 'wx96cbe8b2db62b578', search: '四川航空', desc: '西南地区航线优势明显，官方渠道购票' },
      { id: 'spring', code: '9C', deep: '#1a8f45', name: '春秋航空', icon: '✈️', bg: '#e8f6ec', tel: '95524', appid: 'wx3fc2bf1badc3a129', search: '春秋航空', desc: '廉价航空代表，购票前注意行李额与退改规则' },
      { id: 'juneyao', code: 'HO', deep: '#b58210', name: '吉祥航空', icon: '✈️', bg: '#fdf2e0', tel: '95520', appid: 'wx534a6f359f266888', search: '吉祥航空', desc: '总部上海，国内国际航线丰富，官方直购' },
      { id: 'shandong', code: 'SC', deep: '#2f4bb8', name: '山东航空', icon: '✈️', bg: '#e9eefb', tel: '95369', appid: 'wx5e0b801b20f31d7f', search: '山东航空', desc: '华北华东航线覆盖广，官方渠道购票' },
      { id: 'huaxia', code: 'G5', deep: '#0e8a78', name: '华夏航空', icon: '✈️', bg: '#e6f7f4', tel: '95332', appid: 'wxf4fb2b1702e14b96', search: '华夏航空', desc: '支线航空龙头，三四线城市航线覆盖广' },
      { id: 'chengdu', code: 'EU', deep: '#5a4bd1', name: '成都航空', icon: '✈️', bg: '#eef0fd', tel: '028-66668888', appid: 'wx66b913b9a04ebbd0', search: '成都航空', desc: '国产ARJ21机队规模领先，西南航线丰富' },
      { id: 'tibet', code: 'TV', deep: '#a8322c', name: '西藏航空', icon: '✈️', bg: '#fbeceb', tel: '96222', appid: 'wx4e033a64f8735d07', search: '西藏航空', desc: '高原航线专家，拉萨进出港首选' },
      { id: 'capital', code: 'JD', deep: '#b81f76', name: '首都航空', icon: '✈️', bg: '#fdeaf5', tel: '95375', appid: 'wxaf9e9b1ede9e7e0b', search: '首都航空', desc: '海航系，北京基地，旅游航线较多' },
      { id: 'china-united', code: 'KN', deep: '#2b5c96', name: '中国联合航空', icon: '✈️', bg: '#ebf2fa', tel: '400-102-6666', appid: 'wxd8e34a77a8f86936', search: '中国联合航空', desc: '东航系低成本航司，北京大兴基地' },
      { id: 'loong', code: 'GJ', deep: '#6a2fc0', name: '长龙航空', icon: '✈️', bg: '#f2ebfc', tel: '956199', appid: 'wx0a991d42d653886e', search: '长龙航空', desc: '浙江杭州基地，华东航线日益丰富' },
    ],
  },
  {
    key: 'train',
    name: '火车票',
    icon: '🚄',
    color: '#17a34a',
    desc: '铁路官方及正规购票渠道',
    channels: [
      { id: 'rail-12306', code: '铁', deep: '#0b7d6b', iconImg: 'rail', name: '铁路12306', badge: '官方', icon: '🚄', bg: '#e0f5f0', tel: '12306', appid: 'wxa51f55ab3b2655b9', search: '铁路12306', desc: '铁路官方购票渠道，支持候补购票与学生资质核验' },
    ],
  },
];

function getGroup(key) {
  return GROUPS.find((g) => g.key === key) || GROUPS[0];
}

/**
 * 按后台配置（config.js）过滤出可见的分组。
 * 例如 showAirline=false 时隐藏「航空公司」，show12306=false 时隐藏「火车票 / 12306」。
 */
/**
 * 展示顺序：官方直销（航空公司 / 12306）在前，聚合比价平台在后。
 * 原因：聚合平台是「万能入口」，用户记住一次就不再需要本小程序；
 * 而众多航司各自入口没人记得住，这才是用户每次出行都要回来的理由。
 */
const GROUP_ORDER = ['airline', 'train', 'ota'];

function getVisibleGroups() {
  const list = GROUPS.filter((g) => {
    if (g.key === 'airline') return !!CONFIG.showAirline;
    if (g.key === 'train') return !!CONFIG.show12306;
    return true; // ota 综合平台始终显示
  });
  return list.slice().sort((a, b) => GROUP_ORDER.indexOf(a.key) - GROUP_ORDER.indexOf(b.key));
}

module.exports = { GROUPS, getGroup, getVisibleGroups, CONFIG };
