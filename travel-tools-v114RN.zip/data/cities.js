/**
 * 城市数据（带拼音，用于城市选择器的 A-Z 拼音索引 + 搜索）
 * ------------------------------------------------------------
 * 覆盖：全部省会 / 首府、绝大多数地级市，以及热门旅游目的地
 *       （呼伦贝尔、海拉尔、满洲里、香格里拉、腾冲、稻城、九寨沟、阳朔、婺源…）
 * 数据结构：扁平数组 RAW（name + py 全拼），模块加载时按拼音首字母自动分组排序，
 * 新增城市直接往 RAW 里加 { name, py } 即可，分组会自动完成。
 */

const RAW = [
  // ============ A ============
  { name: '澳门', py: 'aomen' },
  { name: '鞍山', py: 'anshan' }, { name: '安阳', py: 'anyang' },
  { name: '安庆', py: 'anqing' }, { name: '安顺', py: 'anshun' },
  { name: '安康', py: 'ankang' }, { name: '阿克苏', py: 'akesu' },
  { name: '阿坝', py: 'aba' }, { name: '阿拉善', py: 'alashan' },
  { name: '阿尔山', py: 'aershan' }, { name: '阿勒泰', py: 'aletai' },
  // ============ B ============
  { name: '北京', py: 'beijing' }, { name: '保定', py: 'baoding' },
  { name: '包头', py: 'baotou' }, { name: '蚌埠', py: 'bengbu' },
  { name: '北海', py: 'beihai' }, { name: '本溪', py: 'benxi' },
  { name: '宝鸡', py: 'baoji' }, { name: '滨州', py: 'binzhou' },
  { name: '毕节', py: 'bijie' }, { name: '亳州', py: 'bozhou' },
  { name: '百色', py: 'baise' }, { name: '巴中', py: 'bazhong' },
  { name: '保山', py: 'baoshan' }, { name: '白山', py: 'baishan' },
  { name: '白城', py: 'baicheng' }, { name: '白银', py: 'baiyin' },
  { name: '博乐', py: 'bole' },
  // ============ C ============
  { name: '成都', py: 'chengdu' }, { name: '重庆', py: 'chongqing' },
  { name: '长沙', py: 'changsha' }, { name: '长春', py: 'changchun' },
  { name: '常州', py: 'changzhou' }, { name: '沧州', py: 'cangzhou' },
  { name: '承德', py: 'chengde' }, { name: '郴州', py: 'chenzhou' },
  { name: '潮州', py: 'chaozhou' }, { name: '长治', py: 'changzhi' },
  { name: '滁州', py: 'chuzhou' }, { name: '池州', py: 'chizhou' },
  { name: '赤峰', py: 'chifeng' }, { name: '楚雄', py: 'chuxiong' },
  { name: '崇左', py: 'chongzuo' }, { name: '常熟', py: 'changshu' },
  { name: '慈溪', py: 'cixi' },
  // ============ D ============
  { name: '大连', py: 'dalian' }, { name: '东莞', py: 'dongguan' },
  { name: '大同', py: 'datong' }, { name: '丹东', py: 'dandong' },
  { name: '德阳', py: 'deyang' }, { name: '德州', py: 'dezhou' },
  { name: '东营', py: 'dongying' }, { name: '大理', py: 'dali' },
  { name: '大庆', py: 'daqing' }, { name: '达州', py: 'dazhou' },
  { name: '敦煌', py: 'dunhuang' }, { name: '稻城', py: 'daocheng' },
  { name: '德宏', py: 'dehong' }, { name: '迪庆', py: 'diqing' },
  { name: '儋州', py: 'danzhou' }, { name: '定西', py: 'dingxi' },
  // ============ E ============
  { name: '鄂尔多斯', py: 'eerduosi' }, { name: '恩施', py: 'enshi' },
  { name: '鄂州', py: 'ezhou' }, { name: '额济纳', py: 'ejina' },
  { name: '二连浩特', py: 'erlianhaote' },
  // ============ F ============
  { name: '福州', py: 'fuzhou' }, { name: '佛山', py: 'foshan' },
  { name: '抚顺', py: 'fushun' }, { name: '阜阳', py: 'fuyang' },
  { name: '阜新', py: 'fuxin' }, { name: '抚州', py: 'fuzhou2' },
  { name: '福鼎', py: 'fuding' }, { name: '防城港', py: 'fangchenggang' },
  // ============ G ============
  { name: '广州', py: 'guangzhou' }, { name: '桂林', py: 'guilin' },
  { name: '贵阳', py: 'guiyang' }, { name: '赣州', py: 'ganzhou' },
  { name: '广元', py: 'guangyuan' }, { name: '格尔木', py: 'geermu' },
  { name: '广安', py: 'guangan' }, { name: '贵港', py: 'guigang' },
  { name: '固原', py: 'guyuan' }, { name: '果洛', py: 'guoluo' },
  // ============ H ============
  { name: '杭州', py: 'hangzhou' }, { name: '哈尔滨', py: 'haerbin' },
  { name: '海口', py: 'haikou' }, { name: '合肥', py: 'hefei' },
  { name: '呼和浩特', py: 'huhehaote' }, { name: '呼伦贝尔', py: 'hulunbeier' },
  { name: '海拉尔', py: 'hailaer' }, { name: '哈密', py: 'hami' },
  { name: '和田', py: 'hetian' }, { name: '邯郸', py: 'handan' },
  { name: '汉中', py: 'hanzhong' }, { name: '河源', py: 'heyuan' },
  { name: '衡阳', py: 'hengyang' }, { name: '衡水', py: 'hengshui' },
  { name: '菏泽', py: 'heze' }, { name: '淮安', py: 'huaian' },
  { name: '淮北', py: 'huaibei' }, { name: '淮南', py: 'huainan' },
  { name: '黄山', py: 'huangshan' }, { name: '黄冈', py: 'huanggang' },
  { name: '黄石', py: 'huangshi' }, { name: '惠州', py: 'huizhou' },
  { name: '湖州', py: 'huzhou' }, { name: '葫芦岛', py: 'huludao' },
  { name: '黑河', py: 'heihe' }, { name: '鹤岗', py: 'hegang' },
  { name: '红河', py: 'honghe' }, { name: '怀化', py: 'huaihua' },
  { name: '河池', py: 'hechi' }, { name: '海东', py: 'haidong' },
  { name: '海西', py: 'haixi' }, { name: '黄南', py: 'huangnan' },
  { name: '漠河', py: 'mohe' },
  // ============ J ============
  { name: '济南', py: 'jinan' }, { name: '嘉兴', py: 'jiaxing' },
  { name: '金华', py: 'jinhua' }, { name: '景德镇', py: 'jingdezhen' },
  { name: '荆州', py: 'jingzhou' }, { name: '荆门', py: 'jingmen' },
  { name: '九江', py: 'jiujiang' }, { name: '吉林', py: 'jilin' },
  { name: '佳木斯', py: 'jiamusi' }, { name: '济宁', py: 'jining' },
  { name: '焦作', py: 'jiaozuo' }, { name: '锦州', py: 'jinzhou' },
  { name: '晋中', py: 'jinzhong' }, { name: '晋城', py: 'jincheng' },
  { name: '揭阳', py: 'jieyang' }, { name: '江门', py: 'jiangmen' },
  { name: '酒泉', py: 'jiuquan' }, { name: '嘉峪关', py: 'jiayuguan' },
  { name: '金昌', py: 'jinchang' }, { name: '吉安', py: 'jian' },
  { name: '井冈山', py: 'jinggangshan' }, { name: '九寨沟', py: 'jiuzhaigou' },
  { name: '济源', py: 'jiyuan' }, { name: '胶州', py: 'jiaozhou' },
  // ============ K ============
  { name: '昆明', py: 'kunming' }, { name: '喀什', py: 'kashi' },
  { name: '开封', py: 'kaifeng' }, { name: '昆山', py: 'kunshan' },
  { name: '库尔勒', py: 'kuerle' }, { name: '克拉玛依', py: 'kelamayi' },
  { name: '凯里', py: 'kaili' }, { name: '康定', py: 'kangding' },
  { name: '库车', py: 'kuche' },
  // ============ L ============
  { name: '兰州', py: 'lanzhou' }, { name: '洛阳', py: 'luoyang' },
  { name: '廊坊', py: 'langfang' }, { name: '拉萨', py: 'lasa' },
  { name: '丽江', py: 'lijiang' }, { name: '临沂', py: 'linyi' },
  { name: '柳州', py: 'liuzhou' }, { name: '泸州', py: 'luzhou' },
  { name: '连云港', py: 'lianyungang' }, { name: '聊城', py: 'liaocheng' },
  { name: '乐山', py: 'leshan' }, { name: '六安', py: 'luan' },
  { name: '六盘水', py: 'liupanshui' }, { name: '龙岩', py: 'longyan' },
  { name: '漯河', py: 'luohe' }, { name: '娄底', py: 'loudi' },
  { name: '林芝', py: 'linzhi' }, { name: '临沧', py: 'lincang' },
  { name: '临汾', py: 'linfen' }, { name: '来宾', py: 'laibin' },
  { name: '陇南', py: 'longnan' }, { name: '庐山', py: 'lushan' },
  { name: '理塘', py: 'litang' }, { name: '龙口', py: 'longkou' },
  // ============ M ============
  { name: '绵阳', py: 'mianyang' }, { name: '马鞍山', py: 'maanshan' },
  { name: '茂名', py: 'maoming' }, { name: '梅州', py: 'meizhou' },
  { name: '牡丹江', py: 'mudanjiang' }, { name: '满洲里', py: 'manzhouli' },
  { name: '眉山', py: 'meishan' }, { name: '南澳', py: 'nanao' },
  // ============ N ============
  { name: '南京', py: 'nanjing' }, { name: '南宁', py: 'nanning' },
  { name: '南昌', py: 'nanchang' }, { name: '宁波', py: 'ningbo' },
  { name: '南阳', py: 'nanyang' }, { name: '南通', py: 'nantong' },
  { name: '南充', py: 'nanchong' }, { name: '内江', py: 'neijiang' },
  { name: '宁德', py: 'ningde' }, { name: '那曲', py: 'naqu' },
  { name: '怒江', py: 'nujiang' },
  // ============ P ============
  { name: '平顶山', py: 'pingdingshan' }, { name: '盘锦', py: 'panjin' },
  { name: '攀枝花', py: 'panzhihua' }, { name: '莆田', py: 'putian' },
  { name: '萍乡', py: 'pingxiang' }, { name: '濮阳', py: 'puyang' },
  { name: '普洱', py: 'puer' }, { name: '平遥', py: 'pingyao' },
  { name: '平凉', py: 'pingliang' }, { name: '蓬莱', py: 'penglai' },
  { name: '普陀山', py: 'putuoshan' }, { name: '盘州', py: 'panzhou' },
  // ============ Q ============
  { name: '青岛', py: 'qingdao' }, { name: '泉州', py: 'quanzhou' },
  { name: '秦皇岛', py: 'qinhuangdao' }, { name: '齐齐哈尔', py: 'qiqihaer' },
  { name: '衢州', py: 'quzhou' }, { name: '清远', py: 'qingyuan' },
  { name: '钦州', py: 'qinzhou' }, { name: '曲阜', py: 'qufu' },
  { name: '庆阳', py: 'qingyang' }, { name: '琼海', py: 'qionghai' },
  { name: '祁连', py: 'qilian' }, { name: '千岛湖', py: 'qiandaohu' },
  // ============ R ============
  { name: '日照', py: 'rizhao' }, { name: '日喀则', py: 'rikaze' },
  { name: '瑞丽', py: 'ruili' }, { name: '若尔盖', py: 'ruoergai' },
  // ============ S ============
  { name: '上海', py: 'shanghai' }, { name: '深圳', py: 'shenzhen' },
  { name: '苏州', py: 'suzhou' }, { name: '沈阳', py: 'shenyang' },
  { name: '石家庄', py: 'shijiazhuang' }, { name: '绍兴', py: 'shaoxing' },
  { name: '汕头', py: 'shantou' }, { name: '商丘', py: 'shangqiu' },
  { name: '韶关', py: 'shaoguan' }, { name: '上饶', py: 'shangrao' },
  { name: '邵阳', py: 'shaoyang' }, { name: '十堰', py: 'shiyan' },
  { name: '宿迁', py: 'suqian' }, { name: '宿州', py: 'suzhou2' },
  { name: '随州', py: 'suizhou' }, { name: '遂宁', py: 'suining' },
  { name: '三亚', py: 'sanya' }, { name: '松原', py: 'songyuan' },
  { name: '绥化', py: 'suihua' }, { name: '三明', py: 'sanming' },
  { name: '朔州', py: 'shuozhou' }, { name: '四平', py: 'siping' },
  { name: '神农架', py: 'shennongjia' }, { name: '韶山', py: 'shaoshan' },
  { name: '婺源', py: 'wuyuan' }, { name: '沙坡头', py: 'shapotou' },
  { name: '石林', py: 'shilin' }, { name: '双廊', py: 'shuanglang' },
  // ============ T ============
  { name: '天津', py: 'tianjin' }, { name: '太原', py: 'taiyuan' },
  { name: '唐山', py: 'tangshan' }, { name: '泰安', py: 'taian' },
  { name: '台州', py: 'taizhou' }, { name: '泰州', py: 'taizhou2' },
  { name: '铁岭', py: 'tieling' }, { name: '通辽', py: 'tongliao' },
  { name: '铜仁', py: 'tongren' }, { name: '铜陵', py: 'tongling' },
  { name: '腾冲', py: 'tengchong' }, { name: '吐鲁番', py: 'tulufan' },
  { name: '天水', py: 'tianshui' }, { name: '通化', py: 'tonghua' },
  { name: '塔城', py: 'tacheng' }, { name: '泰山', py: 'taishan' },
  // ============ W ============
  { name: '武汉', py: 'wuhan' }, { name: '无锡', py: 'wuxi' },
  { name: '温州', py: 'wenzhou' }, { name: '威海', py: 'weihai' },
  { name: '潍坊', py: 'weifang' }, { name: '芜湖', py: 'wuhu' },
  { name: '渭南', py: 'weinan' }, { name: '乌海', py: 'wuhai' },
  { name: '乌鲁木齐', py: 'wulumuqi' }, { name: '梧州', py: 'wuzhou' },
  { name: '乌兰察布', py: 'wulanchabu' }, { name: '武威', py: 'wuwei' },
  { name: '文山', py: 'wenshan' }, { name: '武夷山', py: 'wuyishan' },
  { name: '五台山', py: 'wutaishan' }, { name: '涠洲岛', py: 'weizhoudao' },
  { name: '乌镇', py: 'wuzhen' }, { name: '武隆', py: 'wulong' },
  { name: '万宁', py: 'wanning' },
  // ============ X ============
  { name: '西安', py: 'xian' }, { name: '厦门', py: 'xiamen' },
  { name: '徐州', py: 'xuzhou' }, { name: '襄阳', py: 'xiangyang' },
  { name: '咸阳', py: 'xianyang' }, { name: '湘潭', py: 'xiangtan' },
  { name: '孝感', py: 'xiaogan' }, { name: '邢台', py: 'xingtai' },
  { name: '信阳', py: 'xinyang' }, { name: '新乡', py: 'xinxiang' },
  { name: '西宁', py: 'xining' }, { name: '宣城', py: 'xuancheng' },
  { name: '许昌', py: 'xuchang' }, { name: '咸宁', py: 'xianning' },
  { name: '忻州', py: 'xinzhou' }, { name: '西双版纳', py: 'xishuangbanna' },
  { name: '香格里拉', py: 'xianggelila' }, { name: '兴义', py: 'xingyi' },
  { name: '锡林浩特', py: 'xilinhaote' }, { name: '香港', py: 'xianggang' },
  { name: '西塘', py: 'xitang' }, { name: '新都桥', py: 'xinduqiao' },
  // ============ Y ============
  { name: '宜昌', py: 'yichang' }, { name: '扬州', py: 'yangzhou' },
  { name: '烟台', py: 'yantai' }, { name: '盐城', py: 'yancheng' },
  { name: '岳阳', py: 'yueyang' }, { name: '运城', py: 'yuncheng' },
  { name: '宜宾', py: 'yibin' }, { name: '宜春', py: 'yichun' },
  { name: '玉溪', py: 'yuxi' }, { name: '银川', py: 'yinchuan' },
  { name: '榆林', py: 'yulin' }, { name: '营口', py: 'yingkou' },
  { name: '永州', py: 'yongzhou' }, { name: '雅安', py: 'yaan' },
  { name: '阳江', py: 'yangjiang' }, { name: '阳朔', py: 'yangshuo' },
  { name: '延吉', py: 'yanji' }, { name: '伊宁', py: 'yining' },
  { name: '伊犁', py: 'yili' }, { name: '玉林', py: 'yulin2' },
  { name: '云浮', py: 'yunfu' }, { name: '延安', py: 'yanan' },
  { name: '鹰潭', py: 'yingtan' }, { name: '云台山', py: 'yuntaishan' },
  // ============ Z ============
  { name: '郑州', py: 'zhengzhou' }, { name: '珠海', py: 'zhuhai' },
  { name: '中山', py: 'zhongshan' }, { name: '湛江', py: 'zhanjiang' },
  { name: '肇庆', py: 'zhaoqing' }, { name: '镇江', py: 'zhenjiang' },
  { name: '株洲', py: 'zhuzhou' }, { name: '遵义', py: 'zunyi' },
  { name: '张家口', py: 'zhangjiakou' }, { name: '张家界', py: 'zhangjiajie' },
  { name: '漳州', py: 'zhangzhou' }, { name: '淄博', py: 'zibo' },
  { name: '自贡', py: 'zigong' }, { name: '舟山', py: 'zhoushan' },
  { name: '周口', py: 'zhoukou' }, { name: '昭通', py: 'zhaotong' },
  { name: '张掖', py: 'zhangye' }, { name: '资阳', py: 'ziyang' },
  { name: '驻马店', py: 'zhumadian' }, { name: '枣庄', py: 'zaozhuang' },
  { name: '中卫', py: 'zhongwei' }, { name: '周庄', py: 'zhouzhuang' },
  { name: '镇远', py: 'zhenyuan' },
];

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

// 去重（同一城市可能重复出现，保留首次）
const MAP = {};
const UNIQUE = [];
RAW.forEach((c) => {
  if (MAP[c.name]) return;
  MAP[c.name] = 1;
  UNIQUE.push(c);
});

// 按拼音首字母分组并组内排序，过滤空分组（动态生成索引条，不会出现空字母）
const CITY_GROUPS = LETTERS.map((letter) => ({
  letter,
  items: UNIQUE.filter((c) => c.py.charAt(0).toUpperCase() === letter).sort((a, b) =>
    a.py.localeCompare(b.py)
  ),
})).filter((g) => g.items.length > 0);

const HOT_CITIES = [
  '北京', '上海', '广州', '深圳', '成都', '杭州',
  '西安', '重庆', '武汉', '南京', '苏州', '天津',
  '长沙', '青岛', '厦门', '三亚', '昆明', '哈尔滨',
];

module.exports = { CITY_GROUPS, HOT_CITIES, ALL_CITIES: UNIQUE };
