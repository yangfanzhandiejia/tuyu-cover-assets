const { loadSections, findArticles } = require('../../utils/cloudGuide');
const store = require('../../utils/store');
const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');
const { FAQS, loadMustRead } = require('../../data/hotreads');
const { buildIndex, search } = require('../../utils/ask');
const { secImgOf } = require('../../utils/secImg');

/**
 * 按「一趟旅程」的顺序分组，解决原来分类维度乱的问题
 * （原来一会儿按交通工具、一会儿按人群、一会儿按地域）
 */
const GROUPS = [
  { key: 'buy', title: '购票避坑', sub: '买票前先看这些，少花冤枉钱', ids: ['timing', 'general', 'flight', 'train', 'points'] },
  { key: 'people', title: '特殊人群', sub: '带老人、带娃、带宠物出门', ids: ['pet', 'elderly'] },
  { key: 'road', title: '路上与突发', sub: '中转、出境、延误、自驾', ids: ['world', 'highway', 'airport', 'baggage'] },
  { key: 'dest', title: '目的地防坑', sub: '到了那座城，怎么防宰', ids: ['city-north', 'city-east', 'city-south', 'city-southwest', 'dest'] },
];

/** 城市交通指南类文章（dest-城市-airport / dest-城市-transit）已迁到独立页面「城市交通指南」 */
function isTransit(id) {
  return /^dest-[a-z]+-(airport|transit)$/.test(id);
}

/** 过滤掉交通类文章，让「避坑指南」回归纯防坑内容 */
function onlyGuides(sections) {
  return (sections || []).map((sec) => {
    const items = (sec.items || []).filter((it) => !isTransit(it.id));
    return {
      id: sec.id,
      img: secImgOf(sec.id),
      icon: sec.icon,
      color: sec.color,
      bg: sec.bg,
      title: sec.title,
      subtitle: sec.subtitle,
      items: items,
    };
  }).filter((sec) => sec.items.length > 0);
}

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    sections: [],
    favs: [],
    recents: [],
    faqs: FAQS,       // 热门问题（从首页归位）
    mustRead: [],     // 出行前必看（从首页归位）
    groups: [],       // 按旅程顺序分组后的板块
    openMap: {},      // 板块展开状态（默认只展开第一个）
    keyword: '',
    searching: false,
    results: [],
    docs: [],
  },

  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    this.refresh();
    loadMustRead((list) => {
      if (list && list.length) this.setData({ mustRead: list });
    });
  },

  /** 从详情页返回 / 切换 Tab 时都要刷新，保证收藏与最近阅读是最新的 */
  onShow() {
    this.refresh();
  },

  refresh() {
    loadSections().then((raw) => {
      const sections = onlyGuides(raw);
      const favIds = store.getGuideFavs();
      // 按旅程顺序分组；同时建搜索索引
      const byId = {};
      sections.forEach((sec) => { byId[sec.id] = sec; });
      const groups = GROUPS.map((g) => ({
        key: g.key,
        title: g.title,
        sub: g.sub,
        sections: g.ids
          .map((id) => byId[id])
          .filter(Boolean)
          .map((sec) => Object.assign({}, sec, { count: (sec.items || []).length })),
      })).filter((g) => g.sections.length);

      // 未归类的板块兜底放到最后，避免漏内容
      const used = {};
      GROUPS.forEach((g) => g.ids.forEach((id) => { used[id] = 1; }));
      const rest = sections.filter((sec) => !used[sec.id]);
      if (rest.length) {
        groups.push({ key: 'other', title: '其他', sub: '', sections: rest.map((sec) => Object.assign({}, sec, { count: (sec.items || []).length })) });
      }

      const openMap = this.data.openMap;
      if (!Object.keys(openMap).length && groups.length && groups[0].sections.length) {
        openMap[groups[0].sections[0].id] = true;   // 默认展开第一篇所属板块
      }
      // 把展开状态直接写进每个板块，WXML 用 sec.open 判断，不做动态键查询
      const withOpen = (list) => list.map((sec) => Object.assign({}, sec, { open: !!openMap[sec.id] }));
      groups.forEach((g) => { g.sections = withOpen(g.sections); });

      const docs = [];
      sections.forEach((sec) => {
        (sec.items || []).forEach((it) => { docs.push({ id: it.id, title: it.title, summary: it.summary || '', tags: it.tags || [], sectionTitle: sec.title }); });
      });

      this.setData({
        sections,
        groups,
        openMap,
        docs: buildIndex(sections) || docs,
        favs: findArticles(sections, favIds),
      });
    });
  },

  /** 展开 / 收起某个板块 */
  toggleSec(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    const openMap = Object.assign({}, this.data.openMap);
    openMap[id] = !openMap[id];
    tap('toggle_guide_fav', { id: id, open: !!openMap[id] });
    // 同步 groups 内每个板块的 open 标记，保持与 openMap 一致
    const groups = (this.data.groups || []).map((g) => Object.assign({}, g, {
      sections: (g.sections || []).map((s) => Object.assign({}, s, { open: !!openMap[s.id] })),
    }));
    this.setData({ openMap, groups });
  },

  onSearch(e) {
    const kw = (e.detail.value || '').trim();
    if (!kw) {
      this.setData({ keyword: '', searching: false, results: [] });
      return;
    }
    const res = search(kw, this.data.docs, 20) || [];
    this.setData({ keyword: kw, searching: true, results: res });
  },

  clearSearch() {
    this.setData({ keyword: '', searching: false, results: [] });
  },

  /** 热门问题：按主题直达对应文章 */
  openFaq(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    tap('open_faq', { id });
    haptic.light();
    wx.navigateTo({ url: '/pages/guide-detail/guide-detail?id=' + id });
  },

  openMust(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    tap('open_must_read', { id });
    haptic.light();
    wx.navigateTo({ url: '/pages/guide-detail/guide-detail?id=' + id });
  },

  openDetail(e) {
    const id = e.currentTarget.dataset.id;
    tap('open_guide', { id });
    haptic.light();
    wx.navigateTo({ url: `/pages/guide-detail/guide-detail?id=${id}` });
  },

  onShareAppMessage() {
    track('share_guide');
    return share.appMessage({ title: '途悦出行防坑：购票套路、退改签、行李额一文看懂', path: '/pages/guide/guide' });
  },

  onTabItemTap(e) {
    track('tab_switch', { page: e.pagePath });
    haptic.light();
  },
  onShareTimeline() {
    return share.timeline({ title: '133篇出行避坑指南，收藏不踩坑' });
  },
});
