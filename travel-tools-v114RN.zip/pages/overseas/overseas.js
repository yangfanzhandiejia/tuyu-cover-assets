/**
 * 出境工具包：插座速查 / 签证速查 / 汇率换算
 * 纯本地静态数据 + 手填汇率换算。插座电压与签证政策各国经常调整，
 * 页面多处标注「以官方为准」；汇率一律由用户填当天价，不内置静态汇率防过期误导。
 */

/* ---------- 插座速查（type=插座标准，volt=电压/频率，need=要带什么）----------
 * need: none=国内两扁插头可直接用 / plug=需转换头 / adapter=需转换头（英标/澳标等三扁）
 * 现代手机笔记本充电器多为宽压 100-240V，一般只需转换头，不需要变压器 */
const PLUGS = [
  { name: '日本', type: 'A / B（两扁 / 两扁+地线）', volt: '100V · 50/60Hz', need: 'none', tip: '国内两扁插头多数可直接用；三脚插头需转换头' },
  { name: '韩国', type: 'C / F（欧标两圆）', volt: '220V · 60Hz', need: 'plug', tip: '圆孔，需欧标转换头' },
  { name: '泰国', type: 'A / B / C 混合', volt: '220V · 50Hz', need: 'plug', tip: '酒店多通用，建议带万能转换头' },
  { name: '新加坡', type: 'G（英标三方）', volt: '230V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '马来西亚', type: 'G（英标三方）', volt: '240V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '印度尼西亚', type: 'C / F（欧标两圆）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头；巴厘岛同' },
  { name: '越南', type: 'A / C / G 混合', volt: '220V · 50Hz', need: 'plug', tip: '插座较杂，万能头最稳' },
  { name: '菲律宾', type: 'A / B（两扁）', volt: '220V · 60Hz', need: 'none', tip: '两扁插头可直接用' },
  { name: '柬埔寨', type: 'A / C / G 混合', volt: '220V · 50Hz', need: 'plug', tip: '万能头最稳' },
  { name: '老挝', type: 'A / B / C 混合', volt: '230V · 50Hz', need: 'plug', tip: '万能头最稳' },
  { name: '缅甸', type: 'C / D / F / G 混合', volt: '230V · 50Hz', need: 'plug', tip: '插座很杂，务必带万能头' },
  { name: '印度', type: 'C / D / M（南标）', volt: '230V · 50Hz', need: 'plug', tip: '需转换头；部分地区电压不稳' },
  { name: '尼泊尔', type: 'C / D / M 混合', volt: '230V · 50Hz', need: 'plug', tip: '需转换头' },
  { name: '斯里兰卡', type: 'D / G / M 混合', volt: '230V · 50Hz', need: 'plug', tip: '插座杂，万能头最稳' },
  { name: '马尔代夫', type: 'A / C / D / G / J 混合', volt: '230V · 50Hz', need: 'plug', tip: '度假村多通用，带万能头保险' },
  { name: '阿联酋', type: 'G（英标三方）', volt: '220V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '卡塔尔', type: 'G（英标三方）', volt: '240V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '土耳其', type: 'C / F（欧标两圆）', volt: '220V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '埃及', type: 'C / F（欧标两圆）', volt: '220V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '摩洛哥', type: 'C / E（欧标）', volt: '220V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '南非', type: 'M / N（南标三圆）', volt: '230V · 50Hz', need: 'plug', tip: '需南标转换头' },
  { name: '肯尼亚', type: 'G（英标三方）', volt: '240V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '澳大利亚', type: 'I（澳标三扁）', volt: '230V · 50Hz', need: 'adapter', tip: '需澳标转换头（斜两扁+地线）' },
  { name: '新西兰', type: 'I（澳标三扁）', volt: '230V · 50Hz', need: 'adapter', tip: '需澳标转换头' },
  { name: '美国', type: 'A / B（两扁 / 带地线）', volt: '120V · 60Hz', need: 'none', tip: '两扁插头可直接用；充电器宽压的没问题' },
  { name: '加拿大', type: 'A / B（两扁）', volt: '120V · 60Hz', need: 'none', tip: '两扁插头可直接用' },
  { name: '墨西哥', type: 'A / B（两扁）', volt: '127V · 60Hz', need: 'none', tip: '两扁插头可直接用' },
  { name: '英国', type: 'G（英标三方）', volt: '230V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '法国', type: 'C / E（欧标）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '德国', type: 'C / F（欧标两圆）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '意大利', type: 'C / F / L 混合', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '西班牙', type: 'C / F（欧标两圆）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '荷兰', type: 'C / F（欧标两圆）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '瑞士', type: 'C / J（瑞标三孔）', volt: '230V · 50Hz', need: 'plug', tip: '需瑞标转换头' },
  { name: '奥地利', type: 'C / F（欧标两圆）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '希腊', type: 'C / F（欧标两圆）', volt: '230V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '俄罗斯', type: 'C / F（欧标两圆）', volt: '220V · 50Hz', need: 'plug', tip: '需欧标转换头' },
  { name: '巴西', type: 'C / N（巴西标）', volt: '127V / 220V 不一', need: 'plug', tip: '插座标准各地不一，带万能头' },
  { name: '阿根廷', type: 'C / I 混合', volt: '220V · 50Hz', need: 'plug', tip: '需转换头' },
  { name: '中国香港', type: 'G（英标三方）', volt: '220V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '中国澳门', type: 'G（英标三方）', volt: '220V · 50Hz', need: 'adapter', tip: '需英标转换头' },
  { name: '中国台湾', type: 'A / B（两扁）', volt: '110V · 60Hz', need: 'none', tip: '两扁插头可直接用' },
];

/* ---------- 签证速查（中国护照口径）----------
 * kind: free=免签 / arrival=落地签 / evisa=电子签 / apply=需提前申请
 * 各国政策调整频繁（尤其免签扩容），出行前务必以中国领事服务网与目的国官方为准 */
const VISAS = [
  { name: '泰国', kind: 'free', stay: '30 天（每 180 天累计不超 90 天）', tip: '中泰互免持普通护照人员签证协定已生效，停留上限以入境章与官方为准' },
  { name: '新加坡', kind: 'free', stay: '30 天（每 180 天累计不超 90 天）', tip: '互免签证；入境前 3 天内需在线填电子入境卡（免费）' },
  { name: '马来西亚', kind: 'free', stay: '以官方公布为准', tip: '互免协定已签署，具体生效安排与停留期以官方公布为准' },
  { name: '阿联酋', kind: 'free', stay: '30 天', tip: '互免签证' },
  { name: '卡塔尔', kind: 'free', stay: '30 天', tip: '互免签证' },
  { name: '塞尔维亚', kind: 'free', stay: '30 天（每 180 天累计不超 90 天）', tip: '互免签证；停留上限以官方为准' },
  { name: '波黑', kind: 'free', stay: '90 天（每 180 天）', tip: '互免签证' },
  { name: '阿尔巴尼亚', kind: 'free', stay: '90 天（每 180 天）', tip: '互免签证' },
  { name: '毛里求斯', kind: 'free', stay: '60 天', tip: '互免签证' },
  { name: '塞舌尔', kind: 'free', stay: '30 天', tip: '互免签证' },
  { name: '斐济', kind: 'free', stay: '30 天', tip: '互免签证已生效，停留期以官方为准' },
  { name: '哈萨克斯坦', kind: 'free', stay: '30 天（每 180 天累计不超 90 天）', tip: '互免签证；停留上限以官方为准' },
  { name: '格鲁吉亚', kind: 'free', stay: '30 天', tip: '互免签证' },
  { name: '马尔代夫', kind: 'free', stay: '30 天', tip: '互免签证' },
  { name: '亚美尼亚', kind: 'free', stay: '90 天（每 180 天）', tip: '互免签证' },
  { name: '白俄罗斯', kind: 'free', stay: '30 天', tip: '互免签证' },
  { name: '印度尼西亚', kind: 'arrival', stay: '30 天（可延期一次）', tip: '落地签（也可提前网上办电子签，过关更快）' },
  { name: '老挝', kind: 'arrival', stay: '30 天', tip: '落地签；备好照片与现金' },
  { name: '柬埔寨', kind: 'arrival', stay: '30 天', tip: '落地签 / 电子签均可' },
  { name: '尼泊尔', kind: 'arrival', stay: '15 / 30 / 90 天分档', tip: '落地签按停留天数分档收费' },
  { name: '埃及', kind: 'arrival', stay: '30 天', tip: '落地签；也可提前办电子签' },
  { name: '约旦', kind: 'arrival', stay: '30 / 60 / 90 天分档', tip: '落地签按停留天数分档收费' },
  { name: '孟加拉国', kind: 'arrival', stay: '30 天', tip: '落地签；建议提前确认入境口岸' },
  { name: '斯里兰卡', kind: 'arrival', stay: '以官方为准', tip: '免签试点 / 落地签 / ETA 电子授权政策多次调整，务必行前查官方' },
  { name: '巴林', kind: 'arrival', stay: '14 / 30 天分档', tip: '落地签 / 电子签均可' },
  { name: '伊朗', kind: 'arrival', stay: '30 天', tip: '落地签；关注外交部出行提醒' },
  { name: '坦桑尼亚', kind: 'arrival', stay: '90 天', tip: '落地签 / 电子签均可' },
  { name: '津巴布韦', kind: 'arrival', stay: '30 天', tip: '落地签' },
  { name: '玻利维亚', kind: 'arrival', stay: '30 天', tip: '落地签（需机票行程单与酒店预订单）' },
  { name: '瓦努阿图', kind: 'arrival', stay: '30 天', tip: '落地签' },
  { name: '土耳其', kind: 'evisa', stay: '30 天（180 天内累计不超 90 天）', tip: '电子签，官网在线办，出签快' },
  { name: '越南', kind: 'evisa', stay: '以官方为准', tip: '电子签 / 另纸签政策多次调整，行前查官方' },
  { name: '印度', kind: 'evisa', stay: '30 / 90 天分档', tip: '电子签（提前在线申请）' },
  { name: '沙特阿拉伯', kind: 'evisa', stay: '90 天（一年累计不超 180 天）', tip: '电子签 / 落地签均可' },
  { name: '阿曼', kind: 'evisa', stay: '30 天', tip: '电子签' },
  { name: '澳大利亚', kind: 'evisa', stay: '以签证为准', tip: '需提前在线申请（非落地），审理要时间，早办' },
  { name: '新西兰', kind: 'evisa', stay: '以签证为准', tip: '需提前在线申请，另缴游客环保税' },
  { name: '肯尼亚', kind: 'evisa', stay: '90 天', tip: '电子签（需提前在线申请）' },
  { name: '埃塞俄比亚', kind: 'evisa', stay: '30 / 90 天分档', tip: '电子签 / 落地签均可' },
  { name: '俄罗斯', kind: 'evisa', stay: '以官方为准', tip: '电子签适用范围扩大中，普通旅游签政策以官方为准' },
  { name: '美国', kind: 'apply', stay: '以签证为准', tip: '需提前办 B1/B2 等签证，要面签，排期长，早办' },
  { name: '加拿大', kind: 'apply', stay: '以签证为准', tip: '需提前办访客签证，要录指纹' },
  { name: '英国', kind: 'apply', stay: '以签证为准', tip: '需提前办标准访客签证' },
  { name: '日本', kind: 'apply', stay: '以签证为准', tip: '需提前办旅游签证（单次/多次），通过指定代办机构送签' },
  { name: '韩国', kind: 'apply', stay: '以签证为准', tip: '需提前办签证；济州岛免签政策以官方为准' },
  { name: '法国', kind: 'apply', stay: '申根短期', tip: '申根签：向停留时间最长的主要目的国申请' },
  { name: '德国', kind: 'apply', stay: '申根短期', tip: '申根签：向停留时间最长的主要目的国申请' },
  { name: '意大利', kind: 'apply', stay: '申根短期', tip: '申根签：向停留时间最长的主要目的国申请' },
  { name: '西班牙', kind: 'apply', stay: '申根短期', tip: '申根签：向停留时间最长的主要目的国申请' },
  { name: '荷兰', kind: 'apply', stay: '申根短期', tip: '申根签：向停留时间最长的主要目的国申请' },
  { name: '瑞士', kind: 'apply', stay: '申根短期', tip: '申根签：向停留时间最长的主要目的国申请' },
  { name: '巴西', kind: 'apply', stay: '以签证为准', tip: '需提前办签证，审理较慢' },
  { name: '阿根廷', kind: 'apply', stay: '以签证为准', tip: '需提前办签证' },
  { name: '南非', kind: 'apply', stay: '以签证为准', tip: '需提前办签证' },
];

/* ---------- 汇率换算（不内置汇率，用户填当天价）---------- */
const CURRENCIES = [
  { code: 'USD', name: '美元', sym: '$' },
  { code: 'EUR', name: '欧元', sym: '€' },
  { code: 'JPY', name: '日元', sym: '¥' },
  { code: 'KRW', name: '韩元', sym: '₩' },
  { code: 'THB', name: '泰铢', sym: '฿' },
  { code: 'SGD', name: '新加坡元', sym: 'S$' },
  { code: 'MYR', name: '马来西亚林吉特', sym: 'RM' },
  { code: 'AUD', name: '澳元', sym: 'A$' },
  { code: 'GBP', name: '英镑', sym: '£' },
  { code: 'HKD', name: '港元', sym: 'HK$' },
  { code: 'MOP', name: '澳门元', sym: 'MOP$' },
  { code: 'TWD', name: '新台币', sym: 'NT$' },
  { code: 'VND', name: '越南盾', sym: '₫' },
  { code: 'IDR', name: '印尼卢比', sym: 'Rp' },
  { code: 'PHP', name: '菲律宾比索', sym: '₱' },
  { code: 'INR', name: '印度卢比', sym: '₹' },
  { code: 'AED', name: '阿联酋迪拉姆', sym: 'AED' },
  { code: 'CHF', name: '瑞士法郎', sym: 'CHF' },
  { code: 'CAD', name: '加元', sym: 'C$' },
  { code: 'NZD', name: '新西兰元', sym: 'NZ$' },
  { code: 'RUB', name: '俄罗斯卢布', sym: '₽' },
  { code: 'TRY', name: '土耳其里拉', sym: '₺' },
];

const VISA_KINDS = {
  free: { label: '免签', cls: 'vk-free' },
  arrival: { label: '落地签', cls: 'vk-arrival' },
  evisa: { label: '电子签', cls: 'vk-evisa' },
  apply: { label: '需提前申请', cls: 'vk-apply' },
};

const NEED_LABELS = { none: '国内两扁插头可直接用', plug: '需带转换头', adapter: '需带转换头（三扁）' };

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    tab: 'plug',
    plugs: PLUGS,
    plugNames: PLUGS.map((x) => x.name),
    plugIdx: 0,
    plugNeedLabel: NEED_LABELS[PLUGS[0].need],

    visas: VISAS.map((v) => Object.assign({}, v, { kindLabel: VISA_KINDS[v.kind].label, kindCls: VISA_KINDS[v.kind].cls })),
    visaNames: VISAS.map((x) => x.name),
    visaIdx: 0,

    fxNames: CURRENCIES.map((c) => c.name + '（' + c.code + '）'),
    fxIdx: 0,
    fxRate: '',
    fxAmount: '',
    fxResult: null,
  },

  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },

  switchTab(e) {
    tap('overseas_tab', { tab: e.currentTarget.dataset.tab });
    haptic.light();
    this.setData({ tab: e.currentTarget.dataset.tab });
  },

  /* ---------- 插座 ---------- */
  onPlugIdx(e) {
    const i = Number(e.detail.value);
    this.setData({ plugIdx: i, plugNeedLabel: NEED_LABELS[PLUGS[i].need] });
  },

  /* ---------- 签证 ---------- */
  onVisaIdx(e) {
    this.setData({ visaIdx: Number(e.detail.value) });
  },

  /* ---------- 汇率 ---------- */
  onFxIdx(e) { this.setData({ fxIdx: Number(e.detail.value) }, () => this.computeFx()); },
  onFxRate(e) { this.setData({ fxRate: e.detail.value }, () => this.computeFx()); },
  onFxAmount(e) { this.setData({ fxAmount: e.detail.value }, () => this.computeFx()); },

  computeFx() {
    const rate = parseFloat(this.data.fxRate);
    const amt = parseFloat(this.data.fxAmount);
    const cur = CURRENCIES[this.data.fxIdx];
    if (!(rate > 0) || !(amt > 0)) { this.setData({ fxResult: null }); return; }
    const cny = amt * rate;
    this.setData({
      fxResult: {
        curCode: cur.code,
        curSym: cur.sym,
        cny: Math.round(cny * 100) / 100,
        back: rate > 0 ? Math.round((1 / rate) * 10000) / 10000 : 0, // 1 元 ≈ ? 外币
      },
    });
  },

  onShareAppMessage() {
    return share.appMessage({ title: '出境工具包：插座、签证、汇率一次查清', path: '/pages/overseas/overseas' });
  },
  onShareTimeline() {
    return share.timeline({ title: '出境先查插座签证汇率' });
  },
});
