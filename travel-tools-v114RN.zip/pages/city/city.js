const { CITY_GROUPS, HOT_CITIES, ALL_CITIES } = require('../../data/cities');
const { track, tap } = require('../../utils/track');

const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    groups: CITY_GROUPS,
    hot: HOT_CITIES,
    keyword: '',
    searchResult: [],
    activeLetter: CITY_GROUPS.length ? CITY_GROUPS[0].letter : '',
    showLetter: '',
  },

  onReady() {
    // 实测每个索引字母的位置，滑动时按"最近的字母"定位，避免平均高度算错
    wx.createSelectorQuery()
      .selectAll('.index-letter')
      .boundingClientRect((rects) => {
        if (rects && rects.length) {
          this.letterRects = rects;
        }
      })
      .exec();
  },

  /** 搜索：支持汉字、拼音全拼、拼音前缀；单个字母 = 该字母开头的全部城市 */
  onSearch(e) {
    const raw = e.detail.value || '';
    const kw = raw.trim().toLowerCase();
    tap('city_search', { kw });
    this.setData({ keyword: raw });

    if (!kw) {
      this.setData({ searchResult: [] });
      return;
    }

    let res;
    if (kw.length === 1 && /^[a-z]$/.test(kw)) {
      // 单字母：等同于点索引，列出该字母开头的城市
      res = ALL_CITIES.filter((c) => c.py.charAt(0).toLowerCase() === kw);
    } else {
      res = ALL_CITIES.filter(
        (c) => c.name.indexOf(kw) > -1 || c.py.indexOf(kw) > -1
      );
    }
    // 结果过多时只取前 50 条，避免一次渲染太多导致卡顿
    this.setData({ searchResult: res.slice(0, 50) });
  },

  clearSearch() {
    this.setData({ keyword: '', searchResult: [] });
  },

  /** 点击右侧字母：精确跳转（不再依赖平均高度计算） */
  onTapLetter(e) {
    const letter = e.currentTarget.dataset.letter;
    if (!letter) return;
    this.scrollToLetter(letter);
  },

  /** 触摸滑动索引条：按实测位置取最近字母 */
  onTouchIndex(e) {
    const t = e.touches[0] || e.changedTouches[0];
    if (!t) return;

    let letter = null;
    const rects = this.letterRects;
    if (rects && rects.length) {
      const y = t.clientY;
      let best = 0;
      let bestD = Infinity;
      rects.forEach((r, i) => {
        const center = r.top + r.height / 2;
        const d = Math.abs(y - center);
        if (d < bestD) {
          bestD = d;
          best = i;
        }
      });
      letter = this.data.groups[best] && this.data.groups[best].letter;
    } else if (this.barTop != null && this.itemH) {
      const y = t.clientY - this.barTop;
      let i = Math.floor(y / this.itemH);
      i = Math.max(0, Math.min(i, this.data.groups.length - 1));
      letter = this.data.groups[i].letter;
    }

    if (!letter || letter === this.data.activeLetter) return;
    this.scrollToLetter(letter);
  },

  /**
   * 滚动到指定字母分组。
   * 不依赖 scroll-view 的 scroll-into-view（真机上容器高度可能撑不开而失效），
   * 改为直接计算分组在页面中的位置，用 wx.pageScrollTo 滚动，兼容性最好。
   */
  scrollToLetter(letter) {
    this._lastLetter = letter;
    this.setData({ activeLetter: letter, showLetter: letter });
    clearTimeout(this._tip);
    this._tip = setTimeout(() => this.setData({ showLetter: '' }), 600);

    const q = wx.createSelectorQuery();
    q.select('#g-' + letter).boundingClientRect();
    q.selectViewport().scrollOffset();
    q.exec((res) => {
      const rect = res && res[0];
      const view = res && res[1];
      if (!rect) return;
      // 56 为吸顶搜索栏的大致高度，避免目标标题被它盖住
      const absolute = rect.top + (view ? view.scrollTop : 0);
      const target = absolute - 56;
      wx.pageScrollTo({
        scrollTop: target > 0 ? target : 0,
        duration: 200,
      });
    });
  },

  onChoose(e) {
    const name = e.currentTarget.dataset.name;
    tap('city_pick', { city: name });
    const ec = this.getOpenerEventChannel && this.getOpenerEventChannel();
    if (ec && ec.emit) {
      ec.emit('choose', { city: name });
    }
    wx.navigateBack();
  },
});
