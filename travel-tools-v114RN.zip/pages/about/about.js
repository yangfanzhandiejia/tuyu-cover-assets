const CONFIG = {
  // 联系邮箱
  email: 'yangfan11001@gmail.com',
  // ⚠️ 待替换：小程序备案通过后，把备案号填到这里（形如 '京ICP备XXXXXXXX号'）
  icp: '',
  // 发布版本号：每次打包发布时同步更新（当前 v114-r7：延误一键投诉信、指南收藏、油价档位/拥堵通用化/充电桩提示、会员日倒计时卡）
  version: 'v114-r7',
};

const share = require('../../utils/share');
Page({
  data: {
    email: CONFIG.email,
    icp: CONFIG.icp,
    version: CONFIG.version,
  },

  copyEmail() {
    const email = this.data.email;
    if (!email || email.indexOf('example.com') > -1) {
      wx.showToast({ title: '联系方式配置中', icon: 'none' });
      return;
    }
    wx.setClipboardData({
      data: email,
      success: () => wx.showToast({ title: '邮箱已复制', icon: 'none', duration: 2000 }),
    });
  },

  copyIcp() {
    if (!this.data.icp) return;
    wx.setClipboardData({
      data: this.data.icp,
      success: () => wx.showToast({ title: '备案号已复制', icon: 'none', duration: 2000 }),
    });
  },
  onShareAppMessage() {
    return share.appMessage({ title: '途悦出行防坑：帮普通人出行不踩坑', path: '/pages/about/about' });
  },
  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },
  onShareTimeline() {
    return share.timeline({ title: '途悦出行防坑：帮普通人出行不踩坑' });
  },
});
