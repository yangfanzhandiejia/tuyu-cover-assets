const CONFIG = {
  // 联系邮箱
  email: 'yangfan11001@gmail.com',
  // ⚠️ 待替换：小程序备案通过后，把备案号填到这里（形如 '京ICP备XXXXXXXX号'）
  icp: '',
  // 发布版本号：每次打包发布时同步更新（当前 v114-r13：分享封面图重设计——关键内容收进中央安全区，避让微信卡片叠加层与朋友圈 1:1 裁切）
  version: 'v114-r13',
};

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
const { tap } = require('../../utils/track');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    email: CONFIG.email,
    icp: CONFIG.icp,
    version: CONFIG.version,
    fontScale: 'normal',   // normal / large / xlarge（适老化字号，storage 持久化）
  },

  copyEmail() {
    const email = this.data.email;
    if (!email || email.indexOf('example.com') > -1) {
      wx.showToast({ title: '联系方式配置中', icon: 'none' });
      return;
    }
    wx.setClipboardData({
      data: email,
      success: () => wx.showToast({ title: '邮箱已复制', icon: 'none', duration: 2000 }),
    });
  },

  copyIcp() {
    if (!this.data.icp) return;
    wx.setClipboardData({
      data: this.data.icp,
      success: () => wx.showToast({ title: '备案号已复制', icon: 'none', duration: 2000 }),
    });
  },
  onShareAppMessage() {
    return share.appMessage({ title: '途悦出行防坑：帮普通人出行不踩坑', path: '/pages/about/about' });
  },
  setFontScale(e) {
    const v = e.currentTarget.dataset.v;
    const cur = wx.getStorageSync(a11y.KEY) || 'normal';
    if (v === cur) return; // 点当前档位不重复提示
    try { wx.setStorageSync(a11y.KEY, v); } catch (err) { /* 存储失败仍切当前会话 */ }
    this.setData({ fontScale: v });
    // 本页立即生效（Behavior 的 pageLifetimes.show 只在他页 show 时刷新）
    this.setData({ fontScaleClass: a11y.readScale() });
    wx.showToast({ title: v === 'normal' ? '已恢复标准字号' : '已放大字号，全站生效', icon: 'none', duration: 2000 });
    tap('about_font_scale', { scale: v });
  },

  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    this.setData({ fontScale: wx.getStorageSync(a11y.KEY) || 'normal' });
  },
  onShareTimeline() {
    return share.timeline({ title: '途悦出行防坑：帮普通人出行不踩坑' });
  },
});
