const { loadSections } = require('../../utils/cloudGuide');
const { REGIONS, findCity } = require('../../data/regions');
const { tap } = require('../../utils/track');

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
const xscroll = require('../../utils/xscroll');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    regions: REGIONS.map((r) => ({ key: r.key, name: r.name })),
    curKey: 'north',
    groups: [],
    total: 0,
    focus: null,   // 从首页「目的地交通」带城市进来时，置顶显示该城市
    xscrollMore: false,
    xscrollEnd: false,
  },

  /** 支持 ?city=三亚：自动切到该城市所在区域并置顶 */
  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    const city = findCity(options && options.city);
    if (city) {
      this.setData({ focus: city });
      this.build(city.regionKey);
    } else {
      this.build('north');
    }
  },

  // 区域栏 4 个区域名较长（如「华北 · 东北 · 西北」）总宽超屏：测量后显示右侧「左滑看更多」提示
  onReady() {
    xscroll.measure(this, '.rg-inner');
  },

  onXscroll(e) {
    xscroll.handleScroll(this, e);
  },

  build(key) {
    const self = this;
    loadSections().then((sections) => {
      const map = {};
      (sections || []).forEach((sec) => {
        (sec.items || []).forEach((it) => { map[it.id] = it.title; });
      });
      const region = REGIONS.filter((r) => r.key === key)[0] || REGIONS[0];
      const groups = region.cities.map((c) => {
        const ck = c[0];
        const cn = c[1];
        return {
          name: cn,
          items: [
            { id: 'dest-' + ck + '-airport', title: map['dest-' + ck + '-airport'] || (cn + '机场怎么去市区最省最快') },
            { id: 'dest-' + ck + '-transit', title: map['dest-' + ck + '-transit'] || (cn + '市内出行：地铁、公交、打车怎么选') },
          ],
        };
      });
      let total = 0;
      groups.forEach((g) => { total += g.items.length; });

      // 若有指定城市，把它的两篇抽出来置顶
      let focus = self.data.focus;
      if (focus) {
        focus = {
          key: focus.key,
          name: focus.name,
          items: [
            { id: 'dest-' + focus.key + '-airport', title: map['dest-' + focus.key + '-airport'] || (focus.name + '机场怎么去市区最省最快') },
            { id: 'dest-' + focus.key + '-transit', title: map['dest-' + focus.key + '-transit'] || (focus.name + '市内出行：地铁、公交、打车怎么选') },
          ],
        };
      }

      self.setData({ curKey: region.key, groups: groups, total: total, focus: focus || null });
    });
  },

  onSwitch(e) {
    const key = e.currentTarget.dataset.key;
    if (key === this.data.curKey) return;
    tap('cityguide_switch', { key: key });
    this.build(key);
  },

  openDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    tap('open_cityguide', { id: id });
    wx.navigateTo({ url: '/pages/guide-detail/guide-detail?id=' + id });
  },

  onShareAppMessage() {
    return share.appMessage({ title: '途悦出行防坑：24 座城市机场进城与市内出行全攻略', path: '/pages/cityguide/cityguide' });
  },
  onShareTimeline() {
    return share.timeline({ title: '城市出行攻略，到了不抓瞎' });
  },
});
