const { buildIndex, search } = require('../../utils/ask');
const { loadSections } = require('../../utils/cloudGuide');
const { tap } = require('../../utils/track');

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    query: '',
    docs: [],
    results: null, // null = 还没搜索过；[] = 搜过但没结果
    asked: false,
    hot: [
      '行李托运怎么算',
      '退票要扣多少钱',
      '航班延误怎么办',
      '值机提前多久到',
      '里程会过期吗',
      '带娃出行注意什么',
      '充电宝能带上飞机吗',
      '学生票怎么买',
    ],
  },

  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    loadSections().then((sections) => {
      this.setData({ docs: buildIndex(sections) });
    });
  },

  onInput(e) {
    this.setData({ query: e.detail.value });
  },

  onAsk() {
    this.doSearch(this.data.query);
  },

  onHot(e) {
    const q = e.currentTarget.dataset.q || '';
    this.setData({ query: q }, () => this.doSearch(q));
  },

  doSearch(q) {
    const kw = (q || '').trim();
    if (!kw) {
      wx.showToast({ title: '老哥提醒：先说说你的问题', icon: 'none' });
      return;
    }
    tap('ask_question', { q: kw });
    const res = search(kw, this.data.docs, 6);
    this.setData({ results: res, asked: true });
    if (!res.length) {
      wx.showToast({ title: '没找到，换个说法试试', icon: 'none', duration: 1800 });
    }
  },

  openArticle(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    tap('ask_open_article', { id });
    wx.navigateTo({ url: '/pages/guide-detail/guide-detail?id=' + id });
  },

  goGuide() {
    wx.switchTab({ url: '/pages/guide/guide' });
  },

  onShareAppMessage() {
    return share.appMessage({ title: '途悦出行防坑：出行问题，一问就有答案', path: '/pages/ask/ask' });
  },
  onShareTimeline() {
    return share.timeline({ title: '出行有疑问？老哥在线答疑' });
  },
});
