/**
 * 维权工具箱
 * 纯本地内容，不上传任何信息。
 * 思路：先跟对方谈（要工号）→ 谈不下来走监管部门 → 同步公开曝光施压。
 */

const { tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');

const SCENES = [
  {
    id: 'refund',
    name: '退票扣太多',
    when: '第三方平台买的票，退票只退税费；或扣款比例远高于购票时看到的规则',
    script: '你好，我的订单号 XXX、票号 XXX。本次退票你们只退了税费，扣掉了几乎全部票款。请说明扣款依据：具体扣了多少、按哪一条退改规则执行、该规则在我购票页面的哪一处向我明示过。依据《消费者权益保护法》第八条与第二十六条，经营者不得以格式条款作出排除或限制消费者权利、减轻自身责任的规定。如不能说明依据，我要求全额退还票款；否则我将向 12326 与 12315 投诉。',
  },
  {
    id: 'delay',
    name: '延误取消没人管',
    when: '航班延误或取消，柜台不办退票、不安排食宿、不给书面证明',
    script: '你好，航班号 XXX，日期 XXX。因航司自身原因延误已超过 4 小时（/航班取消），我已按贵司运输总条件申请全额退票，柜台未予办理。请书面说明不予办理的依据。我要求：全额退票且不收取任何手续费，或免费改签至最近可用航班并承担差价。请在 24 小时内答复，否则我将向 12326 投诉，并同步提交书面材料。',
  },
  {
    id: 'overbook',
    name: '超售被拒登机',
    when: '有票、已值机，却被通知航班超售无法登机',
    script: '你好，我持有已确认的客票（票号 XXX），办理值机时被通知超售无法登机。请：1）书面说明超售情况；2）优先安排最近可用航班；3）按贵司公布的超售补偿标准给予补偿；4）由此产生的住宿、餐食、地面交通费用由贵司承担。请现在出具书面凭证和受理编号。',
  },
  {
    id: 'baggage',
    name: '行李丢失损坏',
    when: '到达后行李未到，或箱体、内物损坏',
    script: '你好，我的行李（行李牌号 XXX，航班 XXX）抵达后未能提取（/已损坏）。请立即启动查询并出具《行李运输事故记录单》。我要求：1）在规定期限内书面答复查询结果；2）如确认丢失，按规定标准赔偿，不得简单按重量一刀切，应参照实际损失与申报价值；3）请提供工号和受理编号，以便后续跟进。',
  },
  {
    id: 'markup',
    name: '平台加价 / 不出票',
    when: '实际支付价高于航司官方同舱位价；付款后查不到票号；疑遇假票',
    script: '你好，我在贵平台购买的机票（订单号 XXX），实际支付含税总价高于航司官方同舱位价格（/购票后查不到票号）。请说明：1）票价构成明细及所有收费项目；2）票号及航司官方验真方式。依据《消费者权益保护法》第八条，我享有知悉其真实情况的权利。如存在未明示的加价或未实际出票，我要求全额退款并承担相应责任。',
  },
  {
    id: 'bundle',
    name: '默认勾选搭售',
    when: '被默认勾选保险、加速包、优惠券套餐，支付后才发现',
    script: '你好，我在贵平台购票时被默认勾选了 XXX（保险/加速包/套餐），我并未主动选择，支付后才发觉。依据《消费者权益保护法》第九条与《电子商务法》相关规定，经营者不得默认搭售商品或服务。我要求立即取消该项并全额退款，请提供工号和受理编号。',
  },
];

/**
 * 投诉渠道：能打的电话直接一键拨打，网址只能复制
 * （小程序 web-view 只能打开自己名下已备案域名的页面，外部网址无法直接跳转）
 */
const CHANNELS = [
  { name: '12326 民航服务质量监督', desc: '民航局官方，航空类纠纷首选，7×24 小时', level: '最管用', phone: '12326' },
  { name: '12315 消费者投诉举报', desc: '消费纠纷通用渠道，加区号可转当地', level: '通用', phone: '12315' },
  { name: '12306 铁路客服', desc: '火车票相关问题走这条', level: '铁路', phone: '12306' },
  { name: '12345 政务服务热线', desc: '涉及多部门、不知找谁时打这个', level: '兜底', phone: '12345' },
  { name: '黑猫投诉（新浪）', desc: '线上公开提交，企业有回复压力；网址已备好，复制到浏览器打开', level: '施压', url: 'https://tousu.sina.com.cn/' },
  { name: '航司官方客服', desc: '先打航司自己的客服，在「购票渠道」页可一键拨打', level: '第一步' },
];

const STEPS = [
  '第一步：找航司/平台官方客服，明确说出你的诉求，索要工号',
  '第二步：不成，要求转投诉部门，并保留受理编号',
  '第三步：仍不成，拨 12326（航空）/ 12306（铁路）/ 12315（消费）',
  '第四步：同步在黑猫投诉公开提交，附订单号与时间线',
];

const TIPS = [
  '所有沟通尽量走书面（App 内留言、邮件），别只打电话',
  '每次通话记下：时间、工号、对方答复内容',
  '诉求要写具体金额，别说"希望合理处理"',
  '别签任何含"自愿放弃"字样的协议',
  '投诉材料按时间线写清：什么时候买的、出了什么事、你要求什么',
];

// ---------- 投诉信生成器 ----------
// 纯本地拼装，不上传任何信息；只生成文本，不代提交
// 法规引用仅限真实存在的条款；模板为通用参考，不构成法律意见

// ---------- 维权证据自查清单 ----------
// 投诉信生成后弹出，帮用户快速核对"手头有哪些证据"
// 纯本地：勾选状态仅存本机 Storage（按场景区分），无后台、不上传
const EVIDENCE_BASE = [
  '订单详情页截图（含订单号、票价、实付金额）',
  '支付凭证 / 银行或第三方扣款记录',
  '与客服的沟通记录（聊天截图 / 通话录音 / 工号）',
  '诉求与对方答复的时间线（整理成文字最好用）',
];

const EVIDENCE_MAP = {
  refund: [
    '购票时「退改规则」页面截图（证明未显著提示）',
    '退票实际扣款明细截图',
    '航司官方同舱位退改标准（对比用）',
  ],
  delay: [
    '航班延误 / 取消的官方通知（短信或 App 推送）',
    '登机牌 / 电子客票行程单',
    '机场广播、电子屏或柜台告知的照片 / 录音',
    '因延误产生的食宿、交通费用凭证',
  ],
  overbook: [
    '已办理的登机牌 / 值机记录',
    '被拒登机的书面说明或现场录音',
    '原航班与改签航班的登机牌',
  ],
  baggage: [
    '行李牌 / 行李条照片',
    '现场开具的《行李运输事故记录单》',
    '行李损坏照片 / 视频',
    '行李内物品价值凭证（发票 / 购买记录）',
  ],
  markup: [
    '实际支付记录（含各项收费明细）',
    '航司官方同舱位票价截图（证明加价）',
    '出票状态查询结果（未出票 / 假票情形）',
  ],
  bundle: [
    '订单勾选项截图（证明被默认勾选）',
    '扣费短信 / 账单明细',
    '未主动选择却扣费的时间线',
  ],
};

/** 按场景组装证据清单，并从本机恢复该场景的勾选状态 */
function buildEvidence(sceneId) {
  const scene = SCENES.find((s) => s.id === sceneId) || SCENES[0];
  const saved = wx.getStorageSync(`evidence_${scene.id}`) || [];
  const wrap = (text) => ({ text, checked: saved.indexOf(text) >= 0 });
  return {
    base: EVIDENCE_BASE.map(wrap),
    specific: (EVIDENCE_MAP[scene.id] || []).map(wrap),
  };
}

const ASKS = [
  { id: 'refund', label: '全额退还票款 / 取消不合理扣费' },
  { id: 'explain', label: '书面说明扣款 / 处理依据' },
  { id: 'compensate', label: '按相关规定给予赔偿 / 补偿' },
  { id: 'receipt', label: '出具书面答复，提供工号与受理编号' },
];

// 每个场景配专属诉求：什么问题要什么赔偿，不能一锅乱炖
const ASKS_MAP = {
  refund: ['refund', 'explain'],
  delay: ['refund', 'arrange', 'receipt'],
  overbook: ['reroute', 'compensate', 'receipt'],
  baggage: ['compensate', 'receipt'],
  markup: ['refund', 'explain', 'receipt'],
  bundle: ['refund', 'receipt'],
};

// 场景专属诉求里用到的扩展项（挂到 ASKS_MAP 场景下动态取词）
const ASK_EXTRA = {
  arrange: '安排必要的食宿与地面交通，或免费改签至最近可用航班',
  reroute: '优先安排改签至最近可用航班，并承担因此产生的食宿与交通费用',
};

/**
 * 按场景生成诉求列表（含场景专属项与勾选态）。
 * ⚠️ 坑：WXML 表达式是编译期静态校验，不支持 indexOf 等方法调用，
 * 三元里的 indexOf 会静默退化成 false——表现为"方框永远点不亮"。
 * 所以勾选态必须在 JS 层预计算成 item.checked 布尔字段，wxml 只做属性访问。
 */
function buildAskItems(sceneIndex, defaultCheckedIds) {
  const scene = SCENES[sceneIndex] || SCENES[0];
  const ids = ASKS_MAP[scene.id] || ASKS_MAP.refund;
  const checked = defaultCheckedIds || [];
  return ids.map((id) => {
    const base = ASKS.find((a) => a.id === id);
    return {
      id,
      label: base ? base.label : ASK_EXTRA[id],
      checked: checked.indexOf(id) >= 0,
    };
  });
}

// 每种问题类型对应的"事情经过"草稿与法规落点
const LETTER_BODY = {
  refund: '本人购买的机票（详见上文订单信息）在申请退票时，被扣除了绝大部分票款，退票比例远高于购票时贵司页面明示的标准，且扣款依据未向本人清楚说明。',
  delay: '本人所乘航班因航司自身原因延误（/取消）超过 4 小时，柜台未按运输总条件为本人办理全额退票或免费改签，亦未安排必要的食宿与地面交通。',
  overbook: '本人持有已确认客票并已办理值机，却在登机时被以"航班超售"为由拒绝登机，贵司未优先安排后续航班，亦未主动提出补偿方案。',
  baggage: '本人托运的行李抵达后未能正常提取（/已损坏），贵司现场未及时出具《行李运输事故记录单》，后续亦未给出明确的处理时限。',
  markup: '本人在贵平台购买的机票，实际支付价格高于航司官方同舱位价格（/付款后长时间查不到票号），收费明细与出票状态均未得到清楚说明。',
  bundle: '本人在贵平台购票过程中，被默认勾选了并未主动选择的增值服务（保险 / 加速包 / 套餐），支付后才发现，取消与退款流程繁琐。',
};

const LETTER_LAW = {
  refund: '依据《消费者权益保护法》第八条、第二十六条，消费者享有知悉商品或服务真实情况的权利，经营者不得以格式条款作出排除或限制消费者权利、减轻或免除自身责任的规定。',
  delay: '依据《消费者权益保护法》第八条及民航旅客运输相关服务规范，航班延误或取消后，承运人应按约定与规定为旅客办理退改签，并承担相应安排义务。',
  overbook: '依据民航旅客运输相关服务规范，因超售导致已确认旅客无法乘机的，承运人应优先安排改签并按规定给予补偿，同时承担已确认旅客的食宿与交通费用。',
  baggage: '依据民航行李运输相关服务规范，行李运输发生事故的，承运人应及时出具事故记录单，并在规定期限内答复查询结果、依法承担赔偿责任。',
  markup: '依据《消费者权益保护法》第八条及《电子商务法》第十七条，经营者应当全面、真实、准确、及时披露商品或服务信息，不得虚假宣传或误导消费者。',
  bundle: '依据《消费者权益保护法》第九条及《电子商务法》第十九条，经营者搭售商品或服务，应当以显著方式提请消费者注意，不得将搭售作为默认同意选项。',
};

function todayText() {
  const d = new Date();
  return `${d.getFullYear()} 年 ${d.getMonth() + 1} 月 ${d.getDate()} 日`;
}

const share = require('../../utils/share');
Page({
  data: {
    scenes: SCENES,
    channels: CHANNELS,
    steps: STEPS,
    tips: TIPS,
    active: 'refund',
    current: SCENES[0],
    // 投诉信生成器
    mode: 'scene', // scene=照话说 letter=写投诉信
    sceneIndex: 0,
    currentAskItems: buildAskItems(0, ASKS_MAP.refund), // 当前场景的诉求（含勾选态，随问题类型切换）
    letter: {
      target: 'airline',
      name: '',
      contact: '',
      orderNo: '',
      flightNo: '',
      flightDate: '', // 信里展示：2026 年 10 月 16 日
      flightDateRaw: '', // 日期选择器回显：2026-10-16
      amount: '',
    },
    letterText: '',
    // 证据清单弹层
    showEvidence: false,
    evidenceBase: [],
    evidenceSpecific: [],
    evidenceTotal: 0,
    evidenceChecked: 0,
  },

  onPick(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({ active: id, current: SCENES.find((s) => s.id === id) || SCENES[0] });
  },

  switchMode(e) {
    haptic.light();
    this.setData({ mode: e.currentTarget.dataset.mode });
  },

  onSceneChange(e) {
    const idx = Number(e.detail.value) || 0;
    const scene = SCENES[idx] || SCENES[0];
    // 换问题类型 = 换一套诉求：勾选态重置为该场景专属项
    this.setData({
      sceneIndex: idx,
      currentAskItems: buildAskItems(idx, ASKS_MAP[scene.id] || ASKS_MAP.refund),
    });
  },

  onTargetChange(e) {
    haptic.light();
    this.setData({ 'letter.target': e.currentTarget.dataset.value });
  },

  onLetterInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [`letter.${field}`]: e.detail.value });
  },

  /** 日期选择器：picker 给 2026-10-16，信里转成中文格式 */
  onFlightDateChange(e) {
    haptic.light();
    const raw = e.detail.value || '';
    const parts = raw.split('-');
    const text = parts.length === 3
      ? `${parts[0]} 年 ${Number(parts[1])} 月 ${Number(parts[2])} 日`
      : raw;
    this.setData({ 'letter.flightDateRaw': raw, 'letter.flightDate': text });
  },

  onAskToggle(e) {
    haptic.light();
    const id = e.currentTarget.dataset.id;
    // 单一数据源：勾选态只存 currentAskItems[].checked，避免两份状态不同步
    const items = this.data.currentAskItems.map((a) => (
      a.id === id ? { id: a.id, label: a.label, checked: !a.checked } : a
    ));
    this.setData({ currentAskItems: items });
  },

  /** 当前场景的诉求列表（含勾选态） */
  currentAsks() {
    return this.data.currentAskItems;
  },

  /** 填空拼装投诉信；未填项用下划线留白，提醒手写补充 */
  blank(v) {
    const s = String(v || '').trim();
    return s || '＿＿＿';
  },

  generateLetter() {
    haptic.light();
    const L = this.data.letter;
    const scene = SCENES[this.data.sceneIndex] || SCENES[0];
    const target = L.target === 'platform' ? '订票平台' : '航空公司';
    const asks = this.currentAsks().filter((a) => a.checked).map((a) => a.label);
    if (!asks.length) {
      wx.showToast({ title: '至少勾一项诉求', icon: 'none' });
      return;
    }
    const askLines = asks.map((t, i) => `${i + 1}、${t}${i === asks.length - 1 ? '。' : '；'}`).join('\n');
    const text = [
      `致${target}客服部 / 投诉受理部门：`,
      '',
      `本人${this.blank(L.name)}，手机号 ${this.blank(L.contact)}。现就本人购票 / 乘机过程中遇到的问题，向贵司正式提出投诉。`,
      '',
      '一、订单与航班信息',
      `投诉对象：${target}`,
      `订单号 / 票号：${this.blank(L.orderNo)}`,
      `航班号：${this.blank(L.flightNo)}`,
      `航班日期：${this.blank(L.flightDate)}`,
      `涉及金额：${this.blank(L.amount)} 元`,
      '',
      '二、事情经过',
      LETTER_BODY[scene.id] || LETTER_BODY.refund,
      '',
      '三、本人认为不妥之处',
      LETTER_LAW[scene.id] || LETTER_LAW.refund,
      '',
      '四、本人诉求',
      askLines,
      '',
      '五、答复要求',
      '请在收到本函后 7 个工作日内书面答复本人，并告知工号与受理编号。如逾期未获满意答复，本人将向 12326 民航服务质量监督热线、12315 消费者投诉热线继续反映，并保留在法律框架内继续维护自身权益的权利。',
      '',
      `投诉人：${this.blank(L.name)}`,
      `联系电话：${this.blank(L.contact)}`,
      `日期：${todayText()}`,
    ].join('\n');
    const ev = buildEvidence(scene.id);
    const evTotal = ev.base.length + ev.specific.length;
    const evChecked = ev.base.filter((i) => i.checked).length + ev.specific.filter((i) => i.checked).length;
    this.setData({
      letterText: text,
      showEvidence: true,
      evidenceBase: ev.base,
      evidenceSpecific: ev.specific,
      evidenceTotal: evTotal,
      evidenceChecked: evChecked,
    });
    // 生成后自动把页面滚到投诉信卡片，避免信被弹层挡住后找不到
    setTimeout(() => {
      wx.pageScrollTo({ selector: '#letterCard', duration: 300 });
    }, 60);
    tap('gen_letter', { scene: scene.id, target: L.target });
  },

  copyLetter() {
    if (!this.data.letterText) return;
    wx.setClipboardData({
      data: this.data.letterText,
      success: () => {
        haptic.light();
        wx.showToast({ title: '投诉信已复制', icon: 'none', duration: 2000 });
      },
    });
  },

  /** 重新打开证据清单（结果卡片里的入口） */
  openEvidence() {
    if (this.data.evidenceBase.length || this.data.evidenceSpecific.length) {
      this.setData({ showEvidence: true });
      return;
    }
    const scene = SCENES[this.data.sceneIndex] || SCENES[0];
    const ev = buildEvidence(scene.id);
    const evTotal = ev.base.length + ev.specific.length;
    const evChecked = ev.base.filter((i) => i.checked).length + ev.specific.filter((i) => i.checked).length;
    this.setData({
      showEvidence: true,
      evidenceBase: ev.base,
      evidenceSpecific: ev.specific,
      evidenceTotal: evTotal,
      evidenceChecked: evChecked,
    });
  },

  /** 勾选 / 取消某条证据，并把勾选态存到本机 */
  toggleEvidence(e) {
    const text = e.currentTarget.dataset.text;
    haptic.light();
    const flip = (arr) => arr.map((i) => (i.text === text ? { text: i.text, checked: !i.checked } : i));
    const base = flip(this.data.evidenceBase);
    const specific = flip(this.data.evidenceSpecific);
    const checked = base.filter((i) => i.checked).length + specific.filter((i) => i.checked).length;
    this.setData({ evidenceBase: base, evidenceSpecific: specific, evidenceChecked: checked });
    const scene = SCENES[this.data.sceneIndex] || SCENES[0];
    const allChecked = base.concat(specific).filter((i) => i.checked).map((i) => i.text);
    wx.setStorageSync(`evidence_${scene.id}`, allChecked);
  },

  closeEvidence() {
    this.setData({ showEvidence: false });
    // 关掉弹层后回到投诉信卡片，信始终在眼前
    setTimeout(() => {
      wx.pageScrollTo({ selector: '#letterCard', duration: 300 });
    }, 60);
  },

  noop() {},

  copyScript() {
    wx.setClipboardData({
      data: this.data.current.script,
      success: () => {
        haptic.light();
        wx.showToast({ title: '话术已复制', icon: 'none', duration: 2000 });
      },
    });
  },

  copyWhen() {
    wx.setClipboardData({
      data: this.data.current.when,
      success: () => wx.showToast({ title: '已复制', icon: 'none', duration: 2000 }),
    });
  },

  /** 一键拨打投诉电话（维权页目的明确，直接拨） */
  makeCall(e) {
    const phone = String(e.currentTarget.dataset.phone || '').replace(/[^\d+]/g, '');
    if (!phone) return;
    tap('call_rights', { phone });
    haptic.light();
    wx.makePhoneCall({
      phoneNumber: phone,
      fail: () => {
        wx.showToast({ title: '未调起拨号，请手动拨打 ' + phone, icon: 'none' });
      },
    });
  },

  /** 外部网址无法在小程序内跳转，复制后引导到浏览器打开 */
  copyUrl(e) {
    const url = e.currentTarget.dataset.url;
    if (!url) return;
    tap('copy_url', { url });
    wx.setClipboardData({
      data: url,
      success: () => {
        wx.showModal({
          title: '网址已复制',
          content: '老哥说明：小程序打不开外网，你用手机浏览器打开，把网址粘到地址栏就行。',
          confirmText: '我知道了',
          showCancel: false,
        });
      },
    });
  },

  goDelay() {
    wx.navigateTo({ url: '/pages/delay/delay' });
  },

  onShareAppMessage() {
    return share.appMessage({ title: '被坑了别认栽：投诉电话 + 现成话术都在这', path: '/pages/rights/rights' });
  },
  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    // 延误一键应对：从延误权益页带参过来 → 直接进入「延误投诉信」场景，投诉对象预设航司
    if (options && options.from === 'delay') {
      tap('rights_from_delay');
      const idx = SCENES.findIndex((s) => s.id === 'delay');
      this.setData({
        mode: 'letter',
        sceneIndex: idx > -1 ? idx : 0,
        'letter.target': 'airline',
      }, () => {
        wx.showToast({ title: '已进入延误投诉信，补全航班信息即可生成', icon: 'none', duration: 3000 });
        setTimeout(() => wx.pageScrollTo({ selector: '#letterForm', duration: 300 }), 300);
      });
    }
  },
  onShareTimeline() {
    return share.timeline({ title: '被坑了别认栽：投诉电话+话术都在这' });
  },
});
