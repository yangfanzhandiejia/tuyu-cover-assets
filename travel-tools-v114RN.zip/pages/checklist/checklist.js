const store = require('../../utils/store');
const { tap } = require('../../utils/track');

// 场景模板：清单内容融入我们的出行常识（充电宝/液体/检疫证明等防坑点）
const TEMPLATES = [
  {
    key: 'general',
    name: '通用出行',
    groups: [
      { title: '证件与票据', items: ['身份证', '车票 / 机票订单（截图留存）', '银行卡 + 少量现金', '酒店预订单'] },
      { title: '电子设备', items: ['手机 + 充电器', '充电宝（≤100Wh，且不可托运）', '数据线 / 耳机', '转换插头（出境）'] },
      { title: '液体与洗漱', items: ['单瓶 ≤100ml 的液体（合计 ≤1L）', '透明密封袋（过安检用）', '牙刷牙膏 / 洁面', '防晒 / 护肤品'] },
      { title: '衣物', items: ['按天数 + 1 套备用', '薄外套（机上空调较冷）', '舒适步行鞋', '拖鞋（长途）'] },
      { title: '药品与健康', items: ['常用药（保留原包装）', '创可贴 / 消毒棉片', '晕车药（按需）', '口罩'] },
      { title: '其他', items: ['折叠伞', '空水杯（过安检后接水）', '零食（高铁 / 长途）'] },
    ],
  },
  {
    key: 'baby',
    name: '带娃出行',
    groups: [
      { title: '证件', items: ['儿童身份证 / 户口本', '出生证明（婴儿票需要）', '预防接种证（按需）'] },
      { title: '喂养', items: ['奶粉（分装）', '奶瓶 + 奶嘴 2 个', '辅食 / 成品泥', '保温杯（装温水）'] },
      { title: '护理', items: ['纸尿裤（按天数 + 2 天量）', '湿巾 / 纸巾', '隔尿垫', '替换衣物 2 套'] },
      { title: '哄娃', items: ['小玩具 / 绘本', '零食', '安抚玩偶', '平板（提前下载动画片）'] },
      { title: '装备', items: ['婴儿车（可登机口托运）', '背带 / 腰凳', '儿童安全座椅（自驾）'] },
    ],
  },
  {
    key: 'elder',
    name: '长辈出行',
    groups: [
      { title: '证件', items: ['身份证', '医保卡', '老年证 / 优待证（景区优惠）', '紧急联系人卡片'] },
      { title: '药品', items: ['日常用药（按天分装 + 原包装）', '急救药（如硝酸甘油）', '用药清单 / 病历摘要', '血压计（按需）'] },
      { title: '辅助器具', items: ['拐杖 / 助行器', '老花镜', '助听器 + 备用电池', '护膝 / 护腰'] },
      { title: '舒适', items: ['靠枕 / 颈枕', '保暖外套', '软底防滑鞋', '保温杯'] },
    ],
  },
  {
    key: 'pet',
    name: '带宠出行',
    groups: [
      { title: '证件（最关键）', items: ['动物检疫合格证明', '狂犬疫苗证明（21 天以上）', '宠物身份牌 / 芯片信息'] },
      { title: '装备', items: ['符合航司尺寸的航空箱', '牵引绳', '嘴套（部分航司要求）', '航空箱标识贴'] },
      { title: '食物', items: ['宠物粮（按天数）', '便携水碗', '零食'] },
      { title: '清洁与安抚', items: ['尿垫 / 猫砂（少量）', '清洁袋 / 拾便袋', '安抚玩具 / 熟悉的小毯子'] },
    ],
  },
  {
    key: 'camp',
    name: '露营 / 户外',
    groups: [
      { title: '住宿', items: ['帐篷 + 地钉', '防潮垫 / 充气垫', '睡袋（按季节温标）', '营地灯 / 头灯'] },
      { title: '炊具', items: ['炉头 + 气罐', '锅具 / 餐具', '保温壶', '垃圾袋（无痕露营）'] },
      { title: '衣物', items: ['冲锋衣 / 雨衣', '登山鞋', '保暖层（抓绒 / 羽绒）', '备用袜子'] },
      { title: '安全', items: ['急救包', '驱蚊 / 防晒', '充电宝（大容量）', '离线地图 / 指南针'] },
    ],
  },
  {
    key: 'bike',
    name: '骑行 / 自驾',
    groups: [
      { title: '车辆', items: ['打气筒 / 补胎工具', '备用内胎', '链条油', '车前灯 + 尾灯'] },
      { title: '安全', items: ['头盔', '骑行手套', '反光背心', '维修工具（六角扳手）'] },
      { title: '补给', items: ['水壶 / 水袋', '能量胶 / 零食', '备用电量（导航）'] },
      { title: '其他', items: ['驮包 / 车尾包', '雨衣', '身份证 + 保险卡'] },
    ],
  },
  {
    key: 'cruise',
    name: '邮轮 / 海岛',
    groups: [
      { title: '证件', items: ['护照（有效期 6 个月以上）', '签证 / 落地签材料', '船票确认单', '身份证'] },
      { title: '衣物', items: ['泳衣 2 套', '防晒衣 / 帽子', '正装（船长晚宴）', '拖鞋 / 凉鞋'] },
      { title: '防护', items: ['高倍防晒霜（珊瑚友好型）', '晕船药', '防水手机袋', '墨镜'] },
      { title: '其他', items: ['常用药', '转换插头', '浮潜装备（可选）', '现金（小费）'] },
    ],
  },
  {
    key: 'student',
    name: '学生 / 穷游',
    groups: [
      { title: '证件（能省钱）', items: ['学生证（景区/车票优惠）', '身份证', '银行卡（少带现金）', '准考证 / 录取通知书（部分优惠）'] },
      { title: '住宿', items: ['青旅 / 民宿（看评价与退改）', '一次性床单被套', '耳塞 + 眼罩', '拖鞋 + 洗漱包'] },
      { title: '省钱装备', items: ['折叠水杯（接直饮水）', '充电宝 + 多口充电器', '干粮 / 零食', '雨伞 / 雨衣'] },
      { title: '安全', items: ['行程截图发给家人', '常用药（小包装）', '防盗腰包 / 挂脖卡包', '备用现金（少量）'] },
    ],
  },
  {
    key: 'ski',
    name: '滑雪 / 冰雪',
    groups: [
      { title: '雪具', items: ['雪板 / 雪杖（或租赁）', '雪鞋（合脚最重要）', '固定器调节工具', '雪板包 / 背带'] },
      { title: '保暖', items: ['滑雪服（防水防风）', '雪袜（备用 2 双）', '抓绒 / 羽绒内胆', '保暖手套 2 副'] },
      { title: '防护', items: ['头盔（必带）', '雪镜（防紫外线）', '护脸 / 面罩', '防晒霜 + 唇膏（雪地反光强）'] },
      { title: '其他', items: ['护具（护臀/护膝，初学者）', '暖宝宝', '防水袋（装湿衣物）', '保温杯'] },
    ],
  },
  {
    key: 'hometown',
    name: '探亲 / 返乡',
    groups: [
      { title: '证件', items: ['身份证', '车票（纸质或截图）', '健康卡 / 医保卡', '现金红包（用红包装好）'] },
      { title: '伴手礼', items: ['给长辈的礼品（按需提前买）', '给小孩的零食 / 玩具', '特产（注意保质期与托运规定）'] },
      { title: '自用', items: ['换洗衣物（按天数）', '常备药', '充电宝', '洗漱用品（老家可能不全）'] },
      { title: '注意', items: ['液体 / 酒类留意托运规定', '生鲜、自制食品不宜携带', '礼物发票留存（便于退换）'] },
    ],
  },
  {
    key: 'hike',
    name: '徒步 / 登山',
    groups: [
      { title: '装备', items: ['登山鞋（防滑、提前磨合）', '登山杖（保护膝盖）', '登山包（背负系统合身）', '头灯 + 备用电池'] },
      { title: '衣物', items: ['速干衣裤', '冲锋衣（防风防雨）', '保暖层（抓绒 / 羽绒）', '备用袜子'] },
      { title: '补给', items: ['饮用水（足量）', '高能量零食', '简易午餐', '电解质补充'] },
      { title: '安全', items: ['离线地图 / 轨迹', '急救包（创可贴、绷带）', '哨子 / 充电宝', '把行程告知家人'] },
    ],
  },
  {
    key: 'biz',
    name: '出差办公',
    groups: [
      { title: '证件', items: ['身份证', '名片', '工作证 / 门禁卡', '邀请函 / 会议通知'] },
      { title: '办公', items: ['笔记本 + 充电器', '转换头 / 插排', 'U 盘 / 移动硬盘', '合同或资料（纸质 + 电子）'] },
      { title: '形象', items: ['正装 / 衬衫', '皮鞋 + 袜子', '领带 / 配饰', '便携挂烫（按需）'] },
      { title: '其他', items: ['发票袋（收纳票据）', '洗漱包', '常备药'] },
    ],
  },
];

const share = require('../../utils/share');
Page({
  data: {
    templates: TEMPLATES.map((t) => ({ key: t.key, name: t.name })),
    curKey: 'general',
    groups: [],
    customs: [],
    done: 0,
    total: 0,
  },

  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    // 好友从分享卡片进来时，直接打开对应场景
    const fromShare = options && options.tpl ? options.tpl : '';
    const last = store.getLastTpl();
    this.applyTpl(fromShare || last || 'general');
  },

  applyTpl(key) {
    const self = this;
    const tpl = TEMPLATES.find((t) => t.key === key) || TEMPLATES[0];
    const checked = store.getChecklist();
    const groups = tpl.groups.map((g, gi) => ({
      title: g.title,
      items: g.items.map((name, ii) => {
        const k = tpl.key + '|' + gi + '|' + ii;
        return { name: name, key: k, on: !!checked[k] };
      }),
    }));
    // 自定义物品（按场景归属）
    const customMap = store.getCustomItems();
    const customs = (customMap[tpl.key] || []).map((c) => {
      const k = 'custom|' + tpl.key + '|' + c.name;
      return { name: c.name, key: k, on: !!checked[k] };
    });
    let done = 0;
    let total = 0;
    groups.forEach((g) => g.items.forEach((i) => {
      total += 1;
      if (i.on) done += 1;
    }));
    customs.forEach((i) => {
      total += 1;
      if (i.on) done += 1;
    });
    self.setData({ curKey: tpl.key, groups: groups, customs: customs, done: done, total: total });
  },

  onSwitchTpl(e) {
    const key = e.currentTarget.dataset.key;
    if (key === this.data.curKey) return;
    tap('checklist_switch', { key: key });
    store.saveLastTpl(key);
    this.applyTpl(key);
  },

  onToggle(e) {
    const key = e.currentTarget.dataset.key;
    const checked = store.getChecklist();
    checked[key] = !checked[key];
    store.saveChecklist(checked);
    tap('checklist_toggle');
    const groups = this.data.groups.map((g) => ({
      title: g.title,
      items: g.items.map((i) => (i.key === key ? { name: i.name, key: i.key, on: checked[key] } : i)),
    }));
    const customs = this.data.customs.map((i) => (i.key === key ? { name: i.name, key: i.key, on: checked[key] } : i));
    let done = 0;
    groups.forEach((g) => g.items.forEach((i) => { if (i.on) done += 1; }));
    customs.forEach((i) => { if (i.on) done += 1; });
    this.setData({ groups: groups, customs: customs, done: done });
  },

  /** 添加自定义物品（挂在当前场景） */
  onAddCustom() {
    const self = this;
    wx.showModal({
      title: '添加我的物品',
      placeholderText: '如：奶奶的降压药',
      editable: true,
      success: function (res) {
        if (!res.confirm) return;
        const name = (res.content || '').trim();
        if (!name) return;
        if (name.length > 20) {
          wx.showToast({ title: '名称请控制在 20 字内', icon: 'none' });
          return;
        }
        const key = self.data.curKey;
        const all = store.getCustomItems();
        all[key] = all[key] || [];
        const exist = all[key].filter((x) => x.name === name).length > 0;
        if (exist) {
          wx.showToast({ title: '已经有这项了', icon: 'none' });
          return;
        }
        all[key].push({ name: name });
        store.saveCustomItems(all);
        self.applyTpl(key);
        wx.showToast({ title: '已添加' });
      },
    });
  },

  /** 删除自定义物品 */
  onDelCustom(e) {
    const name = e.currentTarget.dataset.name;
    const self = this;
    wx.showModal({
      title: '删除物品',
      content: '确定删除「' + name + '」吗？',
      success: function (res) {
        if (!res.confirm) return;
        const key = self.data.curKey;
        const all = store.getCustomItems();
        all[key] = (all[key] || []).filter((x) => x.name !== name);
        store.saveCustomItems(all);
        // 同时清掉它的勾选状态
        const checked = store.getChecklist();
        delete checked['custom|' + key + '|' + name];
        store.saveChecklist(checked);
        self.applyTpl(key);
        wx.showToast({ title: '已删除', icon: 'none' });
      },
    });
  },

  onReset() {
    const self = this;
    wx.showModal({
      title: '清空勾选',
      content: '将取消当前清单的所有勾选，确定吗？',
      success: function (res) {
        if (!res.confirm) return;
        const checked = store.getChecklist();
        self.data.groups.forEach((g) => g.items.forEach((i) => { delete checked[i.key]; }));
        (self.data.customs || []).forEach((i) => { delete checked[i.key]; });
        store.saveChecklist(checked);
        self.applyTpl(self.data.curKey);
        wx.showToast({ title: '已清空', icon: 'none' });
      },
    });
  },

  onShareAppMessage() {
    const key = this.data.curKey;
    const tpl = TEMPLATES.filter((t) => t.key === key)[0] || TEMPLATES[0];
    return share.appMessage({
      title: '【' + tpl.name + '】出行打包清单 · 逐项勾选不遗漏',
      path: '/pages/checklist/checklist?tpl=' + key,
    });
  },
  onShareTimeline() {
    return share.timeline({ title: '出行前检查清单，照着勾不漏带' });
  },
});
