const { TOOLS, TOOL_GROUPS } = require('../../data/tools');
const { tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    groups: TOOL_GROUPS.map((g) => ({
      key: g.key,
      title: g.title,
      sub: g.sub,
      tools: TOOLS.filter((t) => t.group === g.key),
    })),
  },

  goTool(e) {
    tap('go_tool', { url: e.currentTarget.dataset.url });
    haptic.light();
    wx.navigateTo({ url: e.currentTarget.dataset.url });
  },

  onTabItemTap(e) {
    track('tab_switch', { page: e.pagePath });
    haptic.light();
  },

  onShareAppMessage() {
    return share.appMessage({ title: '途悦出行防坑：退改签、行李、税费一键算', path: '/pages/index/index' });
  },
  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },
  onShareTimeline() {
    return share.timeline({ title: '出行工具箱，算限行算时差一键搞定' });
  },
});
