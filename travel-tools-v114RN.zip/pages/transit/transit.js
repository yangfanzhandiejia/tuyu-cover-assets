/**
 * 中转时间够不够
 * 纯本地计算。建议值为行业通行经验，最终以机场与航司现场要求为准。
 */

const TYPES = [
  { key: 'dd', label: '国内转国内', base: 90 },
  { key: 'di', label: '国内转国际', base: 120 },
  { key: 'id', label: '国际转国内', base: 120 },
  { key: 'ii', label: '国际转国际', base: 120 },
];

const TICKETS = [
  { key: 'joint', label: '联程票（一个订单）', add: 0 },
  { key: 'split', label: '分开买的两段票', add: 75 },
];

const AIRPORTS = [
  { key: 'same', label: '同一个机场', add: 0 },
  { key: 'cross', label: '要换机场（如虹桥→浦东）', add: 150 },
];

const EXTRAS = [
  { key: 'visa', label: '中转地需要过境签证', add: 60 },
  { key: 'peak', label: '节假日 / 超大机场', add: 30 },
  { key: 'family', label: '带老人小孩或行李多', add: 30 },
];

const MINUTES = [45, 60, 75, 90, 105, 120, 150, 180, 210, 240, 300, 360];

function fmtMin(m) {
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (h && r) return h + ' 小时 ' + r + ' 分';
  if (h) return h + ' 小时';
  return m + ' 分钟';
}

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    types: TYPES,
    tickets: TICKETS,
    airports: AIRPORTS,
    extras: EXTRAS.map((x) => Object.assign({}, x, { on: false })),
    minutes: MINUTES,
    minuteLabels: MINUTES.map(fmtMin),
    minuteIndex: 4,      // 默认 105 分钟
    type: 'dd',
    ticket: 'joint',
    airport: 'same',
    picked: [],
    result: null,
  },

  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    this.compute();
  },

  onPickType(e) { this.setData({ type: e.currentTarget.dataset.key }, () => this.compute()); },
  onPickTicket(e) { this.setData({ ticket: e.currentTarget.dataset.key }, () => this.compute()); },
  onPickAirport(e) { this.setData({ airport: e.currentTarget.dataset.key }, () => this.compute()); },

  onPickExtra(e) {
    const key = e.currentTarget.dataset.key;
    const picked = this.data.picked.slice();
    const i = picked.indexOf(key);
    if (i > -1) picked.splice(i, 1); else picked.push(key);
    // 同步每项的选中态（WXML 不支持 indexOf，选中样式在 JS 侧算好）
    const extras = this.data.extras.map((x) => Object.assign({}, x, { on: picked.indexOf(x.key) > -1 }));
    this.setData({ picked, extras }, () => this.compute());
  },

  onPickMinute(e) {
    this.setData({ minuteIndex: parseInt(e.detail.value, 10) }, () => this.compute());
  },

  compute() {
    const { type, ticket, airport, picked, minuteIndex, minutes } = this.data;
    const t = TYPES.find((x) => x.key === type) || TYPES[0];
    const tk = TICKETS.find((x) => x.key === ticket) || TICKETS[0];
    const ap = AIRPORTS.find((x) => x.key === airport) || AIRPORTS[0];
    let need = t.base + tk.add + ap.add;
    const reasons = ['基础建议 ' + fmtMin(t.base)];
    if (tk.add) reasons.push('分开买的两段票，要取行李重新值机安检 +' + tk.add + ' 分钟');
    if (ap.add) reasons.push('跨机场中转，地面交通 +' + ap.add + ' 分钟');
    picked.forEach((k) => {
      const ex = EXTRAS.find((x) => x.key === k);
      if (ex) { need += ex.add; reasons.push(ex.label + ' +' + ex.add + ' 分钟'); }
    });

    const mine = minutes[minuteIndex];
    const gap = mine - need;
    let level;
    let levelColor;
    let verdict;
    if (gap < 0) {
      level = '偏紧，有风险';
      levelColor = '#b47630';
      verdict = '你的中转时间比建议少了 ' + fmtMin(-gap) + '。前一段只要晚点一点，后一段就赶不上。';
    } else if (gap < 30) {
      level = '刚好够，但不宽裕';
      levelColor = '#e8890c';
      verdict = '理论上够，但没有余量。前一段晚点半小时以上就会很被动。';
    } else {
      level = '时间充足';
      levelColor = '#1a8f45';
      verdict = '留出了 ' + fmtMin(gap) + ' 的余量，正常情况不用担心。';
    }

    const tips = [];
    if (ticket === 'joint') {
      tips.push('联程票（一个订单）：前段延误导致赶不上后段，由航司负责改签安排，你不用再掏钱');
      tips.push('行李一般可以直挂到目的地，中途不用取');
    } else {
      tips.push('分开买的两段票：前段赶不上，后段按误机处理，票款可能一分不退');
      tips.push('必须先取行李、重新办值机和安检，别按联程的时间算');
      tips.push('真要分开买，建议两段之间至少留 3 小时');
    }
    if (airport === 'cross') {
      tips.push('跨机场中转要先算地面交通时间，地铁一般 1–1.5 小时，打车遇堵更久');
    }
    if (picked.indexOf('visa') > -1) {
      tips.push('需要过境签的中转，务必提前办妥，没有签证会被拒绝登机');
    }

    this.setData({
      result: {
        needText: fmtMin(need),
        mineText: fmtMin(mine),
        level,
        levelColor,
        verdict,
        reasons,
        tips,
      },
    });
  },

  onShareAppMessage() {
    return share.appMessage({ title: '中转时间够不够？先算一下再买联程票', path: '/pages/transit/transit' });
  },
  onShareTimeline() {
    return share.timeline({ title: '中转航班怎么衔接？别误机' });
  },
});
