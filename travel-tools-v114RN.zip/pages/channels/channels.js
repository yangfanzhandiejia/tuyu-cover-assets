const { GROUPS, getGroup, getVisibleGroups, CONFIG } = require('../../data/channels');
const store = require('../../utils/store');
const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');

const share = require('../../utils/share');
Page({
  data: {
    from: '',
    to: '',
    date: '',
    dateCN: '',
    via: '',
    type: 'flight',
    typeLabel: '飞机',
    isCombo: false,
    groups: [],          // 按后台配置过滤后的可见分组（Tab）
    activeGroup: 'ota',
    currentDesc: '',
    channels: [],
    hasRoute: false,     // 是否已有路线数据（用于提示）
  },

  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    let from = decodeURIComponent(options.from || '');
    let to = decodeURIComponent(options.to || '');
    let date = options.date || '';
    let dateCN = options.dateCN || date;
    let via = decodeURIComponent(options.via || '');
    let type = options.type || 'flight';

    // 关键：若未通过参数传入（例如直接进入购票渠道页），则读取首页/我的行程保存的「最近路线」
    if (!from && !to) {
      const cur = store.getCurrent();
      if (cur) {
        from = cur.from || '';
        to = cur.to || '';
        date = cur.date || '';
        dateCN = cur.dateCN || date;
        via = cur.via || '';
        type = cur.type || type;
      }
    }

    const typeLabel = type === 'train' ? '高铁火车' : type === 'combo' ? '飞机+高铁' : '飞机';
    // 优先使用首页传入的分类，否则根据出行类型推断默认分组
    let group = options.group || (type === 'train' ? 'train' : 'airline');
    // 若该分组被后台配置隐藏，则回退到第一个可见分组
    const visKeys = getVisibleGroups().map((g) => g.key);
    if (visKeys.indexOf(group) === -1) group = visKeys[0] || 'ota';

    this.setData({
      from, to, date, dateCN, via, type, typeLabel,
      isCombo: type === 'combo',
      hasRoute: !!(from && to),
      groups: getVisibleGroups(),
    });
    this.loadGroup(group);
  },

  loadGroup(key) {
    const g = getGroup(key);
    if (!g) return;
    const channels = g.channels.map((c) => ({ ...c }));
    this.setData({ activeGroup: g.key, currentDesc: g.desc, channels });
  },

  onTapGroup(e) {
    haptic.light();
    tap('tap_channel_group', { key: e.currentTarget.dataset.key });
    this.loadGroup(e.currentTarget.dataset.key);
  },

  /**
   * 跳转函数：尝试跳转到对应小程序（appid 为预留变量，在 data/channels.js 配置）。
   * 跳转失败（未配置 appid / 测试号 / 无权限等）则复制名称并弹窗引导用户去微信搜一搜。
   */
  onTapChannel(e) {
    const id = e.currentTarget.dataset.id;
    const item = this.data.channels.find((c) => c.id === id);
    if (!item) return;
    haptic.light();
    tap('tap_channel', { id, hasAppid: !!item.appid });

    if (item.appid) {
      const params = {
        appId: item.appid, // 预留的官方小程序 AppID 变量
        envVersion: 'release',
        fail: () => this.copyGuide(item),
      };
      if (item.path) params.path = item.path;
      wx.navigateToMiniProgram(params);
    } else {
      this.copyGuide(item);
    }
  },

  /**
   * 点击客服电话：先弹菜单，再决定拨打还是复制。
   * 渠道页是「找入口跳转」的地方，手指一直在点，一碰就拨容易误触。
   * 号码里的横杠、空格要先清掉（如 028-66668888、400-102-6666）。
   */
  callTel(e) {
    const raw = String(e.currentTarget.dataset.tel || '');
    const tel = raw.replace(/[^\d+]/g, '');
    if (!tel) return;
    tap('tap_channel_tel', { tel });
    wx.showActionSheet({
      itemList: ['拨打 ' + tel, '复制号码'],
      success: (r) => {
        if (r.tapIndex === 0) {
          tap('call_channel', { tel });
          haptic.light();
          wx.makePhoneCall({ phoneNumber: tel, fail: () => {} });
        } else if (r.tapIndex === 1) {
          wx.setClipboardData({
            data: tel,
            success: () => wx.showToast({ title: '号码已复制', icon: 'none', duration: 1800 }),
          });
        }
      },
      fail: () => {}, // 用户取消，静默处理
    });
  },

  // 兜底：复制渠道名称，并弹窗提示「去微信搜一搜打开」
  copyGuide(item) {
    tap('copy_guide', { id: item.id });
    wx.setClipboardData({
      data: item.search || item.name,
      success: () => {
        wx.showModal({
          title: '复制名称，去微信搜一搜',
          content: `已复制「${item.name}」，打开微信「搜一搜」粘贴，搜它的官方小程序打开。`,
          confirmText: '我知道了',
          showCancel: false,
        });
      },
      fail: () => {
        wx.showModal({
          title: '复制名称，去微信搜一搜',
          content: `打开微信「搜一搜」，搜「${item.name}」官方小程序打开。`,
          confirmText: '我知道了',
          showCancel: false,
        });
      },
    });
  },

  onTabItemTap(e) {
    track('tab_switch', { page: e.pagePath });
  },

  onShareAppMessage() {
    return share.appMessage({ title: '途悦出行防坑：汇集航司、12306、正规平台官方购票入口', path: '/pages/index/index' });
  },
  onShareTimeline() {
    return share.timeline({ title: '维权渠道都在这，被坑了别认栽' });
  },
});
