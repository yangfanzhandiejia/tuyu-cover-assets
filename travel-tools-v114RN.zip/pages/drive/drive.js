// 自驾计算：成本 / 续航估算 / 限行速查 / 行程时长 / 检查清单 / 驾驶计时 / 免费卡点
// 纯前端估算，费率与限行规则会变动，结果仅供参考，以官方为准

const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');

function r1(n) { return Math.round(n * 10) / 10; }
function r2(n) { return Math.round(n * 100) / 100; }

// === 限行数据维护提醒（到期前请更新；改数据时同步更新 wxml 底部 note）===
// · 北京/天津 BJ_TJ_ROUNDS：官方每年 3 月底发布新一年表，本表为 2026-03-30~2027-03-28；
//   2027-03-28 到期后，用两地公安局新通告的 4 段「日期区间 + 周一~周五尾号」替换本数组即可。
// · 重庆（tail_fixed，用 STD_MAP）：渝公交管规〔2026〕1号，有效期 2027-02-28；
//   到期前确认是否延续/新分组——分组不变则只改重庆项 note 里的有效期，若变则改 STD_MAP 或重庆项 map。
// · 西安（tail_fixed）：通告有效期至 2026-11-06，到期前确认是否延续，改西安项 note 或转规则。
// · 武汉（bridge_single）：武公交规〔2024〕8号，有效期至 2029-03-03，长期基本不动。
// · 字母规则：北京/天津按 0 管理；成都/西安/郑州/兰州/杭州/重庆按末位阿拉伯数字；武汉按字母前一位数字。
// · 未含：临时交通管制、重污染预警、节假日调休上班日——页面底部提示语已兜底，需用户手动核对。
// 限行城市类型：tail_rotate=尾号轮换(京津) / tail_fixed=固定尾号(成西郑兰杭渝) /
//   bridge_single=桥隧单双号(武汉) / none=已不限行(石家庄海口) /
//   foreign_only=只限外地车(深圳上海) / cycle=开四停四(广州) / area=区域限行(苏州南京)
const BJ_TJ_ROUNDS = [
  { s: '2026-03-30', e: '2026-06-28', g: [[2,7],[3,8],[4,9],[5,0],[1,6]] },
  { s: '2026-06-29', e: '2026-09-27', g: [[1,6],[2,7],[3,8],[4,9],[5,0]] },
  { s: '2026-09-28', e: '2026-12-27', g: [[5,0],[1,6],[2,7],[3,8],[4,9]] },
  { s: '2026-12-28', e: '2027-03-28', g: [[4,9],[5,0],[1,6],[2,7],[3,8]] },
];
const STD_MAP = [[1,6],[2,7],[3,8],[4,9],[5,0]]; // 成都/西安/郑州/兰州（周一..周五）
const HZ_MAP  = [[1,9],[2,8],[3,7],[4,6],[5,0]]; // 杭州错峰（仅快速路/高架）

const CITIES = [
  { city: '北京', type: 'tail_rotate', rounds: BJ_TJ_ROUNDS, scope: '五环路以内（不含五环）', local: true, foreign: '外地车需办「进京证」，六环内工作日早晚高峰禁行', note: '尾号轮换 工作日 7:00-20:00；字母尾号按 0 管理' },
  { city: '天津', type: 'tail_rotate', rounds: BJ_TJ_ROUNDS, scope: '外环线以内（不含）', local: true, foreign: '外地车工作日早晚高峰（7-9、16-19）禁行外环内，可办通行凭证', note: '尾号轮换 工作日 7:00-19:00；字母按 0 管理' },
  { city: '成都', type: 'tail_fixed', map: STD_MAP, scope: '绕城高速(G4202)不含以内', local: true, foreign: '外地车同规则（新能源除外）', note: '尾号限行 工作日 7:30-20:00；字母按末位数字' },
  { city: '西安', type: 'tail_fixed', map: STD_MAP, scope: '全市', local: true, foreign: '外地车同规则（新能源除外）', note: '尾号限行 工作日 7:00-20:00；通告有效期至 2026-11-06，预计延续，以官方为准；字母按末位数字' },
  { city: '郑州', type: 'tail_fixed', map: STD_MAP, scope: '东/南/西/北三环（不含）以内', local: true, foreign: '外地车同规则（新能源除外）', note: '尾号限行 工作日 7:00-21:00；字母按末位数字' },
  { city: '兰州', type: 'tail_fixed', map: STD_MAP, scope: '全市', local: true, foreign: '非甘A号牌来兰当日不限，次日起同城同策', note: '尾号限行 工作日 7:30-20:00；字母按末位数字' },
  { city: '杭州', type: 'tail_fixed', map: HZ_MAP, scope: '快速路/高架（地面道路不限）', local: true, foreign: '非浙A 工作日早晚高峰全号段禁行快速路/高架，可办「急事通」', note: '错峰尾号 工作日 7:00-9:00、16:30-18:30；西湖景区 9-11 月双休/节假日单双号；字母按末位数字' },
  { city: '武汉', type: 'bridge_single', local: true, foreign: '本地外地同权，仅限长江大桥/江汉桥；出租车、新能源除外', note: '单双号：按日期单双（单日单号/双日双号）7:00-22:00；休息日/法定节假日除外（调休上班周末按工作日）；字母按前一位数字；武公交规〔2024〕8号，有效期至 2029-03-03' },
  { city: '石家庄', type: 'none', local: true, foreign: '—', note: '2023-12 起已取消机动车尾号限行' },
  { city: '海口', type: 'none', local: true, foreign: '外地车每自然年累计 ≤120 天', note: '无限号限行，仅部分单行道限时单向' },
  { city: '深圳', type: 'foreign_only', local: false, foreign: '外地车工作日早晚高峰全市禁行（需申报），无尾号限行', note: '不限尾号，主要限外地车' },
  { city: '上海', type: 'foreign_only', local: false, foreign: '外牌工作日早晚高峰高架/内环禁行，无尾号限行', note: '不限尾号，主要限外地车' },
  { city: '广州', type: 'cycle', local: false, foreign: '非粤A牌「开四停四」', note: '连续驶入管控区不超 4 天，再入须间隔满 4 天', zone: '大观路—东环高速—珠江（含主航道）—华南快速—南部合围的管控区' },
  { city: '重庆', type: 'tail_fixed', map: STD_MAP, scope: '错峰桥隧(25座：高家花园/石门/嘉华/渝澳/牛角沱/黄花园/千厮门/朝天门/东水门/石板坡/菜园坝/鹅公岩/曾家岩/双碑/大佛寺/红岩村/马桑溪/李家沱等大桥 + 真武山/双碑/大学城/中梁山隧道)', local: true, foreign: '所有渝籍/非渝籍汽车均错峰（悬挂新能源号牌除外）', note: '桥隧错峰尾号 工作日早7:00-9:00、晚17:00-19:30（仅限上述桥隧，非全市）；字母按末位数字；渝公交管规〔2026〕1号，有效期至 2027-02-28' },
  { city: '苏州', type: 'area', local: false, foreign: '古城区外地车限行', note: '工作日早晚高峰护城河内古城区外地车禁行', zone: '护城河以内古城区' },
  { city: '南京', type: 'area', local: false, foreign: '长江大桥全天禁外地车', note: '南京长江大桥全天禁止外地号牌机动车通行', zone: '南京长江大桥（非机动车/行人可通行）' },
];

// 限行数据到期日（临近到期自动在限行结果页提示，提醒更新；详见顶部维护注释）
const LIMIT_EXPIRY = {
  北京: '2027-03-28',
  天津: '2027-03-28',
  西安: '2026-11-06',
  重庆: '2027-02-28',
};
function checkLimitExpire(cityName) {
  const due = LIMIT_EXPIRY[cityName];
  if (!due) return '';
  const now = new Date();
  const dueDate = new Date(due.replace(/-/g, '/'));
  const days = Math.ceil((dueDate - now) / 86400000);
  if (days > 30) return '';                                  // 还早，不打扰
  if (days >= 0) return '⚠️ ' + cityName + '限行数据将于 ' + due + ' 到期（以当地交警最新通告为准）。如需更新请告知开发者。';
  return '⚠️ ' + cityName + '限行数据已于 ' + due + ' 到期，当前规则可能已变动，请告知开发者更新，并以官方为准。';
}

// 法定节假日安排：高速免费时段与尾号/桥隧限行暂停共用本表。2026 为已公布官方安排；
// 2027 为预估（国务院放假调休安排一般 12 月前后公布，完整连休以当年通知为准）
const HOLIDAYS = [
  { name: '春节', s: '2026-02-15', e: '2026-02-23' },
  { name: '清明', s: '2026-04-04', e: '2026-04-06' },
  { name: '劳动', s: '2026-05-01', e: '2026-05-05' },
  { name: '国庆', s: '2026-10-01', e: '2026-10-07' },
  { name: '春节', s: '2027-02-05', e: '2027-02-12', est: true },
  { name: '清明', s: '2027-04-04', e: '2027-04-06', est: true },
  { name: '劳动', s: '2027-05-01', e: '2027-05-05', est: true },
  { name: '国庆', s: '2027-10-01', e: '2027-10-07', est: true },
];

// 富化免费时段：补年份、是否过期、是否预估，并算“下一个免费时段”（进行中或未来第一个）
function enrichHolidays() {
  const d = new Date();
  const today = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const list = HOLIDAYS.map((h) => Object.assign({}, h, {
    year: h.s.slice(0, 4),
    past: h.e < today,
    est: !!h.est,
  }));
  const next = list.find((h) => h.e >= today) || null;
  return { list, next };
}

// 油价参考档位（92# 汽油大致水平，2026-10 整理）：档位仅作估算参考，
// 油价随行就市，请以当地加油站实时挂牌价为准。改档位时同步更新 wxml 底部说明
const OIL_PRESETS = [
  { label: '6.8 偏低地区', value: 6.8, note: '西北/东北部分区域' },
  { label: '7.5 多数地区', value: 7.5, note: '全国平均水平附近' },
  { label: '8.0 偏高地区', value: 8.0, note: '华南/西南山区等' },
  { label: '8.8 海南', value: 8.8, note: '含车辆通行附加费' },
];

// 出发前检查清单（仅本机存储，不联网）
const CHECK_GROUPS = [
  { g: '证件', items: ['身份证', '驾驶证', '行驶证', '交强险标志/保单', 'ETC 卡'] },
  { g: '车况', items: ['胎压（含备胎）', '机油 / 冷却液', '玻璃水', '灯光 / 雨刮', '备胎 + 换胎工具'] },
  { g: '应急', items: ['三角警示牌', '灭火器', '反光背心', '拖车绳 / 搭电线', '安全锤'] },
  { g: '电子', items: ['手机支架', '充电宝', '行车记录仪', '离线地图已下载', '车载充电线'] },
  { g: '行李', items: ['饮水', '零食 / 干粮', '急救包', '现金零钱', '纸巾'] },
];

function checkTotalCount() {
  let n = 0;
  CHECK_GROUPS.forEach((grp) => { n += grp.items.length; });
  return n;
}

const share = require('../../utils/share');
Page({
  data: {
    tab: 'cost',
    cityNames: CITIES.map((c) => c.city),
    cityIdx: 0,

    /* 成本 */
    costType: 'gas',          // gas / ev
    distance: '',
    gasConsume: '8',          // L/100km
    gasPrice: '7.8',          // 元/L
    evConsume: '15',          // kWh/100km
    evPrice: '1.5',           // 元/kWh（公共快充）
    tollMode: 'estimate',     // estimate / manual
    toll: '',
    roundTrip: false,
    costResult: null,

    /* 续航估算（电车） */
    ratedRange: '500',        // 标称续航 km
    planDistance: '',         // 计划单程里程 km（算充几次）
    scHighway: true,
    scLowtemp: false,
    scAc: false,
    scLoad: false,
    rangeResult: null,

    /* 限行 */
    limitDate: '2026-10-15',
    limitResult: null,

    /* 行程时长 */
    durDistance: '',
    durSpeed: '100',          // 平均车速
    departTime: '08:00',
    durResult: null,

    /* 检查清单 */
    checkGroups: CHECK_GROUPS,
    checked: {},
    checkDone: 0,
    checkTotal: checkTotalCount(),
    holidays: [],             // 富化后的免费时段（onLoad 填充）
    freeHoliday: '',          // 当前选中的免费时段（以开始日 s 为唯一键）
    freeHolidayName: '',      // 当前选中免费时段的节日名（拥堵提示文案用）
    nextHoliday: null,        // 下一个免费时段（进行中或未来第一个）
    oilPresetIdx: -1,         // 油价档位选中索引（-1=未选，手动输入）

    /* 驾驶计时 */
    timerText: '00:00:00',
    timerRunning: false,
    timerStatus: '未开始计时',
    timerWarn: false,

    /* 免费卡点 */
    freeStart: '',            // 免费开始日
    freeEnd: '',              // 免费结束日
    exitDate: '',             // 计划下高速日期
    exitTime: '12:00',        // 计划下高速时间
    freeResult: null,
  },

  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    const tab = ['cost', 'range', 'limit', 'duration', 'checklist', 'timer', 'free'].indexOf(options.tab) > -1 ? options.tab : 'cost';
    this.setData({ tab });

    // 富化免费时段：补年份/是否过期/是否预估，并算下一个免费时段
    const enriched = enrichHolidays();
    this.setData({ holidays: enriched.list, nextHoliday: enriched.next });

    // 首次进入提示顶部 tab 可横滑（只提示一次）
    if (!wx.getStorageSync('drive_seg_hinted')) {
      wx.showToast({ title: '← 左右滑动查看全部功能 →', icon: 'none' });
      wx.setStorageSync('drive_seg_hinted', true);
    }

    // 恢复检查清单
    const saved = wx.getStorageSync('drive_checklist') || {};
    let done = 0;
    for (const k in saved) if (saved[k]) done++;
    this.setData({ checked: saved, checkDone: done });

    // 载入好友分享的清单（分享卡片带 ck 参数）
    if (options.ck) {
      try {
        const arr = decodeURIComponent(options.ck).split(',').filter(Boolean);
        const checked = {};
        arr.forEach((k) => { checked[k] = true; });
        wx.setStorageSync('drive_checklist', checked);
        let d = 0; for (const k in checked) if (checked[k]) d++;
        this.setData({ checked, checkDone: d, tab: 'checklist' });
        wx.showToast({ title: '已载入好友分享的清单', icon: 'none' });
      } catch (err) { /* 参数异常则忽略 */ }
    }

    // 恢复计时器
    this._interval = null;
    this._baseSec = 0;
    this._startTs = Date.now();
    const t = wx.getStorageSync('drive_timer');
    if (t && typeof t === 'object') {
      this._baseSec = t.baseSec || 0;
      this._startTs = t.startTs || Date.now();
      this.setData({ timerRunning: !!t.running });
    }
    this._renderTimer();
  },

  onShow() {
    if (this.data.timerRunning && !this._interval) {
      this._interval = setInterval(() => this.tick(), 1000);
    }
  },

  onHide() {
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
  },

  onUnload() {
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
  },

  switchTab(e) {
    tap('drive_tab', { tab: e.currentTarget.dataset.tab });
    haptic.light();
    this.setData({ tab: e.currentTarget.dataset.tab });
  },

  /* ---------- 成本 ---------- */
  setCostType(e) { this.setData({ costType: e.currentTarget.dataset.t }, () => this.computeCost()); },
  setTollMode(e) { this.setData({ tollMode: e.currentTarget.dataset.m }, () => this.computeCost()); },
  setRoundTrip(e) { this.setData({ roundTrip: !this.data.roundTrip }, () => this.computeCost()); },
  setOilPreset(e) {
    const i = Number(e.currentTarget.dataset.i);
    const p = OIL_PRESETS[i];
    if (!p) return;
    // 再次点击已选档位则取消选中，交还手动输入
    const idx = this.data.oilPresetIdx === i ? -1 : i;
    this.setData({ oilPresetIdx: idx, gasPrice: idx > -1 ? String(p.value) : this.data.gasPrice }, () => this.computeCost());
    tap('drive_oil_preset', { value: p.value });
  },
  onDistance(e) { this.setData({ distance: e.detail.value }, () => this.computeCost()); },
  onGasConsume(e) { this.setData({ gasConsume: e.detail.value }, () => this.computeCost()); },
  onGasPrice(e) { this.setData({ gasPrice: e.detail.value, oilPresetIdx: -1 }, () => this.computeCost()); },
  onEvConsume(e) { this.setData({ evConsume: e.detail.value }, () => this.computeCost()); },
  onEvPrice(e) { this.setData({ evPrice: e.detail.value }, () => this.computeCost()); },
  onToll(e) { this.setData({ toll: e.detail.value }, () => this.computeCost()); },

  computeCost() {
    const d = parseFloat(this.data.distance);
    if (!(d > 0)) { this.setData({ costResult: null }); return; }
    const mult = this.data.roundTrip ? 2 : 1;
    let energy = 0;
    let energyLabel = '';
    if (this.data.costType === 'gas') {
      const c = parseFloat(this.data.gasConsume) || 0;
      const p = parseFloat(this.data.gasPrice) || 0;
      energy = (d * c / 100) * p * mult;
      energyLabel = '油费';
    } else {
      const c = parseFloat(this.data.evConsume) || 0;
      const p = parseFloat(this.data.evPrice) || 0;
      energy = (d * c / 100) * p * mult;
      energyLabel = '电费';
    }
    let toll = 0;
    if (this.data.tollMode === 'estimate') {
      toll = d * 0.5 * mult; // 估算：约 0.5 元/km，区间 0.4~0.6
    } else {
      toll = (parseFloat(this.data.toll) || 0) * (this.data.roundTrip ? 2 : 1);
    }
    const total = energy + toll;
    this.setData({
      costResult: {
        energyLabel,
        energy: r2(energy),
        toll: r2(toll),
        total: r2(total),
        tripLabel: this.data.roundTrip ? '往返' : '单程',
        tollNote: this.data.tollMode === 'estimate' ? '过路费按约 0.5 元/km 估算，实际 0.4~0.6，以收费站为准' : '过路费为你手动填写',
      },
    });
  },

  /* ---------- 续航估算 ---------- */
  onRatedRange(e) { this.setData({ ratedRange: e.detail.value }, () => this.computeRange()); },
  onPlanDistance(e) { this.setData({ planDistance: e.detail.value }, () => this.computeRange()); },
  toggleSc(e) {
    const k = e.currentTarget.dataset.k;
    this.setData({ [k]: !this.data[k] }, () => this.computeRange());
  },

  computeRange() {
    const rated = parseFloat(this.data.ratedRange);
    if (!(rated > 0)) { this.setData({ rangeResult: null }); return; }
    let factor = 1;
    const tags = [];
    if (this.data.scHighway) { factor -= 0.15; tags.push('高速−15%'); }
    if (this.data.scLowtemp) { factor -= 0.25; tags.push('低温−25%'); }
    if (this.data.scAc) { factor -= 0.10; tags.push('空调−10%'); }
    if (this.data.scLoad) { factor -= 0.05; tags.push('满载−5%'); }
    factor = Math.max(0.35, factor); // 封底，避免叠加后失真
    const actual = Math.round(rated * factor);
    const plan = parseFloat(this.data.planDistance);
    // 用到 20% 才补能，单程可跑 = actual*0.8（提到 if 外，告警态与提示文案共用）
    const perFull = actual * 0.8;
    let charges = 0;
    let chargeTip = '未填计划里程，无法估算中途充电次数';
    let chargeDensityTip = '';
    if (plan > 0) {
      charges = Math.max(0, Math.ceil(plan / perFull) - 1);
      chargeTip = plan <= perFull
        ? '单程一满电够用，中途可不充电'
        : '单程约需中途充电 ' + charges + ' 次（按用到 20% 补能估算）';
      chargeDensityTip = plan > perFull
        ? '⚠️ 出发前用地图导航查好沿途充电桩：节假日热门服务区快充排队 1 小时以上很常见，可规划「下高速到城区快充站」补能，顺带吃饭休息'
        : '提示：节假日热门服务区充电桩仍可能排队，建议提前标记备选站点，随车带一把随车充更稳妥';
    }
    this.setData({
      rangeResult: {
        actual,
        tags: tags.length ? tags.join('、') : '无额外折扣',
        chargeTip,
        chargeDensityTip,
        // wxml 不支持 indexOf，告警态在 JS 层预计算（需中途充电=告警）
        chargeWarn: plan > 0 && plan > perFull,
        factor: Math.round(factor * 100),
      },
    });
  },

  /* ---------- 限行 ---------- */
  onCity(e) { this.setData({ cityIdx: Number(e.detail.value) }, () => this.computeLimit()); },
  onLimitDate(e) { this.setData({ limitDate: e.detail.value }, () => this.computeLimit()); },

  computeLimit() {
    const c = CITIES[this.data.cityIdx];
    const dt = new Date(this.data.limitDate.replace(/-/g, '/'));
    // 日期为空/非法时不渲染结果（date picker 正常不会给空值，防御初始化竞态与脏数据），
    // 否则 getDay() 为 NaN，周几显示 undefined、尾号匹配全落空
    if (isNaN(dt.getTime())) {
      this.setData({ limitResult: null });
      return;
    }
    const wd = dt.getDay(); // 0 日 1一 ... 6六
    const wdNames = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    const isWorkday = wd >= 1 && wd <= 5;
    const res = {
      city: c.city,
      type: c.type,
      weekday: wdNames[wd],
      isWorkday,
      foreign: c.foreign,
      note: c.note,
      scope: c.scope || '',
    };
    // 法定节假日：尾号/桥隧限行暂停（北京等地规定法定节假日不限行），避免节假日误显限行。
    // 清明/劳动/国庆等假期同样适用——此前只认春节，节假日选成工作日会误报限行
    const hol = HOLIDAYS.find((h) => this.data.limitDate >= h.s && this.data.limitDate <= h.e);
    if (hol) {
      res.holiday = true;
      res.holidayName = hol.name;
      // 预估假期（2027）连休窗口可能微调，提示以官方通知为准
      const estTip = hol.est ? '（假期安排为预估，以官方通知为准）' : '';
      if (c.type === 'tail_rotate' || c.type === 'tail_fixed') {
        res.tail = hol.name + '法定假期，尾号限行暂停' + estTip;
        res.limited = false;
      } else if (c.type === 'bridge_single') {
        res.tail = hol.name + '法定假期，桥隧单双号暂停' + estTip;
        res.limited = false;
      } else if (c.type === 'cycle') {
        res.zone = c.zone;
        res.tip = hol.name + '法定假期仍执行「开四停四」，管控区规则不变。';
      } else if (c.type === 'area') {
        res.zone = c.zone;
        res.tip = hol.name + '法定假期区域限行以当地交警通告为准。';
      }
      res.expireTip = checkLimitExpire(c.city);
      this.setData({ limitResult: res });
      return;
    }

    if (c.type === 'tail_rotate') {
      const seg = c.rounds.find((r) => this.data.limitDate >= r.s && this.data.limitDate <= r.e);
      res.tail = !isWorkday ? '周末不限行' : (seg ? '限行尾号 ' + seg.g[wd - 1].join('/') : '该日轮换表待更新（以官方为准）');
      res.limited = isWorkday && !!seg;
    } else if (c.type === 'tail_fixed') {
      res.tail = !isWorkday ? '周末不限行' : '限行尾号 ' + c.map[wd - 1].join('/');
      res.limited = isWorkday;
    } else if (c.type === 'bridge_single') {
      if (!isWorkday) {
        res.tail = '休息日/法定节假日 不限桥隧单双号';
      } else {
        const dnum = dt.getDate();
        res.tail = (dnum % 2 === 1 ? '今日单日：单号车牌可走，双号限行' : '今日双日：双号车牌可走，单号限行') + '（7:00-22:00，仅长江大桥/江汉桥）';
      }
      res.limited = isWorkday;
    } else if (c.type === 'none') {
      res.tail = '该城不限尾号（已取消 / 无限号）';
      res.limited = false;
    } else if (c.type === 'foreign_only') {
      res.tail = '不限尾号，仅限外地车高峰';
      res.limited = false;
    } else if (c.type === 'cycle') {
      res.zone = c.zone;
      res.tip = '规则：非广州牌连续驶入管控区最多 4 天，第 5 天起须停驶，间隔满 4 天才能再驶入。请自行累计已连续行驶天数。';
    } else if (c.type === 'area') {
      res.zone = c.zone;
      res.tip = '区域内按当地规定限行，非本地牌尤其注意；遇临时管制以交警现场与官方通告为准。';
    }
    res.expireTip = checkLimitExpire(c.city);
    this.setData({ limitResult: res });
  },

  /* ---------- 行程时长 ---------- */
  onDurDistance(e) { this.setData({ durDistance: e.detail.value }, () => this.computeDuration()); },
  onDurSpeed(e) { this.setData({ durSpeed: e.detail.value }, () => this.computeDuration()); },
  onDepartTime(e) { this.setData({ departTime: e.detail.value }, () => this.computeDuration()); },

  computeDuration() {
    const d = parseFloat(this.data.durDistance);
    const sp = parseFloat(this.data.durSpeed);
    if (!(d > 0) || !(sp > 0)) { this.setData({ durResult: null }); return; }
    const driveMin = (d / sp) * 60;
    const rests = Math.floor(driveMin / 120); // 每 2 小时歇 20 分
    const restMin = rests * 20;
    const totalMin = driveMin + restMin;
    // 到达时间
    const [hh, mm] = this.data.departTime.split(':').map(Number);
    let arr = hh * 60 + mm + totalMin;
    const days = Math.floor(arr / 1440);
    arr = arr % 1440;
    const arrH = String(Math.floor(arr / 60)).padStart(2, '0');
    const arrM = String(Math.round(arr % 60)).padStart(2, '0');
    const arriveStr = arrH + ':' + arrM + (days > 0 ? '（+' + days + '天）' : '');
    const h = Math.floor(totalMin / 60);
    const m = Math.round(totalMin % 60);
    this.setData({
      durResult: {
        driveMin: Math.round(driveMin),
        rests,
        restMin,
        totalStr: h + ' 小时 ' + m + ' 分',
        arrive: arriveStr,
        tip: rests > 0 ? '建议中途休息 ' + rests + ' 次，每次约 20 分钟，防疲劳' : '路程短，注意别连续驾驶超 4 小时',
      },
    });
  },

  /* ---------- 检查清单 ---------- */
  toggleCheck(e) {
    const key = e.currentTarget.dataset.key;
    const val = !this.data.checked[key];
    const checked = Object.assign({}, this.data.checked);
    if (val) checked[key] = true; else delete checked[key];
    let done = 0;
    for (const k in checked) if (checked[k]) done++;
    wx.setStorageSync('drive_checklist', checked);
    this.setData({ checked, checkDone: done });
    tap('drive_check', { key });
  },

  resetCheck() {
    wx.removeStorageSync('drive_checklist');
    this.setData({ checked: {}, checkDone: 0 });
  },

  /* ---------- 驾驶计时 ---------- */
  _renderTimer() {
    const now = Date.now();
    const t = this._baseSec + (this.data.timerRunning ? (now - this._startTs) / 1000 : 0);
    const sec = Math.max(0, Math.floor(t));
    const hh = String(Math.floor(sec / 3600)).padStart(2, '0');
    const mm = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
    const ss = String(sec % 60).padStart(2, '0');
    const h = sec / 3600;
    let status = '连续驾驶中…';
    let warn = false;
    if (h >= 4) { status = '⚠️ 已连续驾驶超 4 小时，必须休息！违法且危险'; warn = true; }
    else if (h >= 2) { status = '已连续驾驶 ' + h.toFixed(1) + ' 小时，该进服务区歇歇了'; warn = true; }
    else if (sec > 0) { status = '连续驾驶中，满 2 小时记得休息'; }
    this.setData({ timerText: hh + ':' + mm + ':' + ss, timerStatus: status, timerWarn: warn });
  },

  tick() { this._renderTimer(); },

  _saveTimer() {
    wx.setStorageSync('drive_timer', { baseSec: this._baseSec, running: this.data.timerRunning, startTs: this._startTs });
  },

  startTimer() {
    if (this.data.timerRunning) return;
    this._startTs = Date.now();
    this.setData({ timerRunning: true });
    this._saveTimer();
    if (!this._interval) this._interval = setInterval(() => this.tick(), 1000);
    this._renderTimer();
    tap('drive_timer', { action: 'start' });
  },

  pauseTimer() {
    if (!this.data.timerRunning) return;
    this._baseSec += (Date.now() - this._startTs) / 1000;
    this.setData({ timerRunning: false });
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
    this._saveTimer();
    this._renderTimer();
    tap('drive_timer', { action: 'pause' });
  },

  resetTimer() {
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
    this._baseSec = 0;
    this._startTs = Date.now();
    wx.removeStorageSync('drive_timer');
    this.setData({ timerRunning: false, timerText: '00:00:00', timerStatus: '未开始计时', timerWarn: false });
    tap('drive_timer', { action: 'reset' });
  },

  /** 服务区歇完：连续驾驶时长清零，重新出发时按「开始计时」 */
  restTimer() {
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
    this._baseSec = 0;
    this._startTs = Date.now();
    wx.removeStorageSync('drive_timer');
    this.setData({ timerRunning: false, timerText: '00:00:00', timerStatus: '已休息，重新出发请按「开始计时」', timerWarn: false });
    tap('drive_timer', { action: 'rest' });
  },

  /* ---------- 免费卡点 ---------- */
  onFreeStart(e) { this.setData({ freeStart: e.detail.value }, () => this.computeFree()); },
  onFreeEnd(e) { this.setData({ freeEnd: e.detail.value }, () => this.computeFree()); },
  onExitDate(e) { this.setData({ exitDate: e.detail.value }, () => this.computeFree()); },
  onExitTime(e) { this.setData({ exitTime: e.detail.value }, () => this.computeFree()); },

  setHoliday(e) {
    const key = e.currentTarget.dataset.key;
    const h = this.data.holidays.find((x) => x.s === key);
    if (!h) return;
    this.setData({ freeStart: h.s, freeEnd: h.e, freeHoliday: h.s, freeHolidayName: h.name }, () => this.computeFree());
    tap('drive_holiday', { name: h.name, year: h.year });
  },

  computeFree() {
    const fs = this.data.freeStart, fe = this.data.freeEnd, ed = this.data.exitDate, et = this.data.exitTime;
    if (!fs || !fe || !ed || !et) { this.setData({ freeResult: null }); return; }
    const freeStartTs = new Date(fs.replace(/-/g, '/') + ' 00:00').getTime();
    const endDay00 = new Date(fe.replace(/-/g, '/') + ' 00:00').getTime();
    const freeEndTs = endDay00 + 86400000; // 结束日 24:00
    const exitTs = new Date((ed.replace(/-/g, '/') + ' ' + et)).getTime();
    if (isNaN(freeStartTs) || isNaN(freeEndTs) || isNaN(exitTs)) { this.setData({ freeResult: null }); return; }

    let state, head, msg;
    if (exitTs >= freeStartTs && exitTs <= freeEndTs) {
      state = 'free';
      head = '✅ 全程免费';
      msg = '规则：以「驶离高速出口的时间」为准——只要在免费时段内下高速即免费，与你何时上的高速无关。';
    } else if (exitTs < freeStartTs) {
      state = 'before';
      head = '❌ 下高速时还没免费';
      msg = '建议：① 等到免费开始后再下高速；② 若临近免费开始，可先下高速再重新驶入（仅适合短途接驳，长途不划算）。';
    } else {
      state = 'after';
      head = '❌ 下高速时免费已结束';
      msg = '建议：在免费结束前先下高速再重新驶入，能省一段过路费。';
    }

    let tip = '';
    const near = 3600 * 1000;
    if (Math.abs(exitTs - freeStartTs) <= near) {
      tip = '临近免费开始，可卡点：免费开始后再下高速即全程免费。';
    } else if (Math.abs(exitTs - freeEndTs) <= near) {
      tip = '临近免费结束，可卡点：结束前先下高速再上，省一段。';
    }

    this.setData({
      freeResult: { state, head, msg, tip },
    });
  },

  onShareAppMessage() {
    if (this.data.tab === 'checklist') {
      const keys = Object.keys(this.data.checked).filter((k) => this.data.checked[k]);
      if (keys.length) {
        return share.appMessage({
          title: '自驾出行检查清单（已备 ' + keys.length + '/' + this.data.checkTotal + '）',
          path: '/pages/drive/drive?tab=checklist&ck=' + encodeURIComponent(keys.join(',')),
        });
      }
    }
    return share.appMessage({ title: '途悦出行防坑：自驾成本、限行、续航一键算', path: '/pages/drive/drive' });
  },
  onShareTimeline() {
    return share.timeline({ title: '自驾成本/限行/续航一键算' });
  },
});
