const { loadSections } = require('../../utils/cloudGuide');
const store = require('../../utils/store');
const util = require('../../utils/util');
const { GROUPS, getVisibleGroups, CONFIG } = require('../../data/channels');
const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');
const { TOOLS } = require('../../data/tools');
const { findCity } = require('../../data/regions');

/**
 * 购票渠道智能推荐：随「出行类型」变化，在同一堵墙里分两行展示
 *   official = 官方直销（航司 / 12306）
 *   ota      = 第三方比价预订平台
 * 目的：既不让大家误以为只有几个渠道，又能一眼分清官方与第三方。
 */
const CHANNEL_MAP = {
  flight: {
    official: ['air-china', 'china-eastern', 'china-southern', 'hainan'],
    ota: ['ctrip', 'fliggy', 'qunar', 'tongcheng'],
    tip: '按「飞机」为你精选 8 家 · 更多官方与平台渠道，点开直达',
  },
  train: {
    official: ['rail-12306'],
    ota: ['ctrip', 'fliggy', 'qunar', 'tongcheng'],
    tip: '按「高铁火车」为你精选 5 家 · 更多官方与平台渠道，点开直达',
  },
  combo: {
    official: ['rail-12306', 'air-china', 'china-eastern', 'china-southern'],
    ota: ['ctrip', 'fliggy', 'qunar', 'tongcheng'],
    tip: '按「组合出行」为你精选 8 家 · 更多官方与平台渠道，点开直达',
  },
};

function findChannel(id) {
  for (let i = 0; i < GROUPS.length; i++) {
    const hit = GROUPS[i].channels.find((c) => c.id === id);
    if (hit) return hit;
  }
  return null;
}

function pickChannels(ids) {
  return ids.map(findChannel).filter(Boolean);
}

/** 全部渠道总数（按后台可见配置统计，用于「查看全部 N 家」文案） */
function countChannels() {
  return getVisibleGroups().reduce((sum, g) => sum + g.channels.length, 0);
}

const share = require('../../utils/share');
const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    from: '',
    to: '',
    date: '',
    dateCN: '',
    via: '',
    type: 'flight',
    show12306: true,
    showAirline: true,
    channelTip: '',
    officialChannels: [],
    otaChannels: [],
    totalChannels: 0,
    totalTools: TOOLS.length,
    recentRoutes: [],
    today: '',
    showGuide: false,
    shareImg: '',
    destCity: null,   // 场景化：目的地在交通指南里时才出现
    fontScale: 'normal',  // 适老化字号档位（normal/large/xlarge），首页常驻入口用
  },

  /** options：好友通过分享卡片进入时会带 from / to / date / type / via，自动填入 */
  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    const t = util.today();
    const vis = getVisibleGroups();
    const first = vis[0];
    const defType = first.key === 'train' ? 'train' : first.key === 'airline' ? 'flight' : 'combo';

    const shared = this.parseSharedTrip(options);
    const type = shared.type || defType;

    this.setData({
      date: shared.date || t,
      dateCN: shared.dateCN || util.cnDate(shared.date || t),
      type,
      from: shared.from || '',
      to: shared.to || '',
      destCity: findCity(shared.to || ''),
      via: shared.via || '',
      show12306: !!CONFIG.show12306,
      showAirline: !!CONFIG.showAirline,
      totalChannels: countChannels(),
      today: t,
      recentRoutes: store.getRecentRoutes(3),
      showGuide: !this.isGuided(),
      ...this.buildChannelData(type),
    });

    if (shared.from && shared.to) {
      tap('open_shared_trip', { from: shared.from, to: shared.to });
      wx.showToast({
        title: '已载入好友分享的行程',
        icon: 'none',
        duration: 2200,
      });
    }
  },

  /** 解析分享卡片带来的行程参数（中文需解码） */
  parseSharedTrip(options) {
    const o = options || {};
    if (!o.from && !o.to) return {};
    const dec = (v) => {
      try {
        return v ? decodeURIComponent(v) : '';
      } catch (e) {
        return v || '';
      }
    };
    const date = dec(o.date);
    return {
      from: dec(o.from),
      to: dec(o.to),
      date,
      dateCN: dec(o.dateCN) || (date ? util.cnDate(date) : ''),
      type: dec(o.type) || 'flight',
      via: dec(o.via),
    };
  },


  goChecklist() {
    tap('go_checklist');
    haptic.light();
    wx.navigateTo({ url: '/pages/checklist/checklist' });
  },

  goDelay() {
    tap('go_delay');
    haptic.light();
    wx.navigateTo({ url: '/pages/delay/delay' });
  },

  goRights() {
    tap('go_rights');
    haptic.light();
    wx.navigateTo({ url: '/pages/rights/rights' });
  },

  goCalc() {
    tap('go_calc');
    haptic.light();
    wx.navigateTo({ url: '/pages/calc/calc' });
  },

  goTransit() {
    tap('go_transit');
    haptic.light();
    wx.navigateTo({ url: '/pages/transit/transit' });
  },

  /** 跳到「出行工具」页：那里是全量目录 */
  goTools() {
    tap('go_tools');
    haptic.light();
    wx.switchTab({ url: '/pages/tools/tools' });
  },

  /** 场景化推荐：跳到「城市交通」并定位到目的地城市 */
  /** 场景化：目的地在我们的交通指南里，才显示「机场怎么进城」推荐卡 */
  updateDestCity(to) {
    this.setData({ destCity: findCity(to) });
  },

  goDestCity() {
    const c = this.data.destCity;
    if (!c) return;
    tap('go_dest_city', { city: c.name });
    haptic.light();
    wx.navigateTo({ url: '/pages/cityguide/cityguide?city=' + encodeURIComponent(c.name) });
  },

  /** 从「我的行程」保存后返回、或切换 Tab 回来时，刷新常用路线 */
  onShow() {
    this.setData({ recentRoutes: store.getRecentRoutes(3) });
    this.setData({ fontScale: wx.getStorageSync(a11y.KEY) || 'normal' });
  },

  /** 首页常驻「字号」入口：标准→放大→特大 循环切换，全站生效 */
  cycleFontScale() {
    const order = ['normal', 'large', 'xlarge'];
    const cur = wx.getStorageSync(a11y.KEY) || 'normal';
    const next = order[(order.indexOf(cur) + 1) % order.length];
    try { wx.setStorageSync(a11y.KEY, next); } catch (err) { /* 存储失败仍切当前会话 */ }
    this.setData({ fontScale: next, fontScaleClass: a11y.readScale() });
    const tip = next === 'normal' ? '已恢复标准字号' : (next === 'large' ? '已放大字号' : '已特大字号');
    wx.showToast({ title: tip + '，全站生效', icon: 'none', duration: 2000 });
    tap('index_font_scale_cycle', { scale: next });
  },

  onReady() {
    // 预生成分享封面图（canvas 绘制 → 临时文件），供分享时使用
    this.drawShareImage();
  },

  isGuided() {
    try {
      return !!wx.getStorageSync('tt_guided');
    } catch (e) {
      return false;
    }
  },

  closeGuide() {
    try {
      wx.setStorageSync('tt_guided', 1);
    } catch (e) { /* ignore */ }
    tap('close_guide');
    this.setData({ showGuide: false });
  },

  noop() {},

  /** 用离屏 canvas 绘制分享封面图（无需服务器 / 域名） */
  drawShareImage() {
    if (typeof wx.createSelectorQuery !== 'function') return;
    wx.createSelectorQuery()
      .select('#shareCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        const item = res && res[0];
        const canvas = item && item.node;
        if (!canvas || !canvas.getContext) return;
        const ctx = canvas.getContext('2d');
        const W = 500;
        const H = 400;
        const dpr = (wx.getWindowInfo && wx.getWindowInfo().pixelRatio) || (wx.getSystemInfoSync && wx.getSystemInfoSync().pixelRatio) || 2;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        ctx.scale(dpr, dpr);

        // 背景渐变
        const g = ctx.createLinearGradient(0, 0, W, H);
        g.addColorStop(0, '#4094ff');
        g.addColorStop(1, '#2557d6');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);

        // 装饰圆
        ctx.globalAlpha = 0.12;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(W - 60, 70, 110, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(40, H - 40, 90, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 40px sans-serif';
        ctx.fillText('途悦出行防坑', 40, 130);
        ctx.font = '22px sans-serif';
        ctx.globalAlpha = 0.92;
        // 航司数量从 channels 数据动态取，避免文案与实际渠道数不一致（旧值写死"21 家"，实际 16 家）
        ctx.fillText(GROUPS.find((g) => g.key === 'airline').channels.length + ' 家航司 · 铁路12306 · 主流平台', 40, 178);
        ctx.fillText('官方渠道一键直达', 40, 214);
        ctx.globalAlpha = 0.8;
        ctx.font = '19px sans-serif';
        ctx.fillText('不卖票 · 不代购 · 不套路', 40, 250);
        ctx.globalAlpha = 0.75;
        ctx.font = '17px sans-serif';
        ctx.fillText('出行省钱，从走对渠道开始', 40, 330);

        wx.canvasToTempFilePath({
          canvas,
          x: 0,
          y: 0,
          width: W,
          height: H,
          destWidth: W * 2,
          destHeight: H * 2,
          success: (r) => {
            if (r && r.tempFilePath) {
              this.setData({ shareImg: r.tempFilePath });
            }
          },
          fail: () => { /* 生成失败则回退为默认分享图 */ },
        });
      });
  },

  /** 点击常用路线：一键填入出发地 / 目的地 */
  onPickRoute(e) {
    const { from, to } = e.currentTarget.dataset;
    if (!from || !to) return;
    tap('pick_recent_route', { from, to });
    this.setData({ from, to, destCity: findCity(to) });
    wx.showToast({ title: '已填入 ' + from + ' → ' + to, icon: 'none', duration: 1500 });
  },

  /** 按出行类型生成：官方直销行 + 比价平台行 + 提示语 */
  buildChannelData(type) {
    const conf = CHANNEL_MAP[type] || CHANNEL_MAP.flight;
    return {
      officialChannels: pickChannels(conf.official),
      otaChannels: pickChannels(conf.ota),
      channelTip: conf.tip,
    };
  },

  chooseCity(e) {
    const field = e.currentTarget.dataset.field;
    tap('choose_city', { field });
    wx.navigateTo({
      url: `/pages/city/city?field=${field}`,
      events: {
        choose: (data) => {
          this.setData({ [field]: data.city, destCity: field === 'to' ? findCity(data.city) : this.data.destCity });
        },
      },
    });
  },

  onDate(e) {
    const v = e.detail.value;
    tap('pick_date');
    this.setData({ date: v, dateCN: util.cnDate(v) });
  },

  swapCity() {
    tap('swap_city');
    this.setData({ from: this.data.to, to: this.data.from, destCity: findCity(this.data.from) });
  },

  setFlight() {
    tap('set_type', { type: 'flight' });
    haptic.light();
    this.setData({ type: 'flight', ...this.buildChannelData('flight') });
  },

  setTrain() {
    tap('set_type', { type: 'train' });
    haptic.light();
    this.setData({ type: 'train', ...this.buildChannelData('train') });
  },

  setCombo() {
    tap('set_type', { type: 'combo' });
    haptic.light();
    this.setData({ type: 'combo', ...this.buildChannelData('combo') });
  },

  validate() {
    const from = this.data.from.trim();
    const to = this.data.to.trim();
    if (!from || !to) {
      wx.showToast({ title: '老哥提醒：先填出发地和目的地', icon: 'none' });
      return false;
    }
    if (from === to) {
      wx.showToast({ title: '出发地和目的地不能相同', icon: 'none' });
      return false;
    }
    return true;
  },

  saveTrip() {
    if (!this.validate()) return;
    const { from, to, date, dateCN, type, via } = this.data;
    const typeLabel = type === 'train' ? '高铁火车' : type === 'combo' ? '飞机+高铁' : '飞机';
    tap('save_trip', { type, hasVia: !!via.trim() });
    store.saveTrip({ from: from.trim(), to: to.trim(), date, dateCN, type, via: via.trim(), typeLabel });
    store.saveCurrent({ from: from.trim(), to: to.trim(), date, dateCN, type, typeLabel, via: via.trim() });
    // 保存后立即刷新「常用路线」
    this.setData({ recentRoutes: store.getRecentRoutes(3) });
    haptic.light();
    wx.showToast({ title: '已保存！去「我的行程-待出行」查看', icon: 'success', duration: 3000 });
  },


  /** 渠道墙点击：直接跳转，不再弹窗（弹窗最多 6 项会让人误以为只有 6 家） */
  onTapChannel(e) {
    const id = e.currentTarget.dataset.id;
    const list = this.data.officialChannels.concat(this.data.otaChannels);
    const item = list.find((c) => c.id === id);
    if (!item) return;
    haptic.light();
    tap('tap_channel_index', { id, hasAppid: !!item.appid });
    if (item.appid) {
      wx.navigateToMiniProgram({
        appId: item.appid,
        envVersion: 'release',
        fail: () => this.copyGuide(item),
      });
    } else {
      this.copyGuide(item);
    }
  },

  copyGuide(item) {
    wx.setClipboardData({
      data: item.search || item.name,
      success: () => wx.showToast({ title: '名称已复制，去微信搜它的官方小程序', icon: 'none', duration: 2500 }),
    });
  },

  goCityGuide() {
    tap('go_cityguide');
    haptic.light();
    wx.navigateTo({ url: '/pages/cityguide/cityguide' });
  },

  goAsk() {
    tap('go_ask');
    haptic.light();
    wx.navigateTo({ url: '/pages/ask/ask' });
  },

  goChannels() {
    tap('go_channels');
    haptic.light();
    // 进入渠道页前，把当前表单里填的路线同步过去（避免渠道页还显示上次的路线）
    const { from, to, date, dateCN, type, via } = this.data;
    if (from.trim() && to.trim()) {
      const typeLabel = type === 'train' ? '高铁火车' : type === 'combo' ? '飞机+高铁' : '飞机';
      store.saveCurrent({
        from: from.trim(),
        to: to.trim(),
        date,
        dateCN,
        type,
        typeLabel,
        via: via.trim(),
      });
    }
    wx.navigateTo({ url: '/pages/channels/channels' });
  },

  goAbout() {
    tap('go_about');
    haptic.light();
    wx.navigateTo({ url: '/pages/about/about' });
  },

  onTabItemTap(e) {
    track('tab_switch', { page: e.pagePath });
    haptic.light();
  },

  /** 分享小程序卡片：若已填好行程，好友点开会自动带上这条路线 */
  onShareAppMessage() {
    const { from, to, date, dateCN, type, via } = this.data;
    track('share_index', { hasTrip: !!(from && to) });
    const img = this.data.shareImg;
    if (from && to) {
      const q = [
        'from=' + encodeURIComponent(from),
        'to=' + encodeURIComponent(to),
        'date=' + encodeURIComponent(date || ''),
        'dateCN=' + encodeURIComponent(dateCN || ''),
        'type=' + encodeURIComponent(type || 'flight'),
        'via=' + encodeURIComponent(via || ''),
      ].join('&');
      return share.appMessage({
        title: '【出行计划】' + from + (via ? ' → ' + via : '') + ' → ' + to + (dateCN ? ' · ' + dateCN : ''),
        path: '/pages/index/index?' + q,
        imageUrl: img,
      });
    }
    return share.appMessage({
      title: '途悦出行防坑：官方购票渠道直达，避开购票坑',
      path: '/pages/index/index',
      imageUrl: img,
    });
  },
  onShareTimeline() {
    return share.timeline({ title: '出行避坑一站式，老哥帮你先算再走' });
  },
});
