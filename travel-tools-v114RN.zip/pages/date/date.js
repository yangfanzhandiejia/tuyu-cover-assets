const util = require('../../utils/util');

// 春运窗口（40 天：春节前 15 天 ~ 春节后 25 天）。2027 春节为 2/6，故约 1/22~3/3；日期为预估，以官方为准
const CHUNYUN = [
  { s: '2027-01-22', e: '2027-03-03', est: true },
];

const a11y = require('../../utils/a11y');
Page({
  behaviors: [a11y.a11yBehavior],
  data: {
    date: '',
    dateCN: '',
    rows: null,
    chunyunTip: '',
  },

  onLoad() {
    const t = util.today();
    this.setData({ date: t, dateCN: util.cnDate(t) });
    this.compute(t);
  },

  onDate(e) {
    const v = e.detail.value;
    this.setData({ date: v, dateCN: util.cnDate(v) });
    this.compute(v);
  },

  compute(v) {
    const diff = util.diffDays(v);
    const target = new Date(v + 'T00:00:00');

    const minus = (d, n) => {
      const x = new Date(d);
      x.setDate(x.getDate() - n);
      return util.fmt(x);
    };

    const saleDate = minus(target, 14); // 预售期 15 天（含出发当天），开售日 = 出发日 - 14 天
    const d7 = minus(target, 7);
    const d2 = minus(target, 2);

    // 春运提示：选中日期落在春运窗口内时显示
    const cy = CHUNYUN.find((h) => v >= h.s && v <= h.e);
    const chunyunTip = cy
      ? '🚄 春运期间(约 1/22–3/3)：各火车站起售时间不同，12306「我的→起售时间」可查；抢不到用候补(最多 60 个组合)；学生/务工人员有预约专区可早于 15 天购票。以官方为准。'
      : '';

    const rows = [
      { k: '距今天数', v: diff > 0 ? `还有 ${diff} 天` : diff === 0 ? '就是今天' : `已过 ${-diff} 天` },
      {
        k: '火车票开售',
        v: diff >= 0
          ? `预售期 15 天，约 ${util.cnDate(saleDate)} 开售；售罄可用 12306 候补`
          : '—',
      },
      {
        k: '机票购票建议',
        v: diff >= 90
          ? '距出发还早，国内线多未放出低价舱，可先关注；提前 30–60 天前后是较友好的比价窗口'
          : diff >= 30
            ? '进入较友好的购票窗口（国内线常见低价期约提前 30–60 天），可多方比价后尽早锁定'
            : diff >= 7
              ? '已偏临近，价格普遍走高，建议尽快决定，并看清退改规则与行李额'
              : diff >= 0
                ? '临近出发价格高且波动大，尽快购票；买前务必看清退改规则与行李额'
                : '—',
      },
      {
        k: '退改费用节点',
        v: `${util.cnDate(d7)}（前 7 天）、${util.cnDate(d2)}（前 48 小时）前后费用分档变化，退改请赶早`,
      },
      {
        k: '值机提醒',
        v: '国内航班一般起飞前 1～2 天开放线上值机，多数机场起飞前 45～60 分钟截止托运',
      },
      {
        k: '高铁检票',
        v: '开车前一般提前 5～10 分钟停止检票，大站更早，请预留进站安检时间',
      },
    ];

    this.setData({ rows, chunyunTip });
  },
});
