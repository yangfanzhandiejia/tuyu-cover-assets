const { loadSections, findArticle } = require('../../utils/cloudGuide');

// 文章 → 主题插画映射（同一套立体风格，纯本地图片，不涉及任何外部资源）
const ART_MAP = {
  'flight-refund-rule': 'refund', 'flight-low-price-trap': 'promo', 'flight-baggage-checkin': 'baggage',
  'flight-fake-channel': 'scam', 'flight-transfer-trap': 'warn', 'flight-airline-diff': 'compare',
  'flight-buy-time': 'promo',
  'train-12306-houbu': 'train', 'train-speedup-pack': 'scam', 'train-student-ticket': 'promo',
  'train-gaikai': 'refund', 'train-child': 'child', 'train-overtime': 'delay',
  'highway-free-policy': 'road', 'highway-etc': 'road', 'highway-tips': 'road',
  'general-refund-rights': 'refund', 'general-special-refund': 'refund', 'general-refund-scam': 'scam',
  'general-info': 'shield', 'general-insurance': 'shield',
  'world-transit-visa': 'visa', 'world-delay-comp': 'delay', 'world-baggage': 'baggage',
  'world-oversale': 'warn', 'world-family': 'child', 'world-name-mismatch': 'warn',
  'timing-promo': 'promo', 'timing-best-window': 'promo', 'timing-season-price': 'compare',
  'timing-cheap-ticket-trap': 'promo',
  'pet-flight': 'pet', 'pet-scam': 'scam',
  'elder-flight': 'elder',
  'dest-sanya': 'dest', 'dest-yunnan': 'dest', 'dest-xuexiang': 'dest',
  'intl-visa-ticket': 'visa', 'intl-transit': 'visa',
  'points-where-to-check': 'points', 'points-how-to-use': 'points',
  'points-expire-keepalive': 'points', 'points-rail-12306': 'train',
  'airport-traffic': 'road', 'airport-checkin-time': 'checkin', 'airport-transit-night': 'checkin',
  'baggage-carry-check': 'baggage', 'baggage-forbidden': 'baggage',
};

/** 文章 → 插画：优先查表，其次按 id 后缀规则匹配（新增城市文章自动生效） */
const ART_PFX = {
  airport: 'road', baggage: 'baggage', chunyun: 'train', city: 'dest', dest: 'dest',
  drive: 'road', elder: 'elder', elderly: 'elder', flight: 'flight', general: 'shield',
  highway: 'road', intl: 'visa', pet: 'pet', points: 'points', timing: 'promo',
  train: 'train', world: 'dest',
};
function artFor(id, secId) {
  if (ART_MAP[id]) return ART_MAP[id];
  if (/-airport$/.test(id) || /-transit$/.test(id)) return 'road';
  if (/-scam$/.test(id)) return 'scam';
  const p = String(secId || '').split('-')[0];
  return ART_PFX[p] || 'shield'; // 终极兜底：盾牌（防坑）图，确保 art 文件必然存在
}
const store = require('../../utils/store');
const { track, tap } = require('../../utils/track');
const { secImgOf } = require('../../utils/secImg');

const share = require('../../utils/share');
Page({
  data: {
    article: null,
    isFav: false,
    sectionId: '',
    sectionImg: 'general',
    sectionTitle: '',
    sectionBg: '#eef7f8',
    art: '',
  },

  onLoad(options) {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
    const id = options.id || '';
    this.articleId = id;
    this.setData({ isFav: store.isGuideFav(id) });
    loadSections().then((sections) => {
      const article = findArticle(sections, id);
      if (!article) {
        wx.showToast({ title: '内容不存在', icon: 'none' });
        setTimeout(() => wx.navigateBack(), 1200);
        return;
      }
      tap('view_guide_detail', { id });
      // 记录「最近阅读」，返回指南页时能看到
      store.pushRecentGuide(id);
      // 找出该文章所属板块，用于顶部「板块头图」
      const sec = (sections || []).find((s) => (s.items || []).some((i) => i.id === id));
      this.setData({
        article,
        sectionId: sec ? sec.id : '',
        sectionImg: sec ? secImgOf(sec.id) : 'general',
        sectionTitle: sec ? sec.title : '',
        sectionBg: sec ? sec.bg : '#eef7f8',
        art: artFor(id, sec ? sec.id : ''),
      });
      wx.setNavigationBarTitle({ title: article.title || '避坑详情' });
    });
  },

  onToggleFav() {
    const id = this.articleId;
    if (!id) return;
    store.toggleGuideFav(id);
    const fav = store.isGuideFav(id);
    this.setData({ isFav: fav });
    tap('toggle_guide_fav', { id, fav });
    wx.showToast({
      title: fav ? '已收藏，可在指南页顶部找到' : '已取消收藏',
      icon: 'none',
      duration: 1800,
    });
  },

  onShareAppMessage() {
    const a = this.data.article;
    track('share_guide_detail', { id: a ? a.id : '' });
    return share.appMessage({
      title: a ? a.title : '出行避坑指南',
      path: a ? `/pages/guide-detail/guide-detail?id=${a.id}` : '/pages/guide/guide',
    });
  },
  onShareTimeline() {
    return share.timeline({ title: '这篇避坑指南太实用了，转发给家人' });
  },
});
