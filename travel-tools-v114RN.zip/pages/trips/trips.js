const store = require('../../utils/store');
const { getVisibleGroups } = require('../../data/channels');
const util = require('../../utils/util');
const { findArticles } = require('../../utils/cloudGuide');
const { track, tap } = require('../../utils/track');
const haptic = require('../../utils/haptic');

const TABS = [
  { key: 'upcoming', name: '待出行' },
  { key: 'archive', name: '出行档案' },
  { key: 'favs', name: '我的收藏' },
];

const share = require('../../utils/share');
Page({
  data: {
    tabs: TABS,
    tab: 'upcoming',
    trips: [],
    archive: [],
    favs: [],
    stat: null,       // 档案统计：出行次数 / 城市数 / 年份
    year: '',
    reportImg: '',    // 年度报告图（生成后用于展示与保存）
    showChannelPopup: false,
    popupTitle: '',
    popupGroups: [],
  },

  onShow() {
    this.refresh();
  },

  onPickTab(e) {
    this.setData({ tab: e.currentTarget.dataset.key, reportImg: '' });
  },

  refresh() {
    const today = util.today();
    const trips = store.getTrips().map((t) => {
      const date = t.date || '';
      let tip = '';
      let expired = false;
      if (date) {
        const diff = Math.round(
          (new Date(date + 'T00:00:00').getTime() - new Date(today + 'T00:00:00').getTime()) / 86400000
        );
        if (diff > 0) tip = '还有 ' + diff + ' 天出发';
        else if (diff === 0) tip = '今天出发';
        else { tip = '已过期'; expired = true; }
      }
      return {
        ...t,
        dateCN: t.dateCN || t.date,
        typeLabel: t.type === 'combo' ? '飞机+高铁' : t.type === 'train' ? '高铁火车' : '飞机',
        via: t.via || '',
        tip,
        expired,
      };
    });

    const archive = store.getArchive().map((t) => ({
      ...t,
      doneCN: t.doneAt ? util.fmt(new Date(t.doneAt)) : (t.dateCN || t.date || ''),
      typeLabel: t.type === 'combo' ? '飞机+高铁' : t.type === 'train' ? '高铁火车' : '飞机',
      via: t.via || '',
    }));

    const favs = findArticles(null, store.getGuideFavs()).map((a) => ({
      id: a.id,
      title: a.title,
      sectionTitle: a.sectionTitle || '',
    })).filter((x) => x.title);

    this.setData({ trips, archive, favs, stat: this.buildStat(archive), year: String(new Date().getFullYear()) });
  },

  /** 统计：总次数、去过的城市数、今年次数、第一次与最近一次 */
  buildStat(archive) {
    if (!archive.length) return null;
    const cities = {};
    let thisYear = 0;
    const y = new Date().getFullYear();
    archive.forEach((t) => {
      [t.from, t.to, t.via].forEach((c) => { if (c) cities[c] = 1; });
      const d = t.doneAt ? new Date(t.doneAt) : (t.date ? new Date(t.date + 'T00:00:00') : null);
      if (d && d.getFullYear() === y) thisYear += 1;
    });
    return {
      total: archive.length,
      cities: Object.keys(cities).length,
      thisYear,
      latest: archive[0] ? (archive[0].from + ' → ' + archive[0].to) : '',
    };
  },

  /** 标记已完成 → 进入出行档案 */
  markDone(e) {
    const id = e.currentTarget.dataset.id;
    tap('trip_done', { id });
    haptic.light();
    wx.showModal({
      title: '标记为已完成',
      content: '这条行程会移到「出行档案」，计入你的年度报告。',
      confirmText: '已完成',
      success: (r) => {
        if (!r.confirm) return;
        store.archiveTrip(id);
        this.refresh();
        wx.showToast({ title: '已记入出行档案', icon: 'none', duration: 2000 });
      },
    });
  },

  removeArchiveItem(e) {
    const id = e.currentTarget.dataset.id;
    haptic.light();
    wx.showModal({
      title: '从档案中删除',
      content: '确定删除这条记录吗？',
      confirmColor: '#e5484d',
      success: (r) => {
        if (r.confirm) {
          store.removeArchive(id);
          this.refresh();
        }
      },
    });
  },

  clearArchiveAll() {
    haptic.light();
    wx.showModal({
      title: '清空出行档案',
      content: '确定清空全部档案记录吗？此操作不可恢复。',
      confirmColor: '#e5484d',
      success: (r) => {
        if (r.confirm) {
          store.clearArchive();
          this.refresh();
        }
      },
    });
  },

  openFav(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pages/guide-detail/guide-detail?id=' + id });
  },

  /** 生成年度报告图 */
  makeReport() {
    const stat = this.data.stat;
    if (!stat) {
      wx.showToast({ title: '还没有出行记录', icon: 'none' });
      return;
    }
    tap('make_report', { total: stat.total });
    wx.createSelectorQuery()
      .in(this)
      .select('#reportCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        const item = res && res[0];
        const canvas = item && item.node;
        if (!canvas || !canvas.getContext) {
          wx.showToast({ title: '生成中，稍候再来试试', icon: 'none' });
          return;
        }
        const ctx = canvas.getContext('2d');
        const W = 500;
        const H = 640;
        const dpr = (wx.getWindowInfo && wx.getWindowInfo().pixelRatio) || (wx.getSystemInfoSync && wx.getSystemInfoSync().pixelRatio) || 2;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        ctx.scale(dpr, dpr);

        // 背景
        const g = ctx.createLinearGradient(0, 0, W, H);
        g.addColorStop(0, '#3d6fe0');
        g.addColorStop(1, '#21307a');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);

        ctx.globalAlpha = 0.10;
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(W - 50, 90, 130, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(50, H - 80, 110, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;

        ctx.fillStyle = '#fff';
        ctx.font = 'bold 30px sans-serif';
        ctx.fillText(this.data.year + ' 我的出行年报', 40, 90);
        ctx.globalAlpha = 0.75;
        ctx.font = '18px sans-serif';
        ctx.fillText('途悦出行防坑 · 记录每一次出发', 40, 128);
        ctx.globalAlpha = 1;

        // 三个大数字
        const nums = [
          { v: String(stat.total), l: '次出行' },
          { v: String(stat.cities), l: '座城市' },
          { v: String(stat.thisYear), l: '今年出行' },
        ];
        nums.forEach((n, i) => {
          const x = 40 + i * 150;
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 54px sans-serif';
          ctx.fillText(n.v, x, 250);
          ctx.globalAlpha = 0.78;
          ctx.font = '19px sans-serif';
          ctx.fillText(n.l, x, 285);
          ctx.globalAlpha = 1;
        });

        // 最近一趟
        ctx.globalAlpha = 0.72;
        ctx.font = '19px sans-serif';
        ctx.fillText('最近一趟：' + (stat.latest || '—'), 40, 360);
        ctx.globalAlpha = 1;

        // 分割线
        ctx.strokeStyle = 'rgba(255,255,255,0.25)';
        ctx.beginPath(); ctx.moveTo(40, 400); ctx.lineTo(W - 40, 400); ctx.stroke();

        // 时间线（最多 6 条）
        ctx.font = '19px sans-serif';
        const list = this.data.archive.slice(0, 6);
        list.forEach((t, i) => {
          const y = 440 + i * 32;
          const route = (t.from || '') + (t.via ? ' → ' + t.via : '') + ' → ' + (t.to || '');
          ctx.fillStyle = 'rgba(255,255,255,0.92)';
          ctx.fillText('· ' + route, 40, y);
          ctx.fillStyle = 'rgba(255,255,255,0.6)';
          ctx.fillText(t.doneCN || '', W - 150, y);
        });
        if (this.data.archive.length > 6) {
          ctx.fillStyle = 'rgba(255,255,255,0.55)';
          ctx.fillText('…… 还有 ' + (this.data.archive.length - 6) + ' 趟', 40, 440 + 6 * 32);
        }

        ctx.globalAlpha = 0.7;
        ctx.font = '17px sans-serif';
        ctx.fillText('不卖票 · 只帮你少花冤枉钱', 40, H - 40);
        ctx.globalAlpha = 1;

        wx.canvasToTempFilePath({
          canvas,
          x: 0, y: 0, width: W, height: H,
          destWidth: W * 2,
          destHeight: H * 2,
          success: (r) => {
            if (r && r.tempFilePath) this.setData({ reportImg: r.tempFilePath });
          },
          fail: () => wx.showToast({ title: '生成失败，请重试', icon: 'none' }),
        });
      });
  },

  saveReport() {
    const img = this.data.reportImg;
    if (!img) return;
    haptic.light();
    wx.saveImageToPhotosAlbum({
      filePath: img,
      success: () => wx.showToast({ title: '已保存到相册', icon: 'none' }),
      fail: () => wx.showToast({ title: '保存失败，可长按图片保存', icon: 'none' }),
    });
  },

  /** 点某条行程的「分享」时先记下索引 */
  onShareTripTap(e) {
    const i = e.currentTarget.dataset.index;
    this._shareIndex = typeof i === 'number' ? i : parseInt(i, 10);
  },

  onShareAppMessage() {
    const t = this._shareIndex != null ? this.data.trips[this._shareIndex] : null;
    if (t) {
      track('share_trip_card', { id: t.id });
      const q = [
        'from=' + encodeURIComponent(t.from || ''),
        'to=' + encodeURIComponent(t.to || ''),
        'date=' + encodeURIComponent(t.date || ''),
        'dateCN=' + encodeURIComponent(t.dateCN || t.date || ''),
        'type=' + encodeURIComponent(t.type || 'flight'),
        'via=' + encodeURIComponent(t.via || ''),
      ].join('&');
      const route = (t.from || '') + (t.via ? ' → ' + t.via : '') + ' → ' + (t.to || '');
      return share.appMessage({
        title: '【出行计划】' + route + ' · ' + (t.dateCN || t.date),
        path: '/pages/index/index?' + q,
      });
    }
    const stat = this.data.stat;
    if (this.data.tab === 'archive' && stat) {
      return share.appMessage({
        title: '我今年出行了 ' + stat.total + ' 次，去了 ' + stat.cities + ' 座城市',
        path: '/pages/trips/trips',
      });
    }
    track('share_trips');
    return share.appMessage({
      title: '途悦出行防坑：保存行程，一键直达官方购票渠道',
      path: '/pages/index/index',
    });
  },

  /** 查看渠道：当前页底部弹窗展示官方入口（不再切换 Tab 丢失上下文） */
  showChannels(e) {
    const t = e.currentTarget.dataset.item;
    tap('trip_view_channel', { id: t.id });
    const groups = getVisibleGroups().map((g) => ({
      name: g.name,
      desc: g.desc,
      channels: g.channels.map((c) => ({ ...c })),
    }));
    const route = (t.from || '') + (t.via ? ' → ' + t.via : '') + ' → ' + (t.to || '');
    this.setData({ showChannelPopup: true, popupTitle: route, popupGroups: groups });
  },

  closeChannels() {
    this.setData({ showChannelPopup: false });
  },

  noop() {},

  /** 弹窗内点渠道：复制名称，引导去微信搜一搜（与渠道页兜底一致） */
  popupTapChannel(e) {
    const id = e.currentTarget.dataset.id;
    let item = null;
    this.data.popupGroups.forEach((g) => {
      const c = g.channels.find((x) => x.id === id);
      if (c) item = c;
    });
    if (!item) return;
    tap('tap_channel', { id, from: 'popup' });
    wx.setClipboardData({
      data: item.search || item.name,
      success: () => wx.showToast({ title: '已复制「' + item.name + '」，去微信搜一搜', icon: 'none' }),
    });
  },

  copyTel(e) {
    const raw = String(e.currentTarget.dataset.tel || '');
    const tel = raw.replace(/[^\d+]/g, '');
    if (!tel) return;
    tap('tap_channel_tel', { tel });
    wx.setClipboardData({ data: tel, success: () => wx.showToast({ title: '号码已复制', icon: 'none' }) });
  },

  shareTrip(e) {
    const t = e.currentTarget.dataset.item;
    tap('trip_share', { id: t.id });
    const route = `${t.from}${t.via ? ' → ' + t.via : ''} → ${t.to}`;
    const text = `【出行计划】${route} · ${t.dateCN} · ${t.typeLabel}`;
    wx.setClipboardData({
      data: text,
      success: () => wx.showToast({ title: '行程已复制，去微信粘贴分享', icon: 'none' }),
    });
  },

  removeTrip(e) {
    const id = e.currentTarget.dataset.id;
    tap('trip_delete', { id });
    haptic.light();
    wx.showModal({
      title: '删除行程',
      content: '确定删除这条行程吗？',
      confirmColor: '#e5484d',
      success: (r) => {
        if (r.confirm) {
          store.removeTrip(id);
          this.refresh();
        }
      },
    });
  },

  clearAll() {
    tap('trip_clear_all');
    haptic.light();
    wx.showModal({
      title: '清空行程',
      content: '确定清空全部行程吗？此操作不可恢复。',
      confirmColor: '#e5484d',
      success: (r) => {
        if (r.confirm) {
          this.data.trips.forEach((t) => store.removeTrip(t.id));
          this.refresh();
        }
      },
    });
  },

  onTabItemTap(e) {
    track('tab_switch', { page: e.pagePath });
    haptic.light();
  },
  onLoad() {
    wx.showShareMenu({ menus: ['shareAppMessage', 'shareTimeline'] });
  },
  onShareTimeline() {
    return share.timeline({ title: '我的行程，出行安排一目了然' });
  },
});
