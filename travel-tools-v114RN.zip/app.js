// app.js
// ===== 微信云开发环境配置（当前：不启用）=====
// 本项目内容（48 篇攻略）已全部打包在小程序内，无需云开发即可正常运行、正常过审。
// 如将来需要「云端改文章、免发版」，再按下面步骤开启：
//   微信开发者工具顶部点「云开发」→ 开通 → 复制环境 ID（形如 cloud1-xxxxxxxx）→ 填到 CLOUD_ENV，
//   并把 useCloud 改为 true。两者缺一不可，否则不会调用云端（避免未开通时产生初始化报错）。
const CLOUD_ENV = '';

App({
  globalData: {
    useCloud: false,       // 当前不启用云开发（内容走本地打包数据，无任何云端依赖与费用）
    cloudEnv: CLOUD_ENV,   // 将来启用时填云环境 ID
    userInfo: null,
    systemInfo: null,
  },

  onLaunch() {
    // 仅当「开关已打开 + 环境 ID 已填写 + 基础库支持」三者同时满足时才初始化，避免未开通云开发时报错
    if (this.globalData.useCloud && this.globalData.cloudEnv && wx.cloud) {
      wx.cloud.init({
        env: this.globalData.cloudEnv,
        traceUser: true,
      });
    }

    try {
      // getSystemInfoSync 已废弃：优先用 getWindowInfo，旧基础库回退
      let info = {};
      if (wx.getWindowInfo) {
        info = wx.getWindowInfo();
      } else if (wx.getSystemInfoSync) {
        info = wx.getSystemInfoSync();
      }
      this.globalData.systemInfo = info;
    } catch (e) {
      console.warn('获取系统信息失败', e);
    }
  },

  /**
   * 隐私接口被调用但用户尚未同意授权时，微信会回调这里。
   * 「用户隐私保护指引」在后台审核通过后，若用户未同意而触发复制等能力，
   * 微信会把控制权交给本函数，由我们弹出隐私弹窗，用户同意后再继续。
   */
  onNeedPrivacyAuthorization(resolve) {
    try {
      const pages = getCurrentPages();
      const page = pages[pages.length - 1];
      if (!page) return;
      const popup = page.selectComponent && page.selectComponent('#privacyPopup');
      if (popup && popup.show) {
        popup.show(resolve);
      } else {
        // 兜底：页面上没有弹窗组件时，直接同意，避免功能卡死
        resolve({ buttonId: 'agree-btn', event: 'agree' });
      }
    } catch (e) {
      resolve({ buttonId: 'agree-btn', event: 'agree' });
    }
  },
});
