# 途悦出行防坑（微信小程序）

一个**合规的出行渠道导航 + 避坑指南 + 费用计算**工具小程序。
不查实时票价、不售票、不代购，只做「官方渠道入口 + 防坑知识 + 费用估算」。

## 功能一览

| Tab / 页面 | 功能 |
|---|---|
| 渠道导航（首页） | 填写出发地/目的地/日期/类型 → 查看购票渠道；一键保存行程 |
| 购票渠道 | 顶部路线文字动态读取首页/行程所选出发地·目的地·日期·类型；点击渠道卡片尝试 `wx.navigateToMiniProgram` 跳转（已配 AppID 直接跳，否则复制名称引导微信搜一搜）；12306 与航空公司可在后台配置显隐 |
| 避坑指南 | 17 大板块共 133 篇：覆盖机票、火车票、自驾出行、通用防骗、购票时机、带宠/长辈出行、城市防坑、会员权益、机场值机、行李速查、春运等，可分享详情页 |
| 出行工具 | 9 个工具：航班延误权益、维权工具箱、出行打包清单、城市交通指南、智能问答、费用与时差计算（退改签/行李超重/燃油机建/时差）、中转时间、购票值机时间点、自驾计算（成本/续航/限行/时长/免费卡点） |
| 我的行程 | 本地保存行程列表，可直达渠道页、删除、清空 |

所有页面均内置免责声明（不售票、不代购、以官方为准），这是通过微信审核的关键。

## 一、如何运行（不需要账号，今天就能跑）

1. 下载安装微信开发者工具（https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html）
2. 打开开发者工具 → 「导入项目」→ 选择本目录 `travel-tools`
3. AppID 选择「**测试号**」（代码里已预置 `touristappid`，工具会自动识别）
4. 编译即可看到首页，四个 Tab 都可点

## 二、换成正式账号（个体户 / 企业主体，3 步）

1. 到 https://mp.weixin.qq.com 注册小程序账号（个体户 / 企业主体，本工商户执照已办；**选类目建议：工具-信息查询 / 工具-效率**，不要选「出行平台/票务」类目，那需要资质）
2. 在公众平台「设置-基本设置」拿到 **AppID**，填入 `project.config.json` 的 `appid` 字段
3. 小程序名称建议不含「携程」「去哪儿」「12306」等他人品牌词，否则审核驳回；当前名「途悦出行防坑」可直接用或自改

改名位置：`app.json` 的 `navigationBarTitleText` + `pages/index/index.wxml` 的 hero 标题。

## 三、开通「跳转到官方小程序」能力（可选，建议做）

当前点击渠道卡片 = 复制名称并引导用户去微信搜索（合规且能用）。
想直接跳转对方小程序，需要拿到对方的**官方小程序 AppID**，并在 `app.json` 中声明白名单：

1. 在 `data/channels.js` 中给对应渠道的 `appid` 字段填入真实官方 AppID
2. **微信官方规则：自 2020-04-24 起，跳转其他小程序已取消白名单**——无需在 `app.json` 声明 `navigateToMiniProgramAppIdList`、数量不限；目标小程序须已发布，跳转前微信会弹确认框（用户点「允许」才跳）。所以只需在 `data/channels.js` 填对官方 AppID 即可一键直达；AppID 为空则自动走「复制名称→微信搜一搜」兜底。
3. **不要填来路不明的 AppID**，务必使用各平台官方小程序真实 AppID，否则跳转失败或存在安全风险。

> 已核实的官方 AppID 共 16 个：携程 / 飞猪 / 12306 / 去哪儿 / 同程 5 家平台 + 国航 / 东航 / 南航 / 海航 / 厦航 / 深航 / 川航 / 春秋 / 吉祥 / 山航 / 长龙 10 家航司（逐项来源与主体核验记录见 `data/channels.js` 顶部注释）。

## 四、后台配置（显示 / 隐藏渠道分组）

打开 `data/config.js`：

```js
module.exports = {
  show12306: true,    // 是否显示「火车票 / 12306」分组
  showAirline: true, // 是否显示「航空公司」分组
};
```

改为 `false` 即可在首页出行类型与购票渠道 Tab 中隐藏对应分组（含首页出行类型选项）。第二步接入云开发后，可改为从云数据库读取，页面代码无需改动。

## 五、行程数据打通说明

- 首页选好出发地 / 目的地 / 日期 / 类型后点「保存行程」→ 写入本地存储 `tt_trips`。
- 同时记录一份「最近路线」`tt_current`，购票渠道页顶部路线文字优先读取它；未选择时显示提示。
- 「我的行程」页用 `wx.getStorageSync` 读取并渲染卡片，每条带「删除」按钮；无数据保留空态提示。

> 📌 已核实并预置的官方 AppID 共 16 个：携程旅行 `wx0e6ed4f51db9d078`、飞猪旅行 `wx6a96c49f29850eb5`、铁路12306 `wxa51f55ab3b2655b9`、去哪儿 `wx799d4d93a341b368`、同程 `wx336dcaf6a1ecf632`，以及国航 / 东航 / 南航 / 海航 / 厦航 / 深航 / 川航 / 春秋 / 吉祥 / 山航 / 长龙 10 家航司（逐项来源见 `data/channels.js` 顶部注释）。
> ⚠️ 华夏 / 成都 / 西藏 / 首都 / 中国联合 5 家航司的 `appid` 字段虽有值，但未经微信内「更多资料」页逐一核实，跳转异常时请按 `data/channels.js` 顶部流程核对后更新。

## 六、发布上线流程（审核要点）

1. 开发者工具点「上传」→ 填版本号和备注
2. 公众平台 →「版本管理」→ 提交审核
3. 审核注意：
   - 类目选「工具」类，避免票务/出行平台类目
   - 页面不得出现「抢票」「低价票预订」等购票引导话术（本项目文案已规避）
   - 首次审核 1～7 天，通过后点「发布」
4. 上线后如需接入渠道直接跳转，只需在 `data/channels.js` 填入官方 AppID（白名单已取消，无需改 `app.json`），重新发版即生效

## 七、接微信云开发（内容后台可维护）

当前所有内容在 `data/` 目录（本地 JS）。接云开发后结构不变，只换数据来源：

1. 开发者工具点「云开发」→ 开通环境（新账号有免费体验环境；正式使用约 19.9 元/月起）
2. 建集合：`guide_sections`（避坑板块）、`guide_articles`（避坑文章）、`channels`（渠道）
3. 把 `data/guides.js`、`data/channels.js` 里的数据导入集合
4. 新建 `data/api.js`，用 `wx.cloud.database()` 实现同名方法，页面代码**零改动**：

```js
// data/api.js 示意
const db = wx.cloud.database();
async function getSections() {
  return (await db.collection('guide_sections').orderBy('sort', 'asc').get()).data;
}
module.exports = { getSections };
```

5. `app.js` 中把 `useCloud` 改为 `true` 并填入 `cloudEnv`（本文件已预留开关）

## 目录结构

```
travel-tools/
├── app.js / app.json / app.wxss     # 全局配置与样式
├── project.config.json              # 开发者工具配置（appid 在这里改）
├── sitemap.json
├── data/
│   ├── channels.js                  # 渠道数据（含官方 AppID 核验记录，第二步入库）
│   ├── config.js                    # 渠道分组显隐开关
│   ├── guides.js                    # 避坑内容（17 板块 133 篇，第二步入库）
│   ├── cities.js / regions.js       # 城市与地区数据
│   ├── tools.js                     # 出行工具清单（单一数据源）
│   ├── hotreads.js                  # 热门阅读
│   └── guides.cloud.json            # 云数据库导入文件
├── utils/
│   ├── store.js                     # 行程/收藏的本地存储
│   ├── util.js                      # 日期工具
│   ├── track.js                     # 数据埋点（Mock 接口，假后台）
│   ├── share.js                     # 好友/朋友圈分享封装
│   ├── haptic.js                    # 震动反馈
│   ├── ask.js / cloudGuide.js       # 智能问答 / 云内容回退
│   └── secImg.js                    # 图片安全处理
├── images/tabbar/                   # 底部导航图标（4 组 8 张）
├── pages/                           # 共 17 页
│   ├── index/        # 渠道导航（首页表单）
│   ├── city/         # 城市选择
│   ├── channels/     # 购票渠道列表
│   ├── guide/        # 避坑指南
│   ├── guide-detail/ # 避坑详情
│   ├── tools/        # 工具入口（9 个工具）
│   ├── calc/         # 退改签/行李/税费/时差计算器
│   ├── date/         # 购票值机时间点计算
│   ├── drive/        # 自驾计算（成本/续航/限行/时长/清单/计时/免费卡点）
│   ├── trips/        # 我的行程
│   ├── checklist/    # 出行打包清单
│   ├── ask/          # 智能问答
│   ├── cityguide/    # 城市交通指南
│   ├── delay/        # 航班延误权益
│   ├── rights/       # 维权工具箱
│   ├── transit/      # 中转时间计算
│   └── about/        # 关于/版本
└── cloudfunctions/                  # 预留：云函数目录
```

## 数据埋点（Mock 接口 / 假后台）

为方便后续接入微信官方数据分析，已内置一个**本地埋点假接口** `utils/track.js`：

- **现在做什么**：每个按钮/关键交互点击，都会调用 `track()`，仅记录到 `console` 与本地 Storage（`tt_track_events`，最近 200 条），**不发任何网络请求**。
- **覆盖的事件**：保存行程、选择出行类型、交换城市、切换 Tab、各购票渠道点击（含是否已有 AppID）、避坑文章打开/查看/分享、我的行程查看/分享/删除/清空、计算器各输入与切换、常见问题打开、城市选择搜索/选取等。
- **以后怎么接官方分析**：只改 `utils/track.js` 里的 `send()` 一处：
  - 推荐（免服务器）：微信「自定义分析」→ 把 `send()` 内注释打开为 `wx.reportAnalytics(event, payload)`，并在 MP 后台「数据分析 → 自定义分析」配置同名事件与字段；
  - 或自建后台：`wx.request` 把 `{event, ...payload}` POST 到你的接口。
- 调试：`track.getEvents()` 读取本地记录、`track.clearEvents()` 清空。临时整体关闭：`track.js` 顶部 `ENABLED = false`。

调用示例：

```js
const { track, tap } = require('../../utils/track');
track('save_trip', { type: 'flight' });   // 通用事件
tap('btn_save_trip');                       // 按钮点击 = track('tap_btn_save_trip')
```

## 合规说明（重要）

- 本项目**不抓取、不展示任何第三方平台的实时票价**，仅提供官方渠道入口导航
- 全部页面内置免责声明；计算结果标注为「通用估算」
- 跳转能力完全依赖微信官方 `navigateToMiniProgram` 机制，不使用任何爬虫或非官方接口
